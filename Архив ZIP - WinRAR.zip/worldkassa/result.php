<?
include_once 'config.php';
include '../system/function.php';
include '../system/header.php';

    
if (isset($_POST['id_shop']) && is_numeric($_POST['id_shop']) && isset($_POST['id_bill']) && is_numeric($_POST['id_bill']) && isset($_POST['summa']) && is_numeric($_POST['summa']) && isset($_POST['hash'])){


$res = $mysqli->query('SELECT * FROM `worldkassa` WHERE `id_bill` = '.$_POST['id_bill'].'  ');
$sql = $res->fetch_assoc();

 




if ($_POST['summa']<$sql['summa']){
header('Location: /');
$_SESSION['err'] = '<font color=red>Ошибка! Сумма не совпадает!</font>';
exit();
}elseif($_POST['hash']!=md5($hash.$id_shop.$_POST['id_bill'].$_POST['summa'])){
header('Location: /');
$_SESSION['err'] = '<font color=red>Ошибка! Хеш не совпал!</font>';
exit();
}else{ 

foreach($cena_gold as $gold=>$summa){
if ($summa==$sql['summa']){
$res = $mysqli->query('SELECT * FROM `prom` WHERE `id` = "1" ');
$prom = $res->fetch_assoc();

$res = $mysqli->query('SELECT * FROM `users` WHERE `id` = "'.$sql['id_user'].'" ');
$user = $res->fetch_assoc();



/*
if($user['id'] != 694){
$_SESSION['ses'] = 'Техработы. Вернитесь через 5 минут!';    
header('location: /');
exit;
}
*/




if($gold == 100){$bonus = (3);}
if($gold == 200){$bonus = (5);}
if($gold == 500){$bonus = (25);}
if($gold == 1000){$bonus = (75);}
if($gold == 5000){$bonus = (500);}
if($gold == 10000){$bonus = (1250);}



####################################################################################
$id_miss = 5;$prog_max = 100;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().'  limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){
$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "'.$gold.'" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
####################################################################################

####################################################################################
$id_miss = 18;$prog_max = 500;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().'  limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){
$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "'.$gold.'" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
####################################################################################

####################################################################################
if($gold == 5000){$id_miss = 19;$prog_max = 5000;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().'  limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){
$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "'.$gold.'" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}}
####################################################################################



if($prom['time_1'] > time()){$act_1 = ($gold*$prom['act_1']/100);}elsE{$act_1 = 0;}
if($prom['time_4'] > time()){$silver = ($gold*$prom['act_4']/100);}elsE{$silver = 0;}




$res = $mysqli->query("SELECT COUNT(*) FROM `ref` WHERE `ank` = ".$sql['id_user']." ");
$ref = $res->fetch_array(MYSQLI_NUM);
if($ref['ank'] == $sql['id_user']){
$mysqli->query('UPDATE `users` SET `gold` = `gold` + '.($gold*20/100).' WHERE `id` = '.$ref['user'].' LIMIT 1');
}







$gold = ($gold+$act_1);
$mysqli->query('UPDATE `users` SET `gold` = `gold` + '.($gold+$bonus).', `silver` = `silver` + '.($silver).' WHERE `id` = '.$sql['id_user'].' LIMIT 1');
$mysqli->query('UPDATE `worldkassa` SET `time_oplata` = '.time().' WHERE `id` = '.$sql['id'].' LIMIT 1');














}
}









}
}
?>