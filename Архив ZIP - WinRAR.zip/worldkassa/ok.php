<?php
include '../system/function.php';
include '../system/header.php';  
if(!isset($user)){
echo "Только для зарегестрированых";
}else{
header('Location: /worldkassa/buy.php');
$_SESSION['ok'] = '<div class="trnt-block mb1"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="green1 sh_b mb2"><img height="14" width="14" src="/images/icons/victory.png">Платеж выполнен! <img height="14" width="14" src="/images/icons/victory.png"></div>
</div></div></div></div></div></div></div></div></div></div>';
exit();
}
include '../system/footer.php';
?>