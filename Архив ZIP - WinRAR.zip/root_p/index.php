<?php
$title = 'Админ панель';
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id'] or $user['position'] < 4) {
header('Location: /');
exit();
}


echo '<div class="white medium bold cntr mb2">Панель управления</div>';









echo '<div class="brunches-block"><table><tbody><tr>';

echo '<td><a href="/prom/"><span class="image"><img src="/images/sett.png?1" alt="image" style="border-radius: 8px;"><span class="mask">&nbsp;</span>
<span class="r">&nbsp;</span></span>Акции</a></td>';

echo '<td><a href="/bon/"><span class="image"><img src="/images/sett.png?" alt="image" style="border-radius: 8px;"><span class="mask">&nbsp;</span>
<span class="r">&nbsp;</span></span>Бонусы</a></td>';

echo '<td><a href="/sett/"><span class="image"><img src="/images/sett.png?1" alt="image" style="border-radius: 8px;"><span class="mask">&nbsp;</span>
<span class="r">&nbsp;</span></span>Настройки</a></td>';


echo '</tr></tbody></table></div>';








echo '<div class="brunches-block"><table><tbody><tr>';

echo '<td><a href="/paywk/0/"><span class="image"><img src="/images/sett.png?1" alt="image" style="border-radius: 8px;"><span class="mask">&nbsp;</span>
<span class="r">&nbsp;</span></span>Платежи</a></td>';

echo '</tr></tbody></table></div>';





require_once ('../system/footer.php');
?>