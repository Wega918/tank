<?php
$title = 'Админ панель';
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id'] or $user['position'] < 4) {
header('Location: /');
exit();
}


echo '<div class="white medium bold cntr mb2">Настройки игры</div>';







$res = $mysqli->query("SELECT COUNT(*) FROM `users` WHERE `email` > '0' and `spam` != '0' ");
$k_post1 = $res->fetch_array(MYSQLI_NUM);

$res = $mysqli->query("SELECT COUNT(*) FROM `users` WHERE `email` > '0' ");
$k_post = $res->fetch_array(MYSQLI_NUM);




$res = $mysqli->query("SELECT COUNT(*) FROM `email` WHERE `email` > '0' and `spam` != '0' ");
$k_post2 = $res->fetch_array(MYSQLI_NUM);

$res = $mysqli->query("SELECT COUNT(*) FROM `email` WHERE `email` > '0' ");
$k_posе2_ = $res->fetch_array(MYSQLI_NUM);



$res = $mysqli->query("SELECT COUNT(*) FROM `email_` WHERE `email` > '0' and `spam` != '0' ");
$k_post3 = $res->fetch_array(MYSQLI_NUM);

$res = $mysqli->query("SELECT COUNT(*) FROM `email_` WHERE `email` > '0' ");
$k_post3_ = $res->fetch_array(MYSQLI_NUM);



$res = $mysqli->query("SELECT COUNT(*) FROM `email1` WHERE `email` > '0' and `spam` != '0' ");
$k_post4 = $res->fetch_array(MYSQLI_NUM);

$res = $mysqli->query("SELECT COUNT(*) FROM `email1` WHERE `email` > '0' ");
$k_post4_ = $res->fetch_array(MYSQLI_NUM);



$res = $mysqli->query("SELECT COUNT(*) FROM `email2` WHERE `email` > '0' and `spam` != '0' ");
$k_post5 = $res->fetch_array(MYSQLI_NUM);

$res = $mysqli->query("SELECT COUNT(*) FROM `email2` WHERE `email` > '0' ");
$k_post5_ = $res->fetch_array(MYSQLI_NUM);



$res = $mysqli->query("SELECT COUNT(*) FROM `email3` WHERE `email` > '0' and `spam` != '0' ");
$k_post6 = $res->fetch_array(MYSQLI_NUM);

$res = $mysqli->query("SELECT COUNT(*) FROM `email3` WHERE `email` > '0' ");
$k_post6_ = $res->fetch_array(MYSQLI_NUM);



$res = $mysqli->query("SELECT COUNT(*) FROM `email4` WHERE `email` > '0' and `spam` != '0' ");
$k_post7 = $res->fetch_array(MYSQLI_NUM);

$res = $mysqli->query("SELECT COUNT(*) FROM `email4` WHERE `email` > '0' ");
$k_post7_ = $res->fetch_array(MYSQLI_NUM);



$res = $mysqli->query("SELECT COUNT(*) FROM `email5` WHERE `email` > '0' and `spam` != '0' ");
$k_post8 = $res->fetch_array(MYSQLI_NUM);

$res = $mysqli->query("SELECT COUNT(*) FROM `email5` WHERE `email` > '0' ");
$k_post8_ = $res->fetch_array(MYSQLI_NUM);


$res = $mysqli->query("SELECT COUNT(*) FROM `email6` WHERE `email` > '0' and `spam` != '0' ");
$k_post9 = $res->fetch_array(MYSQLI_NUM);

$res = $mysqli->query("SELECT COUNT(*) FROM `email6` WHERE `email` > '0' ");
$k_post9_ = $res->fetch_array(MYSQLI_NUM);


$res = $mysqli->query("SELECT COUNT(*) FROM `email7` WHERE `email` > '0' and `spam` != '0' ");
$k_post10 = $res->fetch_array(MYSQLI_NUM);

$res = $mysqli->query("SELECT COUNT(*) FROM `email7` WHERE `email` > '0' ");
$k_post10_ = $res->fetch_array(MYSQLI_NUM);



echo '<table><tbody><tr>
<td class="pr4 w33"><div style="position:relative;"><a class="simple-but border mb1" href="?spam"><span><span>Спам '.$k_post1[0].'/'.$k_post[0].'</span></span></a></div></td>
<td class="pr4 w33"><div style="position:relative;"><a class="simple-but border mb1" href="?obnul"><span><span>Обнулить</span></span></a></div></td>
</tr></tbody></table>';


echo '<table><tbody><tr>
<td class="pr4 w33"><div style="position:relative;"><a class="simple-but border mb1" href="?spam1"><span><span>Спам '.$k_post2[0].'/'.$k_posе2_[0].'</span></span></a></div></td>
</tr></tbody></table>';


echo '<table><tbody><tr>
<td class="pr4 w33"><div style="position:relative;"><a class="simple-but border mb1" href="?spam2"><span><span>Спам '.$k_post3[0].'/'.$k_post3_[0].'</span></span></a></div></td>
</tr></tbody></table>';





echo '<table><tbody><tr>
<td class="pr4 w33"><div style="position:relative;"><a class="simple-but border mb1" href="?spam3"><span><span>Спам '.$k_post4[0].'/'.$k_post4_[0].'</span></span></a></div></td>
</tr></tbody></table>';



echo '<table><tbody><tr>
<td class="pr4 w33"><div style="position:relative;"><a class="simple-but border mb1" href="?spam4"><span><span>Спам '.$k_post5[0].'/'.$k_post5_[0].'</span></span></a></div></td>
</tr></tbody></table>';



echo '<table><tbody><tr>
<td class="pr4 w33"><div style="position:relative;"><a class="simple-but border mb1" href="?spam5"><span><span>Спам '.$k_post6[0].'/'.$k_post6_[0].'</span></span></a></div></td>
</tr></tbody></table>';



echo '<table><tbody><tr>
<td class="pr4 w33"><div style="position:relative;"><a class="simple-but border mb1" href="?spam6"><span><span>Спам '.$k_post7[0].'/'.$k_post7_[0].'</span></span></a></div></td>
</tr></tbody></table>';




echo '<table><tbody><tr>
<td class="pr4 w33"><div style="position:relative;"><a class="simple-but border mb1" href="?spam7"><span><span>Спам '.$k_post8[0].'/'.$k_post8_[0].'</span></span></a></div></td>
</tr></tbody></table>';



echo '<table><tbody><tr>
<td class="pr4 w33"><div style="position:relative;"><a class="simple-but border mb1" href="?spam8"><span><span>Спам '.$k_post9[0].'/'.$k_post9_[0].'</span></span></a></div></td>
</tr></tbody></table>';


echo '<table><tbody><tr>
<td class="pr4 w33"><div style="position:relative;"><a class="simple-but border mb1" href="?spam9"><span><span>Спам '.$k_post10[0].'/'.$k_post10_[0].'</span></span></a></div></td>
</tr></tbody></table>';




if(isset($_GET['spam'])){
$res = $mysqli->query('SELECT * FROM `users` WHERE `spam` = "0" and `email` > "0" limit 100');
while ($w_us = $res->fetch_array()){
if($w_us['spam']==0){
$mysqli->query('UPDATE `users` SET `spam` = "1" WHERE `id` = '.$w_us['id'].' ');
var_dump(mail($w_us['email'], 'Танки онлайн', '
Вы пропустили несколько новых событий!

'.$w_us['login'].', вот прямая ссылка для автоматической авторизации в игру: 
'.$HOME.'autolog.php?ulog='.$w_us['login'].'&upas='.$w_us['passw'].'', 'From: news@mtank.ru'));

/* 
var_dump( mail( $w_us['email'], 'Авиа бизнесмены', '
У Вас есть пропущенные собития!
'.$w_us['login'].', прямая ссылка для автоматической авторизации в игру: 
https://airbizz.mobi/autolog.php?ulog='.$w_us['login'].'&upas='.$w_us['passw'].' ' ) ); */
}
}
header('Location: ?');
}





if(isset($_GET['spam1'])){
$res = $mysqli->query('SELECT * FROM `email` WHERE `spam` = "0" and `email` > "0" limit 500');
while ($w_us = $res->fetch_array()){
if($w_us['spam']==0){
$mysqli->query('UPDATE `email` SET `spam` = "1" WHERE `id` = '.$w_us['id'].' ');
var_dump(mail($w_us['email'], 'Танки онлайн', '
Вы пропустили несколько новых событий!

Возвращайтесь: '.$HOME.'', 'From: news@mtank.ru'));
}
}
header('Location: ?');
}





if(isset($_GET['spam2'])){
$res = $mysqli->query('SELECT * FROM `email_` WHERE `spam` = "0" and `email` > "0" limit 500');
while ($w_us = $res->fetch_array()){
if($w_us['spam']==0){
$mysqli->query('UPDATE `email_` SET `spam` = "1" WHERE `id` = '.$w_us['id'].' ');
var_dump(mail($w_us['email'], 'Танки онлайн', '
Вы пропустили несколько новых событий!

Возвращайтесь: '.$HOME.'', 'From: news@mtank.ru'));
}
}
header('Location: ?');
}




if(isset($_GET['spam3'])){
$res = $mysqli->query('SELECT * FROM `email1` WHERE `spam` = "0" and `email` > "0" limit 500');
while ($w_us = $res->fetch_array()){
if($w_us['spam']==0){
$mysqli->query('UPDATE `email1` SET `spam` = "1" WHERE `id` = '.$w_us['id'].' ');
var_dump(mail($w_us['email'], 'Танки онлайн', '
Вы пропустили несколько новых событий!

Возвращайтесь: '.$HOME.'', 'From: news@mtank.ru'));
}
}
header('Location: ?');
}




if(isset($_GET['spam4'])){
$res = $mysqli->query('SELECT * FROM `email2` WHERE `spam` = "0" and `email` > "0" limit 500');
while ($w_us = $res->fetch_array()){
if($w_us['spam']==0){
$mysqli->query('UPDATE `email2` SET `spam` = "1" WHERE `id` = '.$w_us['id'].' ');
var_dump(mail($w_us['email'], 'Танки онлайн', '
Вы пропустили несколько новых событий!

Возвращайтесь: '.$HOME.'', 'From: news@mtank.ru'));
}
}
header('Location: ?');
}




if(isset($_GET['spam5'])){
$res = $mysqli->query('SELECT * FROM `email3` WHERE `spam` = "0" and `email` > "0" limit 500');
while ($w_us = $res->fetch_array()){
if($w_us['spam']==0){
$mysqli->query('UPDATE `email3` SET `spam` = "1" WHERE `id` = '.$w_us['id'].' ');
var_dump(mail($w_us['email'], 'Танки онлайн', '
Вы пропустили несколько новых событий!

Возвращайтесь: '.$HOME.'', 'From: news@mtank.ru'));
}
}
header('Location: ?');
}




if(isset($_GET['spam6'])){
$res = $mysqli->query('SELECT * FROM `email4` WHERE `spam` = "0" and `email` > "0" limit 500');
while ($w_us = $res->fetch_array()){
if($w_us['spam']==0){
$mysqli->query('UPDATE `email4` SET `spam` = "1" WHERE `id` = '.$w_us['id'].' ');
var_dump(mail($w_us['email'], 'Танки онлайн', '
Вы пропустили несколько новых событий!

Возвращайтесь: '.$HOME.'', 'From: news@mtank.ru'));
}
}
header('Location: ?');
}





if(isset($_GET['spam7'])){
$res = $mysqli->query('SELECT * FROM `email5` WHERE `spam` = "0" and `email` > "0" limit 500');
while ($w_us = $res->fetch_array()){
if($w_us['spam']==0){
$mysqli->query('UPDATE `email5` SET `spam` = "1" WHERE `id` = '.$w_us['id'].' ');
var_dump(mail($w_us['email'], 'Танки онлайн', '
Вы пропустили несколько новых событий!

Возвращайтесь: '.$HOME.'', 'From: news@mtank.ru'));
}
}
header('Location: ?');
}




if(isset($_GET['spam8'])){
$res = $mysqli->query('SELECT * FROM `email6` WHERE `spam` = "0" and `email` > "0" limit 500');
while ($w_us = $res->fetch_array()){
if($w_us['spam']==0){
$mysqli->query('UPDATE `email6` SET `spam` = "1" WHERE `id` = '.$w_us['id'].' ');
var_dump(mail($w_us['email'], 'Танки онлайн', '
Вы пропустили несколько новых событий!

Возвращайтесь: '.$HOME.'', 'From: news@mtank.ru'));
}
}
header('Location: ?');
}




if(isset($_GET['spam9'])){
$res = $mysqli->query('SELECT * FROM `email7` WHERE `spam` = "0" and `email` > "0" limit 500');
while ($w_us = $res->fetch_array()){
if($w_us['spam']==0){
$mysqli->query('UPDATE `email7` SET `spam` = "1" WHERE `id` = '.$w_us['id'].' ');
var_dump(mail($w_us['email'], 'Танки онлайн', '
Вы пропустили несколько новых событий!

Возвращайтесь: '.$HOME.'', 'From: news@mtank.ru'));
}
}
header('Location: ?');
}






if(isset($_GET['obnul'])){
$mysqli->query('UPDATE `users` SET `spam` = "0" WHERE `id` ');
$mysqli->query('UPDATE `email` SET `spam` = "0" WHERE `id` ');
$mysqli->query('UPDATE `email_` SET `spam` = "0" WHERE `id` ');
$mysqli->query('UPDATE `email1` SET `spam` = "0" WHERE `id` ');
$mysqli->query('UPDATE `email2` SET `spam` = "0" WHERE `id` ');
$mysqli->query('UPDATE `email3` SET `spam` = "0" WHERE `id` ');
$mysqli->query('UPDATE `email4` SET `spam` = "0" WHERE `id` ');

$mysqli->query('UPDATE `email5` SET `spam` = "0" WHERE `id` ');
$mysqli->query('UPDATE `email6` SET `spam` = "0" WHERE `id` ');
$mysqli->query('UPDATE `email7` SET `spam` = "0" WHERE `id` ');

header('Location: ?');
}


/* $mysqli->query('DELETE FROM `email2` WHERE `email` = "" ');
$mysqli->query('DELETE FROM `email3` WHERE `email` = "" ');
$mysqli->query('DELETE FROM `email4` WHERE `email` = "" ');
$mysqli->query('DELETE FROM `email5` WHERE `email` = "" ');
$mysqli->query('DELETE FROM `email6` WHERE `email` = "" ');
$mysqli->query('DELETE FROM `email7` WHERE `email` = "" ');


 */





require_once ('../system/footer.php');
?>