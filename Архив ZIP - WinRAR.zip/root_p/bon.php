<?php
$title = 'Админ панель';
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id'] or $user['position'] < 4) {
header('Location: /');
exit();
}
$res = $mysqli->query('SELECT COUNT(*) FROM `users` WHERE `viz` > '.(time()-(86400*7)).' ');
$ONL = $res->fetch_array(MYSQLI_NUM);



/* $mysqli->query("UPDATE `ammunition_users` SET `b` = '0' WHERE `b` < '0' ");
$mysqli->query("UPDATE `ammunition_users` SET `k` = '0' WHERE `k` < '0' ");
$mysqli->query("UPDATE `ammunition_users` SET `f` = '0' WHERE `f` < '0' ");
 */








echo '<div class="white medium bold cntr mb2">Выдача бонусов <font color=limegreen>('.$ONL[0].')</font></div>';



echo '<br><form class="pb10" w:id="newPmForm" id="id1" method="post" action="?submit"><div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id1_hf_0" id="id1_hf_0"></div>

<center>
ID игрока<Br>(чтобы выдать всем, не заполняйте)<input w:id="newLogin" type="number" name="user" value="0" class="fld-chng" size="5" maxlength="4"><hr>
</center>
<img height="14" width="14" src="/images/icons/gold.png"> Золото <input w:id="newLogin" type="number" name="gold" value="0" class="fld-chng" size="10" maxlength="4"><br>
<img height="14" width="14" src="/images/icons/silver.png"> Серебро <input w:id="newLogin" type="number" name="silver" value="0" class="fld-chng" size="10" maxlength="4"><br>
<img height="14" width="14" src="/images/icons/crewpoints.png"> Очки экипажа <input w:id="newLogin" type="number" name="crewpoints" value="0" class="fld-chng" size="10" maxlength="4"><br>
<img title="Топливо" alt="Топливо" src="/images/icons/fuel.png?2"> Топливо <input w:id="newLogin" type="number" name="fuel" value="0" class="fld-chng" size="10" maxlength="4"><br>


<img title="Усиление" alt="Усиление" src="/images/icons/exp.png"> "Вера в победу" <input w:id="newLogin" type="number" name="vip_1" value="0" class="fld-chng" size="10" maxlength="4" style="width: 10%;"> часов<br>
<img title="Усиление" alt="Усиление" src="/images/icons/exp.png?2"> "Передовое снабжение" <input w:id="newLogin" type="number" name="vip_2" value="0" class="fld-chng" size="10" maxlength="4" style="width: 10%;"> часов<br>
<img title="Усиление" alt="Усиление" src="/images/icons/exp.png?2"> "Армейское братство" <input w:id="newLogin" type="number" name="vip_3" value="0" class="fld-chng" size="10" maxlength="4" style="width: 10%;"> часов<br>
<img title="Усиление" alt="Усиление" src="/images/icons/exp.png?2"> "Эксп. оборудование" <input w:id="newLogin" type="number" name="vip_4" value="0" class="fld-chng" size="10" maxlength="4" style="width: 10%;"> часов<br>

<img title="Бронебойный снаряд" alt="Бронебойный снаряд" src="/images/shells/ArmorPiercing.png"> Бронебойный снаряд <input w:id="newLogin" type="number" name="b" value="0" class="fld-chng" size="10" maxlength="4" style="width: 10%;"> шт.<br>
<img title="Фугасный снаряд" alt="Фугасный снаряд" src="/images/shells/HighExplosive.png"> Фугасный снаряд <input w:id="newLogin" type="number" name="f" value="0" class="fld-chng" size="10" maxlength="4" style="width: 10%;"> шт.<br>
<img title="Кумулятивный снаряд" alt="Кумулятивный снаряд" src="/images/shells/HollowCharge.png"> Кумулятивный снаряд <input w:id="newLogin" type="number" name="k" value="0" class="fld-chng" size="10" maxlength="4" style="width: 10%;"> шт.<br>
<img title="Ремкомплект" alt="Ремкомплект" src="/images/shells/repairkit.png"> Ремкомплект <input w:id="newLogin" type="number" name="rem" value="0" class="fld-chng" size="10" maxlength="4" style="width: 10%;"> шт.<br>



<div class="dhr a_w50 mt5 mb5"></div>
<center>описание:<center>
<div class="cntr mb5"><textarea id="message" rows="3" name="message" class="w90 p0 m0"></textarea></div>';
?><span id="pokazat">
<table><tbody><tr><td style="width:25%;padding-right:4px;"></td>
<td style="width:50%;"><div class="input-but border w100 m0a"><span><input class="w100" type="submit" w:message="value:MessagePage.send" value="Отправить"></span></div></td>
<td style="width:33%;padding-left:5px;padding-top:5px;">
<a onclick="document.getElementById('pokazat').style.display='none';document.getElementById('skryt').style.display='';return false;" class="btni" style="height: 24px; width: 23px; padding: 2px 3px;box-shadow: inset 0px 1px 0px #;border: 1px solid #7dab2e;color:#FFFFFF;text-align: inherit;border-radius: 7px;border-radius: 4px;" href="#"><img style="vertical-align: sub;" src="/files/smile/smiles.png" width="20"></a>
</td></tr></tbody></table></span><?

?><span id="skryt" style="display:none">
<table><tbody><tr><td style="width:25%;padding-right:4px;"></td>
<td style="width:50%;"><div class="input-but border w100 m0a"><span><input class="w100" type="submit" w:message="value:MessagePage.send" value="Отправить"></span></div></td>
<td style="width:33%;padding-left:5px;padding-top:5px;">
<a onclick="document.getElementById('skryt').style.display='none';document.getElementById('pokazat').style.display='';return false;" class="btni" style="height: 24px; width: 23px; padding: 2px 3px;box-shadow: inset 0px 1px 0px #;border: 1px solid #7dab2e;color:#FFFFFF;text-align: inherit;border-radius: 7px;border-radius: 4px;" href="#"><img style="vertical-align: sub;" src="/files/smile/smiles.png" width="20"></a>
</td></tr></tbody></table>
<div class="fight center">
<?
$sm = $mysqli->query('SELECT * FROM `smile` WHERE `papka` = "1" ORDER BY `id` ASC');
while ($s = $sm->fetch_array()){
?><a onclick="pasteSmile(' <?=$s['name']?> ')"><img src="<?=$HOME?>files/smile/<?=$s['icon']?>" alt="<?=$s['name']?>" title="<?=$s['name']?>"></a><?
}
?>
</div></span><?
echo '</form>';
if(isset($_REQUEST['submit'])) {
if($user['position'] < 4){header('Location: ?');exit();}
$user = strong($_POST['user']);
$gold = strong($_POST['gold']);
$silver = strong($_POST['silver']);
$crewpoints = strong($_POST['crewpoints']);
$fuel = strong($_POST['fuel']);
$vip_1 = strong($_POST['vip_1']);
$vip_2 = strong($_POST['vip_2']);
$vip_3 = strong($_POST['vip_3']);
$vip_4 = strong($_POST['vip_4']);
$b = strong($_POST['b']);
$f = strong($_POST['f']);
$k = strong($_POST['k']);
$rem = strong($_POST['rem']);
$message1 = strong($_POST['message']);
if(empty($message1)){header('location:?');$_SESSION['err'] = "Поле 'message' обязательно";exit();}


if($gold>0){$gold_t = "<img height='14' width='14' src='/images/icons/gold.png'> ".$gold." золота<br>";}else{$gold_t = "";}
if($silver>0){$silver_t = "<img height='14' width='14' src='/images/icons/silver.png'> ".$silver." серебра<br>";}else{$silver_t = "";}
if($crewpoints>0){$crewpoints_t = "<img height='14' width='14' src='/images/icons/crewpoints.png'> ".$crewpoints." очков экипажа<br>";}else{$crewpoints_t = "";}
if($fuel>0){$fuel_t = "<img height='14' width='14' src='/images/icons/fuel.png'> ".$fuel." топлива<br>";}else{$fuel_t = "";}
if($vip_1>0){$vip_1_t = "<img height='14' width='14' src='/images/icons/exp.png'> Усиление 'Вера в победу' на ".$vip_1."ч.<br>";}else{$vip_1_t = "";}
if($vip_2>0){$vip_2_t = "<img height='14' width='14' src='/images/icons/exp.png'> Усиление 'Передовое снабжение' на ".$vip_2."ч.<br>";}else{$vip_2_t = "";}
if($vip_3>0){$vip_3_t = "<img height='14' width='14' src='/images/icons/exp.png'> Усиление 'Армейское братство' на ".$vip_3."ч.<br>";}else{$vip_3_t = "";}
if($vip_4>0){$vip_4_t = "<img height='14' width='14' src='/images/icons/exp.png'> Усиление 'Экспериментальное оборудование' на ".$vip_4."ч.<br>";}else{$vip_4_t = "";}
if($b>0){$b_t = "<img height='14' width='14' src='/images/shells/ArmorPiercing.png'> Бронебойный снаряд ".$b." шт.<br>";}else{$b_t = "";}
if($f>0){$f_t = "<img height='14' width='14' src='/images/shells/HighExplosive.png'> Фугасный снаряд ".$f." шт.<br>";}else{$f_t = "";}
if($k>0){$k_t = "<img height='14' width='14' src='/images/shells/HollowCharge.png'> Кумулятивный снаряд ".$k." шт.<br>";}else{$k_t = "";}
if($rem>0){$rem_t = "<img height='14' width='14' src='/images/shells/repairkit.png'> Ремкомплект ".$rem." шт.<br>";}else{$rem_t = "";}


if($user>0){
$res11 = $mysqli->query('SELECT * FROM `users` WHERE `id` = '.$user.' ORDER BY `id` asc LIMIT 1');
}else{
$res11 = $mysqli->query('SELECT * FROM `users` WHERE `viz` > '.(time()-(86400*7)).' ORDER BY `id` asc LIMIT 100000');
}
while ($ank = $res11->fetch_array()){


$res = $mysqli->query('SELECT * FROM `ammunition_users` WHERE `user`  = "'.$ank['id'].'" LIMIT 1');
$a_users = $res->fetch_assoc();





if($gold>0 or $silver>0 or $fuel>0){
$mysqli->query("UPDATE `users` SET `gold` = `gold` + '".$gold."', `silver` = `silver` + '".$silver."', `fuel` = `fuel` + '".$fuel."' WHERE `id` = '".$ank['id']."' ");
}
if($crewpoints>0){
$res = $mysqli->query('SELECT * FROM `ammunition_users` WHERE `user`  = "'.$ank['id'].'" LIMIT 1');
$ammunition_users = $res->fetch_assoc();
$mysqli->query('UPDATE `ammunition_users` SET `crewpoints` = '.($ammunition_users['crewpoints']+$crewpoints).' WHERE `id` = '.$ammunition_users['id'].'');
}


$res = $mysqli->query('SELECT * FROM `vip` WHERE `user` = "'.$ank['id'].'" LIMIT 1');
$vip = $res->fetch_assoc();
$res = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user` = '.$ank['id'].' and `active`  = "1" LIMIT 1');
$u_t = $res->fetch_assoc();

if($vip_1>0){
if($vip['time1']>time()){
$mysqli->query("UPDATE `vip` SET `time1` = '".($vip['time1']+($vip_1*3600))."' WHERE `id` = '".$vip['id']."' LIMIT 1");
}else{
if(!$vip){
$mysqli->query('INSERT INTO `vip` SET `time1` = "'.(time()+($vip_1*3600)).'", `user` = "'.$ank['id'].'"');
$mysqli->query('UPDATE `users_tanks` SET `a` = '.($u_t['a']+100).', `b` = '.($u_t['b']+100).', `t` = '.($u_t['t']+100).', `p` = '.($u_t['p']+100).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}else{
$mysqli->query("UPDATE `vip` SET `time1` = '".(time()+($vip_1*3600))."' WHERE `id` = '".$vip['id']."' LIMIT 1");
}
}
}

if($vip_2>0){
if($vip['time2']>time()){
$mysqli->query("UPDATE `vip` SET `time2` = '".($vip['time2']+($vip_2*3600))."' WHERE `id` = '".$vip['id']."' LIMIT 1");
}else{
if(!$vip){
$mysqli->query('INSERT INTO `vip` SET `time2` = "'.(time()+($vip_2*3600)).'", `user` = "'.$ank['id'].'"');
}else{
$mysqli->query("UPDATE `vip` SET `time2` = '".(time()+($vip_2*3600))."' WHERE `id` = '".$vip['id']."' LIMIT 1");
}
}
}

if($vip_3>0){
if($vip['time3']>time()){
$mysqli->query("UPDATE `vip` SET `time3` = '".($vip['time3']+($vip_3*3600))."' WHERE `id` = '".$vip['id']."' LIMIT 1");
}else{
if(!$vip){
$mysqli->query('INSERT INTO `vip` SET `time3` = "'.(time()+($vip_3*3600)).'", `user` = "'.$ank['id'].'"');
}else{
$mysqli->query("UPDATE `vip` SET `time3` = '".(time()+($vip_3*3600))."' WHERE `id` = '".$vip['id']."' LIMIT 1");
}
}
}

if($vip_4>0){
if($vip['time4']>time()){
$mysqli->query("UPDATE `vip` SET `time4` = '".($vip['time4']+($vip_4*3600))."' WHERE `id` = '".$vip['id']."' LIMIT 1");
}else{
if(!$vip){
$mysqli->query('INSERT INTO `vip` SET `time4` = "'.(time()+($vip_4*3600)).'", `user` = "'.$ank['id'].'"');
}else{
$mysqli->query("UPDATE `vip` SET `time4` = '".(time()+($vip_4*3600))."' WHERE `id` = '".$vip['id']."' LIMIT 1");
}
}

$res = $mysqli->query('SELECT * FROM `buildings_polygon` WHERE `user` = '.$ank['id'].' LIMIT 1');
$b_polygon = $res->fetch_assoc();
if($b_polygon){
if($b_polygon['a_time']>time()){
if($b_polygon['a']!=50){
$mysqli->query("UPDATE `buildings_polygon` SET `a` = '".($b_polygon['a']+10)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `a` = '.($u_t['a']+10).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}else{
$mysqli->query("UPDATE `buildings_polygon` SET `a` = '".($b_polygon['a']+20)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `a` = '.($u_t['a']+20).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}
}
if($b_polygon['b_time']>time() ){
if($b_polygon['b']!=50){
$mysqli->query("UPDATE `buildings_polygon` SET `b` = '".($b_polygon['b']+10)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `b` = '.($u_t['b']+10).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}else{
$mysqli->query("UPDATE `buildings_polygon` SET `b` = '".($b_polygon['b']+20)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `b` = '.($u_t['b']+20).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}
}
if($b_polygon['b_time']>time() ){
if($b_polygon['t']!=50){
$mysqli->query("UPDATE `buildings_polygon` SET `t` = '".($b_polygon['t']+10)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `t` = '.($u_t['t']+10).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}else{
$mysqli->query("UPDATE `buildings_polygon` SET `t` = '".($b_polygon['t']+20)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `t` = '.($u_t['t']+20).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}
}
if($b_polygon['b_time']>time() ){
if($b_polygon['p']!=50){
$mysqli->query("UPDATE `buildings_polygon` SET `p` = '".($b_polygon['p']+10)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `p` = '.($u_t['p']+10).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}else{
$mysqli->query("UPDATE `buildings_polygon` SET `p` = '".($b_polygon['p']+20)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `p` = '.($u_t['p']+20).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}
}
}
}

if($b>0){
if(!$a_users){
$mysqli->query('INSERT INTO `ammunition_users` SET `b` = "'.($b).'", `user` = "'.$ank['id'].'"');
}else{
$mysqli->query("UPDATE `ammunition_users` SET `b` = '".($a_users['b']+$b)."' WHERE `id` = '".$a_users['id']."' LIMIT 1");
}
}

if($f>0){
if(!$a_users){
$mysqli->query('INSERT INTO `ammunition_users` SET `f` = "'.($f).'", `user` = "'.$ank['id'].'"');
}else{
$mysqli->query("UPDATE `ammunition_users` SET `f` = '".($a_users['f']+$f)."' WHERE `id` = '".$a_users['id']."' LIMIT 1");
}
}

if($k>0){
if(!$a_users){
$mysqli->query('INSERT INTO `ammunition_users` SET `k` = "'.($k).'", `user` = "'.$ank['id'].'"');
}else{
$mysqli->query("UPDATE `ammunition_users` SET `k` = '".($a_users['k']+$k)."' WHERE `id` = '".$a_users['id']."' LIMIT 1");
}
}

if($rem>0){
if(!$a_users){
$mysqli->query('INSERT INTO `ammunition_users` SET `rem` = "'.($rem).'", `user` = "'.$ank['id'].'"');
}else{
$mysqli->query("UPDATE `ammunition_users` SET `rem` = '".($a_users['rem']+$rem)."' WHERE `id` = '".$a_users['id']."' LIMIT 1");
}
}


$message = "<span class='admin'>
<p>Здравствуйте, ".$ank['login']."!

<br><br>
".$message1."
<br><br>

Вы получили посылку:
<br>
".$gold_t."".$silver_t."".$crewpoints_t."".$fuel_t."".$vip_1_t."".$vip_2_t."".$vip_3_t."".$vip_4_t."".$b_t."".$f_t."".$k_t."".$rem_t."

<br></p></span>";

$res = $mysqli->query('SELECT * FROM `dialog` WHERE ((`user` = 2 and `ank` = '.$ank['id'].') or (`user` = '.$ank['id'].' and `ank` = 2)) ');
$dialog = $res->fetch_assoc();
if(!$dialog){
$mysqli->query('INSERT INTO `dialog` SET `user` = "2", `ank` = "'.$ank['id'].'", `time` = "'.time().'" ');
$uid = mysqli_insert_id($mysqli);
$mysqli->query('INSERT INTO `pm` SET `dialog` = "'.$uid.'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$ank['id'].'" ');
$mysqli->query('INSERT INTO `pm_copy` SET `dialog` = "'.$uid.'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$ank['id'].'" ');
}else{
$mysqli->query('INSERT INTO `pm` SET `dialog` = "'.$dialog['id'].'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$ank['id'].'" ');
$mysqli->query('INSERT INTO `pm_copy` SET `dialog` = "'.$dialog['id'].'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$ank['id'].'" ');
$mysqli->query('UPDATE `dialog` SET `time` = "'.time().'" WHERE `id` = "'.$dialog['id'].'" LIMIT 1');
}

}


if($user>0){
$_SESSION['ok'] = "Бонусы выданы игроку ".nick($user)."";
}else{
$_SESSION['ok'] = "Бонусы выданы ".$ONL[0]." чел.";
}



header('location:?');
exit();
}





?>
<script>
function showSmiles(){
document.getElementById("smiles").style.display = "block";
}
function  pasteSmile(smile){
message = document.getElementById("message");
message.value = message.value + smile;
message.focus();
message.selectionStart = message.value.length;
}
</script> 
<?



require_once ('../system/footer.php');
?>