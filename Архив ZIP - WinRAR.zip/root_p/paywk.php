<?php
$title = 'Админ панель';
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id'] or $user['position'] < 4) {
header('Location: /');
exit();
}
$id = abs(intval($_GET['id']));
/* $res = $mysqli->query('SELECT * FROM `forum_razdel` WHERE `id` = '.$id_razdel.' LIMIT 1');
$paywk = $res->fetch_assoc();
 */


echo '<div class="white medium bold cntr mb2">Выдача платежей</div>';








echo '<br><form class="pb10" w:id="newPmForm" id="id1" method="post" action="?submit"><div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id1_hf_0" id="id1_hf_0"></div>

ID игрока <Br><input w:id="newLogin" type="number" name="user" value="0" class="fld-chng" size="5" maxlength="4"><br>

Платеж <br><select style="width: 50%;" name="sum">
<option selected="selected" value="10">10 руб</option>
<option value="20">20 руб</option>
<option value="50">50 руб</option>
<option value="100">100 руб</option>
<option value="500">500 руб</option>
<option value="1000">1000 руб</option>
</select><br>

<div class="dhr a_w50 mt5 mb5"></div>';
echo '<input class="w100" type="submit" value="Выдать"></form>';






if(isset($_REQUEST['submit'])) {



if($user['position'] < 4){header('Location: ?');exit();}
$user_ = strong($_POST['user']);
$sum = strong($_POST['sum']);
if(!$user_){header('Location: ?');exit();}
if($user_<=0){header('Location: ?');exit();}
if(!$sum){header('Location: ?');exit();}
if($sum<=0){header('Location: ?');exit();}

if($sum==10){$gold=100;}
if($sum==20){$gold=200;}
if($sum==50){$gold=500;}
if($sum==100){$gold=1000;}
if($sum==500){$gold=5000;}
if($sum==1000){$gold=10000;}

if($gold == 100){$bonus = (3);}
if($gold == 200){$bonus = (5);}
if($gold == 500){$bonus = (25);}
if($gold == 1000){$bonus = (75);}
if($gold == 5000){$bonus = (500);}
if($gold == 10000){$bonus = (1250);}

$res = $mysqli->query('SELECT * FROM `users` WHERE `id` = '.$user_.' LIMIT 1');
$user_p = $res->fetch_assoc();

$res = $mysqli->query('SELECT * FROM `prom` WHERE `id` = "1" LIMIT 1');
$prom = $res->fetch_assoc();


####################################################################################
$id_miss = 5;$prog_max = 100;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user_p['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().'  limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){
$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "'.$gold.'" WHERE `user` = '.$user_p['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
####################################################################################

####################################################################################
$id_miss = 18;$prog_max = 500;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user_p['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().'  limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){
$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "'.$gold.'" WHERE `user` = '.$user_p['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
####################################################################################

####################################################################################
if($gold == 5000){$id_miss = 19;$prog_max = 5000;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user_p['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().'  limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){
$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "'.$gold.'" WHERE `user` = '.$user_p['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}}
####################################################################################



if($prom['time_1'] > time()){$act_1 = ($gold*$prom['act_1']/100);}elsE{$act_1 = 0;}
if($prom['time_4'] > time()){$silver = ($gold*$prom['act_4']/100);}elsE{$silver = 0;}


$res = $mysqli->query("SELECT COUNT(*) FROM `ref` WHERE `ank` = ".$user_p['id']." ");
$ref = $res->fetch_array(MYSQLI_NUM);
if($ref['ank'] == $user_p['id']){
$mysqli->query('UPDATE `users` SET `gold` = `gold` + '.($gold*20/100).' WHERE `id` = '.$ref['user'].' LIMIT 1');
$referals = $ref['user'];
}else{
$referals = 0;
}


$gold = ($gold+$act_1);
$mysqli->query('UPDATE `users` SET `gold` = `gold` + '.($gold+$bonus).', `silver` = `silver` + '.($silver).' WHERE `id` = '.$user_p['id'].' LIMIT 1');
//$mysqli->query('INSERT INTO `worldkassa` SET `time_oplata` = "'.time().'", `suma` = "'.$sum.'", `id_user` = "'.$user_p['id'].'", `referals` = "'.$referals.'"');


$message = "<span class='admin'><p>Здравствуйте, ".$user_p['login']."! Вы получили: ".($gold+$bonus)." золота<br></p></span>";
$res = $mysqli->query('SELECT * FROM `dialog` WHERE ((`user` = 2 and `ank` = '.$user_p['id'].') or (`user` = '.$user_p['id'].' and `ank` = 2)) ');
$dialog = $res->fetch_assoc();
if(!$dialog){
$mysqli->query('INSERT INTO `dialog` SET `user` = "2", `ank` = "'.$user_p['id'].'", `time` = "'.time().'" ');
$uid = mysqli_insert_id($mysqli);
$mysqli->query('INSERT INTO `pm` SET `dialog` = "'.$uid.'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$user_p['id'].'" ');
$mysqli->query('INSERT INTO `pm_copy` SET `dialog` = "'.$uid.'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$user_p['id'].'" ');
}else{
$mysqli->query('INSERT INTO `pm` SET `dialog` = "'.$dialog['id'].'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$user_p['id'].'" ');
$mysqli->query('INSERT INTO `pm_copy` SET `dialog` = "'.$dialog['id'].'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$user_p['id'].'" ');
$mysqli->query('UPDATE `dialog` SET `time` = "'.time().'" WHERE `id` = "'.$dialog['id'].'" LIMIT 1');
}
$_SESSION['ok'] = '<center>Платеж на '.$sum.' руб выданы игроку '.nick($user_).'<br> Выдано '.($gold+$bonus).' золота.</center>';
header('location:?');
exit();
}


















if($id>0){
// выводим его платежи
}


require_once ('../system/footer.php');
?>