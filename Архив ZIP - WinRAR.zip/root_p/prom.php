<?php
$title = 'Админ панель';
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id'] or $user['position'] < 4) {
header('Location: /');
exit();
}
$res = $mysqli->query('SELECT * FROM `prom` WHERE `id` = "1" ');
$prom = $res->fetch_assoc();

echo '<div class="white medium bold cntr mb2">Управление акциями</div>';
















if($prom['time_1']>time()){$act_1__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_1'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Бонус золота при покупке '.$act_1__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_1']>time()){
echo '<span>'._time($prom['time_1']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_1" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_1" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_1_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_1_'])) {
$act_1 = strong($_POST['act_1']);
$time_1 = strong($_POST['time_1']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_1']>time()){
$mysqli->query('UPDATE `prom` SET `act_1` = "0", `time_1` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_1)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_1)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_1` = "'.$act_1.'", `time_1` = "'.(time()+($time_1*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}














if($prom['time_2']>time()){$act_2__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_2'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Бонус опыта '.$act_2__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_2']>time()){
echo '<span>'._time($prom['time_2']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_2" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_2" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_2_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_2_'])) {
$act_2 = strong($_POST['act_2']);
$time_2 = strong($_POST['time_2']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_2']>time()){
$mysqli->query('UPDATE `prom` SET `act_2` = "0", `time_2` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_2)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_2)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_2` = "'.$act_2.'", `time_2` = "'.(time()+($time_2*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}














if($prom['time_3']>time()){$act_3__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_3'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Скида на тренировку '.$act_3__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_3']>time()){
echo '<span>'._time($prom['time_3']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_3" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_3" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_3_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_3_'])) {
$act_3 = strong($_POST['act_3']);
$time_3 = strong($_POST['time_3']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_3']>time()){
$mysqli->query('UPDATE `prom` SET `act_3` = "0", `time_3` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_3)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_3)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_3` = "'.$act_3.'", `time_3` = "'.(time()+($time_3*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}

















if($prom['time_4']>time()){$act_4__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_4'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Бонус серебра при покупке '.$act_4__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_4']>time()){
echo '<span>'._time($prom['time_4']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_4" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_4" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_4_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_4_'])) {
$act_4 = strong($_POST['act_4']);
$time_4 = strong($_POST['time_4']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_4']>time()){
$mysqli->query('UPDATE `prom` SET `act_4` = "0", `time_4` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_4)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_4)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_4` = "'.$act_4.'", `time_4` = "'.(time()+($time_4*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}


















if($prom['time_5']>time()){$act_5__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_5'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Скидка на базу '.$act_5__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_5']>time()){
echo '<span>'._time($prom['time_5']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_5" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_5" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_5_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_5_'])) {
$act_5 = strong($_POST['act_5']);
$time_5 = strong($_POST['time_5']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_5']>time()){
$mysqli->query('UPDATE `prom` SET `act_5` = "0", `time_5` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_5)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_5)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_5` = "'.$act_5.'", `time_5` = "'.(time()+($time_5*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}








if($prom['time_6']>time()){$act_6__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_6'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Скидка на умения '.$act_6__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_6']>time()){
echo '<span>'._time($prom['time_6']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_6" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_6" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_6_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_6_'])) {
$act_6 = strong($_POST['act_6']);
$time_6 = strong($_POST['time_6']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_6']>time()){
$mysqli->query('UPDATE `prom` SET `act_6` = "0", `time_6` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_6)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_6)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_6` = "'.$act_6.'", `time_6` = "'.(time()+($time_6*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}














if($prom['time_7']>time()){$act_7__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_7'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Новогодняя ёлка '.$act_7__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_7']>time()){
echo '<span>'._time($prom['time_7']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_7" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_7" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_7_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_7_'])) {
$act_7 = strong($_POST['act_7']);
$time_7 = strong($_POST['time_7']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_7']>time()){
$mysqli->query('UPDATE `prom` SET `act_7` = "0", `time_7` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_7)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_7)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_7` = "'.$act_7.'", `time_7` = "'.(time()+($time_7*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
$mysqli->query('DELETE FROM `prom_elka_user` WHERE `id` ');
$mysqli->query('DELETE FROM `prom_elka_log` WHERE `id` ');
header('Location: ?');
exit();
}













if($prom['time_8']>time()){$act_8__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_8'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Cкидка на экипаж '.$act_8__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_8']>time()){
echo '<span>'._time($prom['time_8']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_8" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_8" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_8_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_8_'])) {
$act_8 = strong($_POST['act_8']);
$time_8 = strong($_POST['time_8']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_8']>time()){
$mysqli->query('UPDATE `prom` SET `act_8` = "0", `time_8` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_8)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_8)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_8` = "'.$act_8.'", `time_8` = "'.(time()+($time_8*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}













if($prom['time_9']>time()){$act_9__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_9'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Скидка на улучшения '.$act_9__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_9']>time()){
echo '<span>'._time($prom['time_9']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_9" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_9" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_9_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_9_'])) {
$act_9 = strong($_POST['act_9']);
$time_9 = strong($_POST['time_9']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_9']>time()){
$mysqli->query('UPDATE `prom` SET `act_9` = "0", `time_9` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_9)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_9)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_9` = "'.$act_9.'", `time_9` = "'.(time()+($time_9*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}












if($prom['time_10']>time()){$act_10__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_10'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Скидка на апгрейд '.$act_10__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_10']>time()){
echo '<span>'._time($prom['time_10']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_10" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_10" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_10_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_10_'])) {
$act_10 = strong($_POST['act_10']);
$time_10 = strong($_POST['time_10']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_10']>time()){
$mysqli->query('UPDATE `prom` SET `act_10` = "0", `time_10` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_10)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_10)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_10` = "'.$act_10.'", `time_10` = "'.(time()+($time_10*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}















if($prom['time_11']>time()){$act_11__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_11'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Скидка на модификацию '.$act_11__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_11']>time()){
echo '<span>'._time($prom['time_11']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_11" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_11" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_11_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_11_'])) {
$act_11 = strong($_POST['act_11']);
$time_11 = strong($_POST['time_11']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_11']>time()){
$mysqli->query('UPDATE `prom` SET `act_11` = "0", `time_11` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_11)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_11)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_11` = "'.$act_11.'", `time_11` = "'.(time()+($time_11*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}














if($prom['time_12']>time()){$act_12__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_12'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Скидка на усиления '.$act_12__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_12']>time()){
echo '<span>'._time($prom['time_12']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_12" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_12" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_12_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_12_'])) {
$act_12 = strong($_POST['act_12']);
$time_12 = strong($_POST['time_12']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_12']>time()){
$mysqli->query('UPDATE `prom` SET `act_12` = "0", `time_12` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_12)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_12)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_12` = "'.$act_12.'", `time_12` = "'.(time()+($time_12*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}














if($prom['time_13']>time()){$act_13__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_13'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Скидка на боевую подготовку '.$act_13__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_13']>time()){
echo '<span>'._time($prom['time_13']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_13" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_13" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_13_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_13_'])) {
$act_13 = strong($_POST['act_13']);
$time_13 = strong($_POST['time_13']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_13']>time()){
$mysqli->query('UPDATE `prom` SET `act_13` = "0", `time_13` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_13)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_13)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_13` = "'.$act_13.'", `time_13` = "'.(time()+($time_13*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}














if($prom['time_14']>time()){$act_14__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_14'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Скидка на военное управление '.$act_14__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_14']>time()){
echo '<span>'._time($prom['time_14']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_14" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_14" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_14_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_14_'])) {
$act_14 = strong($_POST['act_14']);
$time_14 = strong($_POST['time_14']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_14']>time()){
$mysqli->query('UPDATE `prom` SET `act_14` = "0", `time_14` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_14)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_14)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_14` = "'.$act_14.'", `time_14` = "'.(time()+($time_14*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}















if($prom['time_15']>time()){$act_15__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_15'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Больше золота за миссии '.$act_15__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_15']>time()){
echo '<span>'._time($prom['time_15']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_15" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_15" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_15_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_15_'])) {
$act_15 = strong($_POST['act_15']);
$time_15 = strong($_POST['time_15']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_15']>time()){
$mysqli->query('UPDATE `prom` SET `act_15` = "0", `time_15` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_15)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_15)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_15` = "'.$act_15.'", `time_15` = "'.(time()+($time_15*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}















if($prom['time_16']>time()){$act_16__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_16'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Бонусные баки топлива '.$act_16__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_16']>time()){
echo '<span>'._time($prom['time_16']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_16" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_16" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_16_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_16_'])){
$act_16 = strong($_POST['act_16']);
$time_16 = strong($_POST['time_16']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_16']>time()){
$mysqli->query('UPDATE `prom` SET `act_16` = "0", `time_16` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_16)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_16)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_16` = "'.$act_16.'", `time_16` = "'.(time()+($time_16*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}















if($prom['time_17']>time()){$act_17__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_17'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Больше опыта в бою '.$act_17__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_17']>time()){
echo '<span>'._time($prom['time_17']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_17" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_17" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_17_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_17_'])) {
$act_17 = strong($_POST['act_17']);
$time_17 = strong($_POST['time_17']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_17']>time()){
$mysqli->query('UPDATE `prom` SET `act_17` = "0", `time_17` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_17)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_17)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_17` = "'.$act_17.'", `time_17` = "'.(time()+($time_17*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}














if($prom['time_18']>time()){$act_18__ = '<font color="green1" style="opacity:0.7;">('.$prom['act_18'].'%)</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Больше серебра в бою	 '.$act_18__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_18']>time()){
echo '<span>'._time($prom['time_18']-time()).'</span><br>';
}else{
echo '% <input w:id="newLogin" type="text" name="act_18" value="50"% class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_18" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_18_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_18_'])) {
$act_18 = strong($_POST['act_18']);
$time_18 = strong($_POST['time_18']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_18']>time()){
$mysqli->query('UPDATE `prom` SET `act_18` = "0", `time_18` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_18)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_18)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_18` = "'.$act_18.'", `time_18` = "'.(time()+($time_18*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}












if($prom['time_19']>time()){$act_19__ = '<font color="green1" style="opacity:0.7;">(множ награды: х'.$prom['act_19'].')</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Игра в снежки+турнир '.$act_19__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_19']>time()){
echo '<span>'._time($prom['time_19']-time()).'</span><br>';
}else{
echo 'множ награды <input w:id="newLogin" type="text" name="act_19" value="1" class="fld-chng" size="10" maxlength="32">
дней: <input w:id="newLogin" type="text" name="time_19" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_19_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_19_'])) {
$act_19 = strong($_POST['act_19']);
$time_19 = strong($_POST['time_19']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_19']>time()){
$mysqli->query('UPDATE `prom` SET `act_19` = "0", `time_19` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
}elsE{
if(empty($act_19)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_19)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `act_19` = "'.$act_19.'", `time_19` = "'.(time()+($time_19*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}










if($prom['time_20']>time()){$act_20__ = '<font color="green1" style="opacity:0.7;">(множ награды: х'.$prom['act_20'].')</font>';$color = 'red';$submit = 'Выключить';}else{$color = 'green';$submit = 'Включить';}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="small bold white sh_b">Боевые задачи '.$act_20__.'</div><div class="dhr a_w50 mt5 mb5"></div>
<div class="fight center">
<form w:id="loginForm" id="id2" method="post" action="">
<div style="width:0px;height:0px;position:absolute;left:-100px;top:-100px;overflow:hidden"><input type="hidden" name="id2_hf_0" id="id2_hf_0"></div>';
if($prom['time_20']>time()){
echo '<span>'._time($prom['time_20']-time()).'</span><br>';
}else{
echo '
Тип БЗ <br><select style="width: 50%;" name="tip_20">
<option selected="selected" value="1">Пасхальная БЗ</option>
</select><br><div class="mt5"></div>
Множ награды <input w:id="newLogin" type="text" name="act_20" value="1" class="fld-chng" size="10" maxlength="32">
Дней: <input w:id="newLogin" type="text" name="time_20" value="1" class="fld-chng" size="10" maxlength="32"><br>';
}
echo '</div>
<div class="bot"><span class="input-but border '.$color.'"><span><input class="w100" type="submit" name="act_20_" w:message="value:SettingsPage.changeProm" value="'.$submit.'"></span></span></div>
</form>
</div>
</div></div></div></div></div></div></div></div></div></div><br>';
if(isset($_REQUEST['act_20_'])) {
$act_20 = strong($_POST['act_20']);
$time_20 = strong($_POST['time_20']);
$tip_20 = strong($_POST['tip_20']);
if($user['position'] < 4){header('Location: ?');exit();}
if($prom['time_20']>time()){
$mysqli->query('UPDATE `prom` SET `tip_20` = "0", `act_20` = "0", `time_20` = "0" WHERE `id` = '.$prom['id'].' LIMIT 1');
$mysqli->query('DELETE FROM `bz_user` WHERE `id` ');
}elsE{
if(empty($act_20)){header('Location: ?');$_SESSION['err'] = 'Поле "%" обязательно';exit();}
if(empty($time_20)){header('Location: ?');$_SESSION['err'] = 'Поле "дней" обязательно';exit();}
$mysqli->query('UPDATE `prom` SET `tip_20` = "'.$tip_20.'", `act_20` = "'.$act_20.'", `time_20` = "'.(time()+($time_20*86400)).'" WHERE `id` = '.$prom['id'].' LIMIT 1');
}
header('Location: ?');
exit();
}
























require_once ('../system/footer.php');
?>