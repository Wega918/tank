<?php
$title = 'Битвы';
require_once ('../system/function.php');

/* 
if($user['id'] !=1){
$_SESSION['err'] = 'Техработы...';
header('Location: /');
exit();
}
 */

?>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<meta name="Keywords" content="Танки, игры, RPG, MMORPG, онлайн игра, онлайн, wap, бесплатно, играть онлайн, ролевые игры, лучшие онлайн игры, браузерная игра, сражения, бои, турниры, задания, битвы, поле боя">
<meta name="google" content="notranslate">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Танки">
<meta property="og:title" content="Танки">
<meta property="og:description" content="Погрузись в мир танков, учавствуй в легендарных сражениях, покажи на что ты способен!">
<meta property="og:url" content="<?=$HOME?>">
<meta property="og:locale" content="ru_RU">
<meta property="og:image" content="/images/logo.jpg">
<meta property="og:image:width" content="2560">
<meta property="og:image:height" content="1024">
<link rel="icon" href="/favicon.ico" type="image/png">
<link rel="stylesheet" type="text/css" href="/diz.css"><title>Танки</title>
</head>
<body>


<?

if (isset($_SESSION['ok'])){
?>
<?=$_SESSION['ok']?>
<?php
unset($_SESSION['ok']);
}







if(!$user['id']){
header('Location: /');
exit();
}




/* // Создаем временную таблицу для хранения идентификаторов строк с максимальным prog
$query = "CREATE TEMPORARY TABLE TempTable AS
    SELECT id_miss, MAX(prog) AS max_prog1
    FROM missions_user
    GROUP BY id_miss";

if ($mysqli->query($query)) {
    // Удаляем строки из missions_user, которые не имеют максимального prog
    $query = "DELETE FROM missions_user
        WHERE (id_miss, prog) NOT IN (SELECT id_miss, max_prog1 FROM TempTable)";

    if ($mysqli->query($query)) {
        echo "Дубликаты удалены успешно.";
    } else {
        echo "Ошибка выполнения запроса DELETE: " . $mysqli->error;
    }

    // Удаляем временную таблицу
    $query = "DROP TEMPORARY TABLE IF EXISTS TempTable";
    $mysqli->query($query);
} else {
    echo "Ошибка создания временной таблицы: " . $mysqli->error;
}

$mysqli->close();

 */



/* // Создаем временную таблицу для хранения идентификаторов строк с максимальным prog
$query = "CREATE TEMPORARY TABLE TempTable AS
    SELECT id_miss, MAX(prog) AS max_prog
    FROM missions_user
    GROUP BY id_miss";

if ($mysqli->query($query)) {
    // Удаляем строки из missions_user, которые не имеют максимального prog
    $query = "DELETE FROM missions_user
        WHERE (id_miss, prog) NOT IN (SELECT id_miss, max_prog FROM TempTable)";

    if ($mysqli->query($query)) {
        echo "Дубликаты удалены успешно.";
    } else {
        echo "Ошибка выполнения запроса DELETE: " . $mysqli->error;
    }

    // Удаляем временную таблицу
    $query = "DROP TEMPORARY TABLE IF EXISTS TempTable";
    $mysqli->query($query);
} else {
    echo "Ошибка создания временной таблицы: " . $mysqli->error;
}

$mysqli->close();

 */




/* // Запрос для удаления дубликатов, оставляя строки с наибольшим значением prog
$query = "DELETE mu1 FROM missions_user mu1
    JOIN (
        SELECT id_miss, MAX(prog) AS max_prog_value
        FROM missions_user
        GROUP BY id_miss
    ) mu2
    ON mu1.id_miss = mu2.id_miss AND mu1.prog < mu2.max_prog_value";

if ($mysqli->query($query)) {
    echo "Дубликаты удалены успешно.";
} else {
    echo "Ошибка выполнения запроса: " . $mysqli->error;
}

$mysqli->close();

 */











/* // Запрос для удаления дубликатов и сохранения строк с наибольшим значением prog
$query = "DELETE mu1 FROM missions_user mu1
    JOIN (
        SELECT id_miss, MAX(prog) AS max_prog
        FROM missions_user
        GROUP BY id_miss
    ) mu2
    ON mu1.id_miss = mu2.id_miss AND mu1.prog < mu2.max_prog";

if ($mysqli->query($query)) {
    echo "Дубликаты удалены успешно.";
} else {
    echo "Ошибка выполнения запроса: " . $mysqli->error;
}

$mysqli->close();

 */




/* 
// Запрос для удаления дубликатов
$query = "DELETE mu1 FROM missions_user mu1
    JOIN missions_user mu2
    ON mu1.id_miss = mu2.id_miss
    AND mu1.prog < mu2.prog";

if ($mysqli->query($query)) {
   // echo "Дубликаты удалены успешно.";
} else {
    echo "Ошибка выполнения запроса: " . $mysqli->error;
}

$mysqli->close();




 */


/* $res = $mysqli->query("SELECT COUNT(*) FROM `missions_user` WHERE `user` = '".$user['id']."' and `id_miss` = '28' ");
$miss28 = $res->fetch_array(MYSQLI_NUM);
if($miss28[0]>1){ */

// Запрос для удаления всех таблиц, кроме той, в которой "prog" максимальное
/* $query = "SET @max_prog = (SELECT MAX(prog) FROM (SELECT prog FROM information_schema.tables WHERE table_schema = 'frankom8_mtank' AND missions_user LIKE 'your_prefix%') AS p);
    SELECT GROUP_CONCAT('DROP TABLE IF EXISTS `', missions_user, '`;') AS sql_statements
    FROM information_schema.tables WHERE table_schema = 'frankom8_mtank' AND missions_user LIKE 'your_prefix%' AND prog < @max_prog AND user < ".$user['id']."";

if ($mysqli->multi_query($query)) {
    do {
        if ($result = $mysqli->store_result()) {
            while ($row = $result->fetch_row()) {
                $sql_statements = $row[0];
                $mysqli->multi_query($sql_statements);
                echo "Таблицы удалены.";
            }
            $result->free();
        }
    } while ($mysqli->more_results() && $mysqli->next_result());
} else {
    echo "Ошибка выполнения запроса: " . $mysqli->error;
}

$mysqli->close();


 */



/* $mysqli->query("DELETE FROM `pvp_user` WHERE `bot` = '1' and `pvp_id` = ".$p_u['pvp_id']." ");


} */











$res = $mysqli->query('SELECT * FROM `traning` WHERE `user` = "'.$user['id'].'" ');
$traning = $res->fetch_assoc();

$res1 = $mysqli->query('SELECT * FROM `settings` WHERE `id` = "1" ');
$sql = $res1->fetch_assoc();

$res = $mysqli->query('SELECT * FROM `pvp_user` WHERE `user` = "'.$user['id'].'" ');
$p_u = $res->fetch_assoc();

$res = $mysqli->query('SELECT * FROM `pvp` WHERE `id` = "'.$p_u['pvp_id'].'" ');
$p = $res->fetch_assoc();

if($p_u and !$p){$mysqli->query('DELETE FROM `pvp_user` WHERE `bot` = "1" and `pvp_id` = "'.$p_u['pvp_id'].'"');$mysqli->query('DELETE FROM `pvp_user` WHERE `user` = "'.$user['id'].'" ');}

if($user['pvp_tip']==1){$col_user = 2;}if($user['pvp_tip']==2){$col_user = 5;}if($user['pvp_tip']==3){$col_user = 10;}







################### Подготовленные запросы ###################



### применяем противника себе
$stmt2 = $mysqli->prepare('UPDATE `pvp_user` SET `goal` = ? WHERE `id` = ? LIMIT 1');
$stmt2->bind_param("ss", $goal,$id_us);

### подбор противника
$stmt1 = $mysqli->prepare('SELECT t.id FROM pvp_user as t,
            (SELECT ROUND((SELECT MAX(id) FROM pvp_user) * rand()) as rnd FROM pvp_user) tmp
            WHERE t.id >= (rnd) and `user` != ? and `pvp_id` = ? and `p` > ? 
			ORDER BY camouflage asc 
			LIMIT 1');
$stmt1->bind_param("sss", $user_res,$pvp_id,$hp);


###############################################################################################################################################
###############################################################################################################################################
if(($p['time_battle']>=time() && $p['time_battle']<=(time()+600)) or ($p['time_battle']>=time() && $p['time_battle']<=(time()+time()))){ // бой начинается, распределяем врагов кому еще не распределило
$pvp_us = $mysqli->query('SELECT * FROM `pvp_user` WHERE `pvp_id` = "'.$p_u['pvp_id'].'" and `p` > "0" ORDER BY `id` desc LIMIT '.$col_user.'');
while ($pvu = $pvp_us->fetch_array()){
if($pvu['goal']==0){
$user_res = $pvu['user'];$pvp_id = $p_u['pvp_id'];$hp = 0;$stmt1->execute();$res = $stmt1->get_result();$goal_ = $res->fetch_assoc(); 
$goal = $goal_['id'];$id_us = $pvu['id'];$stmt2->execute();
//echo ''.$goal['id'].'<hr>';
}
}
header('Location: /pvp/battle/');
exit();
}
###############################################################################################################################################
###############################################################################################################################################







###############################################################################################################################################
###############################################################################################################################################
if($p['time_battle']<time() and $p['time_battle']>0){
$mysqli->query('DELETE FROM `pvp` WHERE `id` = "'.$p_u['pvp_id'].'" ');
$mysqli->query('DELETE FROM `pvp_user` WHERE `user` = "'.$user['id'].'" ');
header('Location: /pvp/');
exit();
}
###############################################################################################################################################
###############################################################################################################################################







$res211 = $mysqli->query('SELECT * FROM `pvp_results` WHERE `user` = "'.$user['id'].'" and `time` > "0" ORDER BY `pvp_id` desc LIMIT 1');
$pvp_res = $res211->fetch_assoc();
//echo ''.$pvp_res['id'].'';


if($pvp_res){
$col_u_ = $mysqli->query("SELECT COUNT(*) FROM `pvp_results` WHERE `pvp_id` = ".$pvp_res['pvp_id']."  ");
$col_u = $col_u_->fetch_array(MYSQLI_NUM);
}




if($user['pvp_rate']<1749){$p_r = 0;$p_r_ = 1749;$img = 1;$pvp_name = 'кадетов';}
if($user['pvp_rate']>=1749 && $user['pvp_rate']<=1999){$p_r = 1750;$p_r_ = 1999;$img = 2;$pvp_name = 'рядовых';}
if($user['pvp_rate']>=1999 && $user['pvp_rate']<=2249){$p_r = 2000;$p_r_ = 2249;$img = 3;$pvp_name = 'сержантов';}
if($user['pvp_rate']>=2249 && $user['pvp_rate']<=2499){$p_r = 2250;$p_r_ = 2499;$img = 4;$pvp_name = 'лейтенантов';}
if($user['pvp_rate']>=2499 && $user['pvp_rate']<=2749){$p_r = 2500;$p_r_ = 2749;$img = 5;$pvp_name = 'старших лейтенантов';}
if($user['pvp_rate']>=2749 && $user['pvp_rate']<=2999){$p_r = 2750;$p_r_ = 2999;$img = 6;$pvp_name = 'капитанов';}
if($user['pvp_rate']>=2999 && $user['pvp_rate']<=3249){$p_r = 3000;$p_r_ = 3249;$img = 7;$pvp_name = 'майоров';}
if($user['pvp_rate']>=3249 && $user['pvp_rate']<=3499){$p_r = 3250;$p_r_ = 3499;$img = 8;$pvp_name = 'подполковников';}
if($user['pvp_rate']>=3499){$p_r = 3500;$p_r_ = 3749;$img = 9;$pvp_name = 'полковников';}






//if($user['pvp_rate']<=2500){
if($p['time_bot']<=time() and (($p['col_user'])<$col_user)){
$stmt = $mysqli->prepare('SELECT t.id FROM users as t,
            (SELECT ROUND((SELECT MAX(id) FROM users) * rand()) as rnd FROM users) tmp
            WHERE t.id >= (rnd) and `pvp_rate` < ? and `viz` <= ? and `id` not in (select user from pvp_user)
			LIMIT 1');
$stmt->bind_param("ss", $p_r,$viz);
$p_r = 2500;$viz = (time()-(1800));$stmt->execute();$res = $stmt->get_result();$rnd_us = $res->fetch_assoc(); 
if($rnd_us){
$res = $mysqli->query('SELECT id, p FROM `users_tanks` WHERE `user` = '.$rnd_us['id'].' and `active`  = "1" LIMIT 1');
$rnd_ta = $res->fetch_assoc();
if($rnd_ta and $p['id']){
if(($p['col_user']+1)>=$col_user){
$mysqli->query('UPDATE `pvp` SET `time_bot` =  "'.(time()+rand(1,5)).'", `col_user` = `col_user` + "1", `time_attack_assault` = "'.(time()+185).'", `time_battle` = "'.(time()+605).'" WHERE `id` = "'.$p['id'].'" LIMIT 1');
}elsE{
$mysqli->query('UPDATE `pvp` SET `time_bot` =  "'.(time()+rand(1,5)).'", `col_user` = `col_user` + "1" WHERE `id` = "'.$p['id'].'" LIMIT 1');
}
$mysqli->query('INSERT INTO `pvp_user` SET `bot` = "1", `tank_id` = "'.$rnd_ta['id'].'", `p` = "'.($rnd_ta['p']*2).'", `pvp_id` = "'.$p['id'].'", `user` = "'.$rnd_us['id'].'" ');
$mysqli->query('INSERT INTO `pvp_results` SET `user` = "'.$rnd_us['id'].'", `rate` =  "0", `pvp_id` = "'.$p['id'].'", `number` = "0" ');
}
}
}
//}



if($p['col_user']>=$col_user and $p['time_battle']==0){
$mysqli->query('UPDATE `pvp` SET `time_attack_assault` = '.(time()+185).', `time_battle` = "'.(time()+605).'" WHERE `id` = '.$p['id'].' LIMIT 1');
}














if($col_u[0]==$col_user and $p_u and !($p['time_battle']>=time() && $p['time_battle']<=(time()+605)) and !($p['time_battle']==0 and $p['col_user']>0) ){
echo '<div class="buy-place-block"><div class="feedbackPanelINFO"><div class="line1"><span class="feedbackPanelINFO">Подсчитываются результаты</span></div></div></div> ';
echo '<a w:id="refreshLink" href="?" class="simple-but"><span><span>Обновить</span></span></a>';
}




/* 2324-1458=866*100/2324=37/(37/10)=10
2324-1243=1081*100/2324=46/(46/(46/10))=4.6
2324-1000=1324*100/2324=57/(57/(57/10))=5.7
 */
 
 
 // если он больше меня и я его убил
/* echo '
'.ceil(sqrt( ((1972-(1600-1972))*100/1600)  *  (((1972-1600))*100/1600) )).'<br>
'.ceil(sqrt( ((4000-(2500-4000))*100/2500)  *  (((4000-2500))*100/2500) )).'<br>
'.ceil(sqrt( ((4000-(2324-4000))*100/2324)  *  (((4000-2324))*100/2324) )).'<br>
'.ceil(sqrt( ((3000-(2324-3000))*100/2324)  *  (((3000-2324))*100/2324) )).'<br>
'.ceil(sqrt( ((2500-(2324-2500))*100/2324)  *  (((2500-2324))*100/2324) )).'<br>
'.ceil(sqrt( ((2325-(2324-2325))*100/2324)  *  (((2325-2324))*100/2324) )).'<br>
<hr>
'.ceil(sqrt( ((1972-(1972-1600))*100/1600)  -  (((1972-1600))*100/1600) )).'<br>
'.ceil(sqrt( ((4000-(4000-2500))*100/2500)  -  (((4000-2500))*100/2500) )).'<br>
'.ceil(sqrt( ((4000-(4000-2324))*100/2324)  -  (((4000-2324))*100/2324) )).'<br>
'.ceil(sqrt( ((3000-(3000-2324))*100/2324)  -  (((3000-2324))*100/2324) )).'<br>
'.ceil(sqrt( ((2500-(2500-2324))*100/2324)  -  (((2500-2324))*100/2324) )).'<br>
'.ceil(sqrt( ((2325-(2325-2324))*100/2324)  -  (((2325-2324))*100/2324) )).'<br>
'; */
// если он меньше меня и я его убил 




echo '<div class="p5">';
if($p['time_battle']>=time() && $p['time_battle']<=(time()+605)){
echo '<div class="buy-place-block"><div class="feedbackPanelINFO"><div class="line1"><span class="feedbackPanelINFO">До начала боя: '.tls($p['time_battle']-(time()+600)).' секунд</span></div></div></div>';
}/* elseif($p['time_battle']>=time() && $p['time_battle']<=(time()+600)){
echo '<div class="buy-place-block"><div class="feedbackPanelINFO"><div class="line1"><span class="feedbackPanelINFO">До начала боя: '.tls($p['time_battle']-(time()+600)).' секунд</span></div></div></div>';
} */




if($user['pvp_rate']<2500){
echo '<div class="medium bold mb0 cntr green1"><img src="/images/icons/victory.png"> Битва чемпионов <img src="/images/icons/victory.png"></div>';
echo '<div class="mt0 mb5 small gray1 cntr">Танкисты с рейтингом до 2500</div>';
}elsE{
//echo '<a w:id="refreshLink" href="?" class="simple-but"><span><span>Обновить</span></span></a>';
}



echo '<img width="100%" w:id="logo" src="/images/war3.png">';
echo '<div class="mt3"></div>';



if($p_u and $p['time_battle']==0 and $p['col_user']>0){
echo '<div class="white small bold sh_b mb5 cntr"><span w:id="queueStatusLabel">Танков в очереди: '.$p['col_user'].' из '.$col_user.'</span></div>
<div class="dhr a_w50 mt5 mb5"></div>';
}elseif($col_u[0]==$col_user and !$p_u){
echo '<div class="small bold sh_b mb1 cntr green2">Результаты</div>';
echo '<div class="small bold cntr gray1 sh_b mb5">';
$resR = $mysqli->query('SELECT * FROM `pvp_results` WHERE `pvp_id` = "'.$pvp_res['pvp_id'].'" ORDER BY `rate` desc, `number` asc LIMIT 10');
while ($setRes = $resR->fetch_array()){

$res = $mysqli->query('SELECT * FROM `users` WHERE `id` = "'.$setRes['user'].'" ');
$us_ank = $res->fetch_assoc();
$res2 = $mysqli->query('SELECT * FROM `traning` WHERE `user` = "'.$us_ank['id'].'" ');
$traning = $res2->fetch_assoc();
if($us_ank['side'] == 1){$side = 'federation';}else{$side = 'empire';}
if($us_ank['viz'] > (time()-$sql['online'])){$viz = '';}else{$viz = '_off';}
if($setRes['rate']>0){$fols = '+';$color = 'green1';}else{$fols = '';$color = 'red1';}
echo '<a href="/profile/'.$setRes['user'].'/">
<img class="vb" height="14" width="14" src="/images/side/'.$side.'/'.$traning['rang'].''.$viz.'.png?1">
 <span class="yellow1">'.$us_ank['login'].'</span></a>: <span class="'.$color.'">'.$fols.''.$setRes['rate'].'</span> ('.$us_ank['pvp_rate'].')
<br>';
}
echo '</div>';
echo '<div class="dhr a_w50 mt5 mb5"></div>';
}

echo '<div class="white small bold sh_b mt5 mb5 cntr">Мой рейтинг: '.$user['pvp_rate'].' из '.$p_r_.'<br><img class="vb" w:id="pDivImg" src="/images/pvp/'.$img.'.png"> Лига '.$pvp_name.'</div>';
if(!$p_u or !$p){
echo '<a w:id="joinLink" href="?start" class="simple-but border"><span><span>Участвовать в битве</span></span></a>';
}else{
echo '<a w:id="refreshLink" href="?" class="simple-but"><span><span>Обновить</span></span></a>';
if($p_u and $p['time_battle']==0 and $p['col_user']>0){
echo '<meta http-equiv="Refresh" content="1" />
<a w:id="leaveLink" href="?exit" class="simple-but gray"><span><span>Отказаться от битвы</span></span></a>';
}
}



echo '<div class="mt5 mb5 small green1 cntr">';
if($user['pvp_tip']==1){echo 'битва с противником один на один.';}
if($user['pvp_tip']==2){echo '"каждый сам за себя" в комнате из 5 танкистов.';}
if($user['pvp_tip']==3){echo '"каждый сам за себя" в комнате из 10 танкистов.';}
echo '</div>';

if(isset($_GET['1'])){if($p_u){header('Location: ?');exit();}$mysqli->query('UPDATE `users` SET `pvp_tip` = "1" WHERE `id` = '.$user['id'].' LIMIT 1');header('Location: ?');exit();}
if(isset($_GET['2'])){if($p_u){header('Location: ?');exit();}$mysqli->query('UPDATE `users` SET `pvp_tip` = "2" WHERE `id` = '.$user['id'].' LIMIT 1');header('Location: ?');exit();}
if(isset($_GET['3'])){if($p_u){header('Location: ?');exit();}$mysqli->query('UPDATE `users` SET `pvp_tip` = "3" WHERE `id` = '.$user['id'].' LIMIT 1');header('Location: ?');exit();}

if(!$p_u){
echo '<div class="mt3"></div><center><table><tbody><tr>';
if($user['pvp_tip']!=1){
echo '<td class="w33"><div style="position:relative;"><a class="simple-but green border mb1" href="?1"><span><span>Режим I</span></span></a></div></td>';
}else{
echo '<td class="w33"><div style="position:relative;"><a class="simple-but gray border mb1"><span><span>Режим I</span></span></a></div></td>';
}
if($user['pvp_tip']!=2){
echo '<td class="w33"><div style="position:relative;"><a class="simple-but green border mb1" href="?2"><span><span>Режим II</span></span></a></div></td>';
}else{
echo '<td class="w33"><div style="position:relative;"><a class="simple-but gray border mb1"><span><span>Режим II</span></span></a></div></td>';
}
if($user['pvp_tip']!=3){
echo '<td class="w33"><div style="position:relative;"><a class="simple-but green border mb1" href="?3"><span><span>Режим III</span></span></a></div></td>';
}else{
echo '<td class="w33"><div style="position:relative;"><a class="simple-but gray border mb1"><span><span>Режим III</span></span></a></div></td>';
}
echo '</tr></tbody></table></center>';
echo '<div class="mt5"></div>';
}













if($user['pvp_rate']<=2500){
$res = $mysqli->query('SELECT * FROM `pvp` WHERE `tip` = "'.$user['pvp_tip'].'" and `col_user` < "'.$col_user.'" and `rate_user` <= "2500" ');
$p1 = $res->fetch_assoc();
}else{
$res = $mysqli->query('SELECT * FROM `pvp` WHERE `tip` = "'.$user['pvp_tip'].'" and `col_user` < "'.$col_user.'" and `rate_user` > "2500" ');
$p1 = $res->fetch_assoc();
}










if(isset($_GET['start'])){
if($p_u){header('Location: ?');exit();}
$res = $mysqli->query('SELECT id, p FROM `users_tanks` WHERE `user` = '.$user['id'].' and `active`  = "1" LIMIT 1');
$u_t = $res->fetch_assoc();
$res1 = $mysqli->query('SELECT bon FROM `skills_user` WHERE `tip`  = "1" and `user`  = "'.$user['id'].'" ');
$skills_u = $res1->fetch_assoc();
$resb_s = $mysqli->query('SELECT tip, bon_col FROM `boevaya_sila` WHERE `user` = "'.$user['id'].'" and `local` = "1" limit 1');
$b_s = $resb_s->fetch_assoc();
if($b_s['tip']==1){$param = 50;}elseif($b_s['tip']==2){$param = 100;}elseif($b_s['tip']==3){$param = 150;}
if($b_s['bon_col'] >0 ){$p = $param;}else{$p = 0;}
if(!$p1 or $p1['col_user']>=$col_user or $p1['time_battle']>=time()){
$mysqli->query('INSERT INTO `pvp` SET `time_bot` = "'.(time()+rand(1,15)).'", `rate_user` = "'.$user['pvp_rate'].'", `time` = "'.time().'", `col_user` = "1", `tip` = "'.$user['pvp_tip'].'" ');
$uid = mysqli_insert_id($mysqli);
$mysqli->query('INSERT INTO `pvp_user` SET `camouflage` = "'.$skills_u['bon'].'", `tank_id` = '.$u_t['id'].', `p` = '.(($u_t['p']+$p)*2).', `pvp_id` = '.$uid.', `user` = '.$user['id'].' ');
$mysqli->query('INSERT INTO `pvp_results` SET `user` = "'.$user['id'].'", `rate` =  "0", `pvp_id` = "'.$uid.'", `number` = "0" ');
}else{
if(($p1['col_user']+1)>=$col_user){
$mysqli->query('UPDATE `pvp` SET `col_user` = `col_user` + "1", `time_attack_assault` = '.(time()+185).', `time_battle` = "'.(time()+605).'" WHERE `id` = '.$p1['id'].' LIMIT 1');
}elsE{
$mysqli->query('UPDATE `pvp` SET `col_user` = `col_user` + "1" WHERE `id` = '.$p1['id'].' LIMIT 1');
}
$mysqli->query('INSERT INTO `pvp_user` SET `camouflage` = "'.$skills_u['bon'].'", `tank_id` = '.$u_t['id'].', `p` = '.(($u_t['p']+$p)*2).', `pvp_id` = '.$p1['id'].', `user` = '.$user['id'].' ');
$mysqli->query('INSERT INTO `pvp_results` SET `user` = "'.$user['id'].'", `rate` =  "0", `pvp_id` = "'.$p1['id'].'", `number` = "0" ');
}
header('Location: ?');
exit();
}







if(isset($_GET['exit'])){
if(!$p_u){$_SESSION['err'] = 'p_u';header('Location: ?');exit();}
if($p['col_user']>=$col_user){$_SESSION['col_user'] = 'p_u';header('Location: ?');exit();}
if($p['time_battle']>=time()){$_SESSION['time_battle'] = 'p_u';header('Location: ?');exit();}
if($col_u[0]==1 and $p['col_user']==$col_u[0]){
$mysqli->query('DELETE FROM `pvp_user` WHERE `pvp_id` = "'.$p['id'].'" ');
$mysqli->query('DELETE FROM `pvp_results` WHERE `pvp_id` = "'.$p['id'].'" ');
$mysqli->query('DELETE FROM `pvp` WHERE `id` = "'.$p_u['pvp_id'].'" ');
}elseif($col_u[0]>1 and $p['col_user']==$col_u[0]){
$mysqli->query('UPDATE `pvp` SET `col_user` = `col_user` - "1" WHERE `id` = '.$p['id'].' LIMIT 1');
$mysqli->query('DELETE FROM `pvp_results` WHERE `user` = "'.$user['id'].'" ');
$mysqli->query('DELETE FROM `pvp_user` WHERE `user` = "'.$user['id'].'" ');
}elseif($col_u[0]>1 and $p['col_user']!=$col_u[0]){
$mysqli->query('DELETE FROM `pvp_results` WHERE `pvp_id` = "'.$p['id'].'" ');
$mysqli->query('DELETE FROM `pvp_user` WHERE `pvp_id` = "'.$p['id'].'" ');
$mysqli->query('DELETE FROM `pvp` WHERE `id` = "'.$p_u['pvp_id'].'" ');
}elseif($col_u[0]>1 and $p['col_user']!=$col_u[0]){
$mysqli->query('DELETE FROM `pvp_results` WHERE `pvp_id` = "'.$p['id'].'" ');
$mysqli->query('DELETE FROM `pvp_user` WHERE `pvp_id` = "'.$p['id'].'" ');
$mysqli->query('DELETE FROM `pvp` WHERE `id` = "'.$p_u['pvp_id'].'" ');
}
//$_SESSION['err'] = 'ок';
header('Location: ?');
exit();
}






















$res = $mysqli->query('SELECT tip FROM `users_tanks` WHERE `user`  = "'.$user['id'].'" and `active`  = "1" limit 1');
$users_tanks = $res->fetch_assoc();

$res = $mysqli->query('SELECT country FROM `tanks` WHERE `id`  = "'.$users_tanks['tip'].'" limit 1');
$tanks = $res->fetch_assoc();

if($tanks['country']=='GERMANY'){$country = 1;}
if($tanks['country']=='SSSR'){$country = 2;}
if($tanks['country']=='USA'){$country = 3;}

####################################################################################
$res = $mysqli->query("SELECT COUNT(*) FROM `missions_user` WHERE `user` = ".$user['id']." and `tip` <= '2' and `country` = '".$country."' ");
$col = $res->fetch_array(MYSQLI_NUM);
$res = $mysqli->query("SELECT COUNT(*) FROM `missions_user` WHERE `user` = ".$user['id']." and `tip` <= '2' and `time` > ".time()." and `country` = '".$country."' ");
$k_post2 = $res->fetch_array(MYSQLI_NUM);

$max_miss = 21; // при изминении максимального кол-ва заданий необходимо откорректировать переменную еще в файле missions

if($col[0]<=1 and $k_post2[0]==0){
$limit = 1;
}elseif($col[0]==1 and $k_post2[0]==1){
$limit = 3;
}elseif($col[0]>=3 and $k_post2[0]>=3){
$limit = $max_miss;
}else{
$limit = 0;
}

if($col[0]<$max_miss){
$res = $mysqli->query('SELECT * FROM `missions` WHERE `tip` <= "2" and `prog` > "0" ORDER BY `id` asc limit '.$limit.'');
while ($i = $res->fetch_array()){//echo '1';
$res2 = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = "'.$user['id'].'" and `id_miss` = "'.$i['id'].'" and (`tip` = "1" or `id_miss` = "5" or `id_miss` = "6" or `id_miss` = "7" or `id_miss` = "8" or `id_miss` = "12" or `id_miss` = "13" )');
$mii = $res2->fetch_assoc();
if(!$mii){//echo '1';
$res1 = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = "'.$user['id'].'" and `id_miss` = "'.$i['id'].'" and `country` = "'.$country.'"  ');
$mi = $res1->fetch_assoc();//
if(!$mi){
$mysqli->query('INSERT INTO `missions_user` SET `user` = '.$user['id'].', `tip` = "'.$i['tip'].'" , `id_miss` = "'.$i['id'].'", `prog_max` = "'.$i['prog'].'", `country` = "'.$country.'" ');
}
}
}
}
####################################################################################














































// создание миссий
################################################################################################################
$res = $mysqli->query("SELECT COUNT(*) FROM `missions_user` WHERE `user` = ".$user['id']." and `tip` = '3' and `country` = '".$country."' ");
$col = $res->fetch_array(MYSQLI_NUM);
$max_miss = 14;
if($traning['rang']>=3){
if($col[0]<$max_miss){
$res = $mysqli->query('SELECT * FROM `missions` WHERE `tip` = "3" and `prog` > "0" ORDER BY `id` asc ');
while ($i = $res->fetch_array()){
$res2 = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = "'.$user['id'].'" and `id_miss` = "'.$i['id'].'" and (`id_miss` = "18" or `id_miss` = "19")');
$mii = $res2->fetch_assoc();
if(!$mii){
$res1 = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = "'.$user['id'].'" and `id_miss` = "'.$i['id'].'" and `country` = "'.$country.'"  ');
$mi = $res1->fetch_assoc();//
if(!$mi){//echo '1';
$mysqli->query('INSERT INTO `missions_user` SET `user` = '.$user['id'].', `tip` = "'.$i['tip'].'" , `id_miss` = "'.$i['id'].'", `prog_max` = "'.$i['prog'].'", `country` = "'.$country.'" ');
}
}
}
}
}
// конец создание миссий
################################################################################################################


//or `id_miss` = '29' or `id_miss` = '30' or `id_miss` = '31')
//or `id_miss` = "29" or `id_miss` = "30" or `id_miss` = "31"





























/* 
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `tip` <= "3" and `time` <= "'.time().'" and `country` = "'.$country.'" 
and (`id_miss` >="28" and `id_miss` < "36")
ORDER BY `tip` asc, `prog`>=`prog_max` desc, `prog` desc, `id` desc LIMIT 100');
while ($miss = $res->fetch_array()){
if($user['id'] == 1){
echo ''.$miss['id_miss'].'<br> ';
}
}

 */


// вывод действующих миссий
################################################################################################################
$max = 100;
$res = $mysqli->query("SELECT * FROM `missions_user` WHERE `user` = ".$user['id']." and `tip` <= '3' and `time` <= ".time()." and `country` = '".$country."' 
and (`id_miss` >='28' and `id_miss` < '36')
");
$k_post = $res->fetch_array(MYSQLI_NUM);
$k_page = k_page($k_post[0],$max);
$page = page($k_page);
$start = $max*$page-$max;
$k_post[0] = $start+1;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `tip` <= "3" and `time` <= "'.time().'" and `country` = "'.$country.'" 
and (`id_miss` >="28" and `id_miss` < "36")
ORDER BY `tip` desc, `prog`>=`prog_max` desc, `prog` desc, `id` desc LIMIT '.$start.','.$max.' ');
while ($miss = $res->fetch_array()){
/* if($user['id'] == 1){
echo ''.$miss['id_miss'].' ';
} */

$res1 = $mysqli->query('SELECT * FROM `missions` WHERE `id` = "'.$miss['id_miss'].'" LIMIT 1 ');
$m = $res1->fetch_assoc();

$width = round(100/($m['prog']/($miss['prog']+0.0000001)));
if($width > 100) {$width = 100;}

$s = ($m['silver']*($img*10)/100);
$e = ($m['exp']*($img*10)/100);


$res_s7 = $mysqli->query('SELECT * FROM `skills_user` WHERE `tip`  = "7" and `user`  = "'.$user['id'].'" ');
$skills_7 = $res_s7->fetch_assoc(); // Инструктор Повышает личный заработанный опыт.
if($skills_7['bon']>0){$m['exp'] = ($m['exp']+($m['exp']*$skills_7['bon']/100));$e = ($e+($e*$skills_7['bon']/100));}else{$m['exp'] = $m['exp'];$e = $e;}

$res_p = $mysqli->query('SELECT * FROM `prom` WHERE `id` = "1" ');
$prom = $res_p->fetch_assoc();
if($prom['time_2']>time()){$m['exp'] = $m['exp']+($m['exp']*$prom['act_2']/100);$e = $e+($e*$prom['act_2']/100);}else{$m['exp'] = $m['exp'];$e = $e;}

if($prom['time_15']>time()){$m['gold'] = ceil($m['gold']+($m['gold']*$prom['act_15']/100));}else{$m['gold'] = $m['gold'];}

if($m['gold']>0){$gold = ceil($m['gold']*$img);$gold_ = '<img class="ico vm" src="/images/icons/gold.png?2" alt="Золото" title="Золото"> '.$gold.'';$gold__ = 'золота';}else{$gold = 0;$gold_ = '';$gold__ = '';}
if($m['silver']>0){$silver = ceil($m['silver']+$s);$silver_ = '<img class="ico vm" src="/images/icons/silver.png" alt="Серебро" title="Серебро"> '.$silver.'';$silver__ = 'серебра';}else{$silver = 0;$silver_ = '';$silver__ = '';}
if($m['exp']>0){$exp = ceil($m['exp']+$e);$exp_ = '<img class="ico vm" src="/images/icons/exp.png" alt="Опыт" title="Опыт"> '.$exp.'';$exp__ = 'опыта';}else{$exp = 0;$exp_ = '';$exp__ = '';}
if($m['crewpoints']>0){$crewpoints = ceil($m['crewpoints']);$crewpoints_ = '<img class="ico vm" src="/images/icons/crewpoints.png" alt="Опыт экипажа" title="Опыт экипажа"> '.$crewpoints.'';$crewpoints__ = 'очков экипажа';}else{$crewpoints = 0;$crewpoints_ = '';$crewpoints__ = '';}
if($m['fuel']>0){$fuel = ceil($m['fuel']+$f);$fuel_ = '<img class="ico vm" src="/images/icons/fuel.png?2" alt="Топливо" title="Топливо"> '.$fuel.'';$fuel__ = 'топлива';}else{$fuel = 0;$fuel_ = '';$fuel__ = '';}
if($m['snaryad']>0){$snaryad = $m['snaryad'];$snaryad_ = '<span class="green2">'.$snaryad.'</span> ';$snaryad__ = 'снарядов';}else{$snaryad = 0;$snaryad_ = '';$snaryad__ = '';}




if(isset($_GET[''.$miss['id'].''])){
if($miss['prog']<$m['prog']){header('Location: ?');exit();}
if($miss['time']>time()){header('Location: ?');exit();}
$mysqli->query('UPDATE `users` SET `miss_col` = `miss_col` + "1", `gold` = `gold` + "'.$gold.'", `silver` = `silver` + "'.$silver.'", `exp` = `exp` + "'.$exp.'", `fuel` = `fuel` + "'.$fuel.'" WHERE `id` = '.$user['id'].'');
if($miss['tip']==1){
$mysqli->query('UPDATE `missions_user` SET `time` = "'.(2147399999).'", `prog` = "0" WHERE `id` = '.$miss['id'].'');
}else{
$mysqli->query('UPDATE `missions_user` SET `time` = "'.(time()+(3600*20)).'", `prog` = "0" WHERE `id` = '.$miss['id'].'');
}
$res = $mysqli->query('SELECT * FROM `ammunition_users` WHERE `user`  = "'.$user['id'].'" LIMIT 1');
$a_users = $res->fetch_assoc();
if($m['snaryad']>0){$rand = rand(1,3);if($rand==1){$mysqli->query("UPDATE `ammunition_users` SET `b` = `b` + '10' WHERE `id` = '".$a_users['id']."' LIMIT 1");}elseif($rand==2){$mysqli->query("UPDATE `ammunition_users` SET `k` = `k` + '10' WHERE `id` = '".$a_users['id']."' LIMIT 1");}elseif($rand==3){$mysqli->query("UPDATE `ammunition_users` SET `f` = `f` + '10' WHERE `id` = '".$a_users['id']."' LIMIT 1");}}
if($m['crewpoints']>0){$mysqli->query("UPDATE `ammunition_users` SET `crewpoints` = `crewpoints` + '".$m['crewpoints']."' WHERE `id` = '".$a_users['id']."' LIMIT 1");}


if($user['company']){
$res_company = $mysqli->query('SELECT * FROM `company` WHERE `id` = '.$user['company'].' limit 1');
$company = $res_company->fetch_assoc();
$res_company_user = $mysqli->query('SELECT * FROM `company_user` WHERE `user` = '.$user['id'].' and `company` = '.$company['id'].' LIMIT 1');
$company_user = $res_company_user->fetch_assoc();
$res_crew_user = $mysqli->query('SELECT * FROM `crew_user` WHERE `user` = '.$user['id'].' and `tip` = "1" limit 1');
$crew_user = $res_crew_user->fetch_assoc();
$res_s6 = $mysqli->query('SELECT * FROM `skills_user` WHERE `tip`  = "6" and `user`  = "'.$user['id'].'" ');
$skills_6 = $res_s6->fetch_assoc(); // Курсы офицеров Повышает заработанный опыт дивизии.
$exp_company = $exp+  ($exp*($crew_user['sposobn']+$skills_6['bon'])/100);
$mysqli->query('UPDATE `company_user` SET `company_exp` = '.($company_user['company_exp']+$exp_company).', `company_exp_stats` = '.($company_user['company_exp_stats']+$exp_company).' WHERE `id` = '.$company_user['id'].'');
$mysqli->query('UPDATE `company` SET `exp` = '.($company['exp']+$exp_company).' WHERE `id` = '.$company['id'].'');
}

header('Location: ?');
$_SESSION['ok'] = '<div class="trnt-block mb6 cntr bold small">
<div class="green1 pb5">Выполнена миссия "'.$m['name'].'"!</div>
<div class="white">'.$gold_.' '.$gold__.' '.$silver_.' '.$silver__.' '.$exp_.' '.$exp__.' '.$crewpoints_.' '.$crewpoints__.' '.$fuel_.' '.$fuel__.' '.$snaryad_.' '.$snaryad__.' </div>
<div class="gray1">Простых миссий выполнено: '.($user['miss_col']+1).'</div>
</div>';
exit();
}



if($miss['tip']==2){
$miss_t = '<span class=general>Лёгкая миссия</span>';
}elseif($miss['tip']==3){
$miss_t = '<span class=yellow1>Сложная миссия</span>';
}
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content">

<div class="white cntr bold sh_b small pb2">
<div class="small orange pb2">'.$miss_t.'<div class="dhr a_w50 mt5 mb5"></div>'.$m['name'].' </div>'.$m['text'].'<br>';//'.$miss['id_miss'].'
if($miss['prog']>0){
echo '<table class="rblock esmall mb0"><tbody><tr>
<td><div class="value-block lh1"><span><span>'.$miss['prog'].'</span></span></div></td>
<td class="progr"><div class="scale-block"><div class="scale" style="width:'.$width.'%;">&nbsp;</div></div></td>
<td><div class="value-block lh1"><span><span>'.$m['prog'].'</span></span></div></td>
</tr></tbody></table>';
}
echo '<span class="gray1">награда:</span> <span class="green2"><span class="nwr"> '.$gold_.' '.$silver_.' '.$exp_.' '.$crewpoints_.' '.$fuel_.' '.$snaryad_.' '.$snaryad__.' </span></span><br>';

echo '</div>';
if($miss['prog']>=$m['prog']){
echo '<div class="bot">
<a class="simple-but border mb10" href="?'.$miss['id'].'"><span><span>Получить награду</span></span></a>
<div style="position:relative;"><span class="digit2 esmall"><span class="l">&nbsp;</span><span class="m">+</span><span class="r">&nbsp;</span></span></div>
</div>';
echo '<div class="trnt-block mb15"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"></div></div></div></div></div></div></div></div></div>';
}


echo '</div></div></div></div></div></div></div></div></div></div>';
if($miss['prog']>=$m['prog']){echo '<br>';}



}
// конец вывод действующих миссий
################################################################################################################







































// вывод ожидаемых миссий
################################################################################################################
$max = 1000;
$res = $mysqli->query("SELECT COUNT(*) FROM `missions_user` WHERE `user` = ".$user['id']." and `tip` <= '3' and `time` < ".(time()+86400)." and `country` = '".$country."' 
and (`id_miss` >='28' and `id_miss` <= '35')
");
$k_post = $res->fetch_array(MYSQLI_NUM);
$k_page = k_page($k_post[0],$max);
$page = page($k_page);
$start = $max*$page-$max;
$k_post[0] = $start+1;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `tip` <= "3" and `time` > "'.time().'" and `time` < "'.(time()+86400).'" and `country` = "'.$country.'" 
and (`id_miss` >="28" and `id_miss` <= "35")
ORDER BY `time` desc LIMIT '.$start.','.$max.' ');
while ($miss_ = $res->fetch_array()){
$res1 = $mysqli->query('SELECT * FROM `missions` WHERE `id` = "'.$miss_['id_miss'].'" ');
$m1 = $res1->fetch_assoc();

echo '<div class="trnt-block mb2">

<div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8">
<div class="wrap-content">
<div class="cntr sh_b small gray1">
<div class="bold pb2">'.$m1['name'].'</div>
<div class="bold">'.$m1['text'].'</div>
Обновление через: '._time($miss_['time']-time()).'
</div>
</div>
</div></div></div></div></div></div></div></div>

</div>';
}
// конец вывод ожидаемых миссий
################################################################################################################


















/* 
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content"><div class="white cntr bold sh_b small pb2">
<div class="small orange pb2">Мастер битв</div>
Проведи 3 битвы<br>
<span class="gray1">награда:</span> <span class="green2"><span class="nwr">
<img class="ico vm" src="/images/icons/gold.png?2" alt="Золото" title="Золото"> 6
</span><span class="nwr">
<img class="ico vm" src="/images/icons/glory.png?2" alt="Слава" title="Слава"> 50
</span></span><br>
</div></div></div></div></div></div></div></div></div></div></div>'; */


$resb_s = $mysqli->query('SELECT * FROM `boevaya_sila` WHERE `user` = "'.$user['id'].'" and `local` = "1" limit 1');
$b_s = $resb_s->fetch_assoc();

if (isset($_SESSION['err'])){
?>
<div class="buy-place-block"><div class="feedbackPanelERROR"><div class="line1"><span class="feedbackPanelERROR">
<?=$_SESSION['err']?>
</span></div></div></div>
<?php
unset($_SESSION['err']);
}




echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content">';
if($b_s['bon_col']<=0){
echo '<div class="medium cntr pb5 white"><span class="bold">Боевая сила: не активна</span><br>Активировать бонус к параметрам</div>
<table class="ta_c"><tbody><tr>
<td class="w33"><a class="simple-but border mb5" href="?bs1"><span><span>+50</span></span></a><img class="ico vm" src="/images/icons/glory.png?2" alt="Слава" title="Слава"> 100</td>
<td class="w33"><a class="simple-but border mb5" href="?bs2"><span><span>+100</span></span></a><img class="ico vm" src="/images/icons/glory.png?2" alt="Слава" title="Слава"> 200</td>
<td class="w33"><a class="simple-but border mb5" href="?bs3"><span><span>+150</span></span></a><img class="ico vm" src="/images/icons/glory.png?2" alt="Слава" title="Слава"> 500</td>
</tr></tbody></table>';
}else{
if($b_s['tip']==1){$param = 50;}elseif($b_s['tip']==2){$param = 100;}elseif($b_s['tip']==3){$param = 150;}
echo '<div class="small cntr pb2 white">Боевая сила: '.$b_s['tip'].' уровень
<div><span class="green1">+'.$param.'</span> к параметрам в следующей битве</div>
<div>Действие: '.$b_s['bon_col'].' битв(ы)</div></div>';
}
echo '</div></div></div></div></div></div></div></div></div></div>'; 



if(isset($_GET['bs1'])){
$res = $mysqli->query('SELECT * FROM `ammunition_users` WHERE `user`  = "'.$user['id'].'" LIMIT 1');
$a_users = $res->fetch_assoc();
if($b_s['bon_col']>0){header('Location: ?');exit();}
if($a_users['glory']<100){$_SESSION['err'] = '<div class="red1">У вас не хватает <img class="ico vm" src="/images/icons/glory.png" alt="Слава" title="Слава"> '.(100-$a_users['glory']).' славы</div>';header('Location: ?');exit();}
if(!$b_s){
$mysqli->query('INSERT INTO `boevaya_sila` SET `user` = '.$user['id'].', `local` = "1", `bon_col` = "3", `tip` = "1" ');
}else{
$mysqli->query("UPDATE `boevaya_sila` SET `local` = '1', `bon_col` = '3', `tip` = '1' WHERE `id` = '".$b_s['id']."' LIMIT 1");
}
$mysqli->query("UPDATE `ammunition_users` SET `glory` = '".($a_users['glory']-100)."' WHERE `id` = '".$a_users['id']."' LIMIT 1");
header('Location: ?');
exit();
}

if(isset($_GET['bs2'])){
$res = $mysqli->query('SELECT * FROM `ammunition_users` WHERE `user`  = "'.$user['id'].'" LIMIT 1');
$a_users = $res->fetch_assoc();
if($b_s['bon_col']>0){header('Location: ?');exit();}
if($a_users['glory']<200){$_SESSION['err'] = '<div class="red1">У вас не хватает <img class="ico vm" src="/images/icons/glory.png" alt="Слава" title="Слава"> '.(200-$a_users['glory']).' славы</div>';header('Location: ?');exit();}
if(!$b_s){
$mysqli->query('INSERT INTO `boevaya_sila` SET `user` = '.$user['id'].', `local` = "1", `bon_col` = "3", `tip` = "2" ');
}else{
$mysqli->query("UPDATE `boevaya_sila` SET `local` = '1', `bon_col` = '3', `tip` = '2' WHERE `id` = '".$b_s['id']."' LIMIT 1");
}
$mysqli->query("UPDATE `ammunition_users` SET `glory` = '".($a_users['glory']-200)."' WHERE `id` = '".$a_users['id']."' LIMIT 1");
header('Location: ?');
exit();
}

if(isset($_GET['bs3'])){
$res = $mysqli->query('SELECT * FROM `ammunition_users` WHERE `user`  = "'.$user['id'].'" LIMIT 1');
$a_users = $res->fetch_assoc();
if($b_s['bon_col']>0){header('Location: ?');exit();}
if($a_users['glory']<500){$_SESSION['err'] = '<div class="red1">У вас не хватает <img class="ico vm" src="/images/icons/glory.png" alt="Слава" title="Слава"> '.(500-$a_users['glory']).' славы</div>';header('Location: ?');exit();}
if(!$b_s){
$mysqli->query('INSERT INTO `boevaya_sila` SET `user` = '.$user['id'].', `local` = "1", `bon_col` = "3", `tip` = "3" ');
}else{
$mysqli->query("UPDATE `boevaya_sila` SET `local` = '1', `bon_col` = '3', `tip` = '3' WHERE `id` = '".$b_s['id']."' LIMIT 1");
}
$mysqli->query("UPDATE `ammunition_users` SET `glory` = '".($a_users['glory']-500)."' WHERE `id` = '".$a_users['id']."' LIMIT 1");
header('Location: ?');
exit();
}








/* echo '<div class="trnt-block mb2"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content-mini">
<div class="mt5 mb5 small green1 cntr">';
if($user['pvp_tip']==1){echo '';}
if($user['pvp_tip']==2){echo 'битва "каждый сам за себя" в комнате из 5 танкистов.';}
if($user['pvp_tip']==3){echo 'битва "каждый сам за себя" в комнате из 10 танкистов.';}
echo '</div>
</div></div></div></div></div></div></div></div></div></div>';
 */




echo '<a w:id="pvpRatingLink" href="/pvp/top/" class="simple-but"><span><span>Лучшие в битве</span></span></a>';
echo '</div>';

/* $res = $mysqli->query('SELECT * FROM `pvp_results` WHERE `time` <= "'.(time()-60).'" ');
$ccccc = $res->fetch_assoc();
echo ''.$ccccc['id'].''; */
//$mysqli->query('DELETE FROM `pvp_results` WHERE `pvp_id` = "'.$pvp_res['pvp_id'].'" and `number` = "0" ');
$mysqli->query('DELETE FROM `pvp_results` WHERE (`time` <= "'.(time()-60).'" and `time` > "0") or `user` = "0" or `pvp_id` = "0" ');
$mysqli->query('DELETE FROM `pvp_log` WHERE `time` <= "'.(time()-86400).'" or `pvp_id` = "0" ');
require_once ('../system/footer.php');
?>