<?php
$mysqli = mysqli_connect(
'localhost',  // Хост, к которому мы подключаемся 
'novikora_mtank',       // Имя пользователя 
'j2eJeQLj8QkkF1',   // Используемый пароль 
'novikora_mtank');    // База данных для запросов по умолчанию  
if (!$mysqli) {
printf("Невозможно подключиться к базе данных. Код ошибки: %s\n", mysqli_connect_error());
exit;
} 


/* company
items */
$query = $mysqli;
//query($query);
$items = array();



// Сохраняем записи таблицы в массив

$result = $mysqli->query('SELECT * FROM `users` WHERE `id` ');
while ($row = $result->fetch_array()){
$items[] = $row;
}

/* while( $row = $result->fetch_assoc() ) {
$items[] = $row;
} */


// Проверяем, нажата ли кнопка экспорта
if(isset($_POST["export"])) {
// Определим имя файла с текущей датой
$fileName = "itemdata-".date('d-m-Y').".xls";

// Устанавливаем информацию заголовка для экспорта данных в формате Excel
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename='.$fileName);

// Устанавливаем переменную в false для заголовка
$heading = false;

// Добавляем данные таблицы MySQL в файл Excel
if(!empty($items)) {
foreach($items as $item) {
if(!$heading) {
echo implode("\t", array_keys($item)) . "\n";
$heading = true;
}
echo implode("\t", array_values($item)) . "\n";
}
}
exit();
}

// Добавить скрипт для чтения данных MySQL и экспорта в Excel
//include ( "/php/export/read_and_export.php" ) ;
//require_once ('../php/export/read_and_export.php');
?>

<!DOCTYPE html>
<html>
<head>
<title>Экспорт данных MySQL в Excel с помощью PHP</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet"
href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet"
href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
<script
src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script
src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>

<body>

<div class="container">
<center><br/><br/><h2
style='color:green'>Информация о таблице товаров</h2></center>
<div class="col-sm-12">
<div>
<form action="#" method="post">
<button type="submit" id="export" name="export"
value="Export to excel" class="btn btn-success">Экспорт в Excel</button>
</form>
</div>
</div>
<br/>
<table id="" class="table table-striped table-bordered">
<tr>
<th>ID</th>
<th>Имя</th>
<th>Тип</th>
<th>Марка</th>
<th>Цена</th>
</tr>
<tbody>
<?php foreach($items as $item) { ?>
<tr>
<td><?php echo $item ['id']; ?></td>
<td><?php echo $item ['name']; ?></td>
<td><?php echo $item ['type']; ?></td>
<td><?php echo $item ['brand']; ?></td>
<td>$<?php echo $item ['price']; ?></td>
</tr>
<?php } ?>
</tbody>
</table>
</div>

</body>
</html>