<?php
header('Location: /');
exit();
?>