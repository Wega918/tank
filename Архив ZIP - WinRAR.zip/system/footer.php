<?php
$today[1] = date("H:i:s"); 
if(!$user['id']) {
echo '<div class="footer"><div class="esmall cntr mb5"><span><span>'.$today[1].'</span></span> | <a class="gray1" href="about">Об игре</a> | '.round(microtime(1) - $t_s, 3).' сек</div></div>';
}else{

if($user['position']>=4){$panel = '<a class="gray1" href="/panel/">Панель</a> | ';}

//$res = $mysqli->query('SELECT * FROM `settings` WHERE `id` = "1"');
//$sql = $res->fetch_assoc();

//$res = $mysqli->query('SELECT COUNT(*) FROM `users` WHERE `viz` > '.(time()-$sql['online']).' ');
//$ONL = $res->fetch_array(MYSQLI_NUM);

if($user['kill_tanks'] >= 3){
$href1 = 'href="/"';
$href2 = 'href="/profile/'.$user['id'].'/"';
}else{
$href1 = '';
$href2 = '';
}

echo '<table><tbody><tr>';
echo '<td class="pr4 w33"><div style="position:relative;"><a class="simple-but gray border mb1" '.$href1.'><span><span>Ангар</span></span></a>';
//echo '<span class="digit esmall"><span class="l">&nbsp;</span><span class="m">+</span><span class="r">&nbsp;</span></span>';
echo '</div></td>';
if ($_SERVER['PHP_SELF'] != '/buildings/production.php' ) {
echo '<td class="pr4 w33"><div style="position:relative;"><a class="simple-but gray border mb1" '.$href2.'><span><span>Профиль</span></span></a>';
/* if($user['time_crew_fuel']<time()){
$res1 = $mysqli->query('SELECT * FROM `crew_user` WHERE `user`  = "'.$user['id'].'" and `tip`  = "2" LIMIT 1');
$crew_user = $res1->fetch_assoc();
if($crew_user['rang']>1){echo '<span class="digit esmall"><span class="l">&nbsp;</span><span class="m">+</span><span class="r">&nbsp;</span></span>';}
} */
}else{
$res = $mysqli->query("SELECT COUNT(*) FROM `buildings_user` WHERE `user` = ".$user['id']." and `level` > '0' and (`faste_build_time` > '0' and `faste_build_time` < '".time()."') limit 1");
$col_build_plus1 = $res->fetch_array(MYSQLI_NUM);
$res = $mysqli->query("SELECT COUNT(*) FROM `buildings_user` WHERE `user` = ".$user['id']." and `level` > '0' and (`time_production` < '".time()."' and `time_production` > '0') limit 1");
$col_build_plus2 = $res->fetch_array(MYSQLI_NUM);
if($col_build_plus[0]<=0 and $col_build_plus2[0]<=0){$plus_postroyki = '';}else{$plus_postroyki = '<span class="digit esmall"><span class="l">&nbsp;</span><span class="m">+</span><span class="r">&nbsp;</span></span>';}
echo '<td class="pr4 w33"><div style="position:relative;"><a class="simple-but gray border mb1" href="/buildings/"><span><span>База</span></span></a>'.$plus_postroyki.'';
}
//echo '<span class="digit esmall"><span class="l">&nbsp;</span><span class="m">+</span><span class="r">&nbsp;</span></span>';
echo '</div></td>';

if ($user['company'] > 0) {
if ($_SERVER['PHP_SELF'] != '/index.php' ) {
echo '<td class="pr4 w33"><div style="position:relative;"><a class="simple-but gray border mb1" href="/company/'.$user['company'].'/"><span><span>Дивизия</span></span></a></div></td>';
}
}

echo '</tr></tbody></table>';




echo '<center><img src="https://air.mars-games.ru/favicon.ico" width="15" height="15" alt="https://air.mars-games.ru/"> <a href="https://air.mars-games.ru/" target="_blank"><font color=gold>Авиа бизнесмены</font></a></center>';
echo '<center><img src="https://mars-games.ru/favicon.ico" width="15" height="15" alt="https://mars-games.ru/"> <a href="https://mars-games.ru/" target="_blank"><font color=gold>Марсианские бизнесмены</font></a></center>';




$res = $mysqli->query('SELECT * FROM `prom` WHERE `id` = "1" ');
$prom = $res->fetch_assoc();


if($user['level'] >= 2){
if($prom['time_7']>time()){
$res = $mysqli->query('SELECT * FROM `prom_elka_user` WHERE `user` = "'.$user['id'].'" ');
$p_e_u = $res->fetch_assoc();
if(!$p_e_u){$mysqli->query('INSERT INTO `prom_elka_user` SET `user` = "'.$user['id'].'"');}
if($p_e_u['time']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="green1" href="/xprom/7/">Новогодняя ёлка</a></div>';
}else{
echo '<div class="medium cntr mt2 mb2"><a class="orange" href="/xprom/7/">Новогодняя ёлка</a></div>';
}
}
}


if($prom['time_19']>time()){
$res = $mysqli->query('SELECT * FROM `prom_elka_user` WHERE `user` = "'.$user['id'].'" ');
$p_e_u = $res->fetch_assoc();
if($dateStart_<(time()+300) and $date_y){
echo '<div class="medium cntr mt2 mb2"><a class="orange" href="/dm_year/">Игра в снежки</a></div>';
}else{
echo '<div class="medium cntr mt2 mb2"><a class="blue2" href="/dm_year/">Игра в снежки</a></div>';
}
}




if($prom['time_20']>time()){
$res = $mysqli->query('SELECT * FROM `bz_user` WHERE `user` = "'.$user['id'].'" and `tip` = "'.$prom['tip_20'].'"');
$bz_user = $res->fetch_assoc();
if($prom['tip_20']==1){$n = 'Праздничная боевая задача';}
if($bz_user['prog_']>=$bz_user['prog'] and $bz_user['prog_']>0){
echo '<div class="medium cntr mt2 mb2"><a class="orange" href="/xprom/20/">'.$n.'</a></div>';
}else{
echo '<div class="medium cntr mt2 mb2"><a class="bia" href="/xprom/20/">'.$n.'</a></div>';
}
}



if($prom['time_1']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="/xprom/1/"><span style="color:lawngreen;">Акция - бонус золота!</span></a></div>';
}
if($prom['time_2']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="/xprom/2/"><font color=#eaaf45>Акция - бонус опыта!</font></a></div>';
}
if($prom['time_3']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="/xprom/3/">Акция - скидка на тренировку!</a></div>';
}
if($prom['time_4']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="silver" href="/xprom/4/">Акция - бонус серебра!</a></div>';
}
if($prom['time_5']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="/xprom/5/">Акция - скидка на базу!</a></div>';
}
if($prom['time_6']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="/xprom/6/">Акция - скидка на умения!</a></div>';
}
if($prom['time_8']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="/xprom/8/">Акция - скидка на экипаж!</a></div>';
}
if($prom['time_9']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="/xprom/9/">Акция - скидка на улучшения!</a></div>';
}
if($prom['time_10']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="/xprom/10/">Акция - скидка на апгрейд!</a></div>';
}
if($prom['time_11']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="/xprom/11/">Акция - скидка на модификацию!</a></div>';
}
if($prom['time_12']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="/xprom/12/">Акция - скидка на усиления!</a></div>';
}
if($prom['time_13']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="/xprom/13/">Акция - скидка на боевую подготовку!</a></div>';
}
if($prom['time_14']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="/xprom/14/">Акция - скидка на военное управление!</a></div>';
}
if($prom['time_15']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="gold" href="/xprom/15/"><font color=#fcec6e>Акция - больше золота за миссии!</font></a></div>';
}

if($prom['time_16']>time()){
if($user['time_prom16_fuel']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="/xprom/16/"><font color=#97ace7>Акция - бонусное топливо!</font></a></div>';
}else{
echo '<div class="medium cntr mt2 mb2"><a class="orange" href="/xprom/16/">Акция - бонусное топливо!</a></div>';
}
}
if($prom['time_17']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="/xprom/17/">Акция - больше опыта в бою!</a></div>';
}
if($prom['time_18']>time()){
echo '<div class="medium cntr mt2 mb2"><a class="silver" href="/xprom/18/">Акция - больше серебра в бою!</a></div>';
}







/*
echo '<div class="medium cntr mb2 mt2"><a class="bia" href="battletasks">Боевая задача</a></div>';
echo '<div class="medium cntr mt2 mb2"><a class="magenta" href="xpromo/BooleanPromoType_Dep50GoldToBonus250AndClanBonus250">Акция - бонус золота!</a></div>';
*/
echo '<div class="medium cntr mb2"><a class="yellow1" href="/forum/">Форум</a> | <a class="yellow1" href="/chat/">Чат</a></div>';
echo '<div class="esmall cntr mb2"><a class="yellow1" href="/online/">Онлайн</a></div>';
//echo '<div class="esmall cntr mb2 mt2 gray1"><span><span>01:37:26</span></span></div>';
//echo '<div class="esmall cntr mb5"><a class="gray1" href="'.$HOME.'about/">Об игре</a> | <a class="gray1" href="'.$HOME.'settings/">Настройки</a></div>';
echo '<br><div class="esmall cntr mb5"><span><span>'.date("H:i:s").'</span></span> | '.round(microtime(1) - $t_s, 3).' сек </div>';
echo '<div class="esmall cntr"> '.$panel.' <a class="gray1" href="/settings/">Настройки</a> | <a class="gray1" href="/about/">Об игре</a> | <a class="gray1" href="/exit/">Выход</a></div>';
}
echo '</div><body></html>';


$_SESSION['miss'] = 0;


//mysqli_close($mysqli);

?>