<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, minimum-scale=1, maximum-scale=5">
<meta name="Keywords" content="Танки, игры, RPG, MMORPG, онлайн игра, онлайн, wap, бесплатно, играть онлайн, ролевые игры, лучшие онлайн игры, браузерная игра, сражения, бои, турниры, задания, битвы, поле боя">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Танки">
<meta property="og:title" content="Танки">
<meta property="og:description" content="Погрузись в мир танков, участвуй в легендарных сражениях, покажи на что ты способен!">
<meta property="og:url" content="https://mtank.ru/">
<meta property="og:image" content="/images/logo.jpg">
<meta property="og:image:width" content="2560">
<meta property="og:image:height" content="1024">

<link rel="apple-touch-icon.png" href="/images/apple-touch-icon.png">
<link rel="icon" href="/favicon.ico" type="image/x-icon">
<link rel="shortcut icon" href="/favicon.ico">
<link rel="stylesheet" type="text/css" href="/diz.css">

<title>Танки</title>

<script type="text/javascript">var secS ='с';var secM =' сек';var minS ='м:';var minM ='мин';var hourS ='ч:';var hourM ='час';var dayS ='д:';var dayM ='дн';var detailOut = false;var readyLink = '1'+(detailOut?secS:'' + secM );</script>
</head>
<?php

echo '<body><div class="mt5">';
if(!$user['id']) {
if (isset($_SESSION['err'])){?><div class="buy-place-block"><div class="feedbackPanelERROR"><div class="line1"><span class="feedbackPanelERROR"><?=$_SESSION['err']?></span></div></div></div> <?php unset($_SESSION['err']);}
}else{
##############################################################################################################
########################################### СИСТЕМА АВТОНАЧИСЛЕНИЯ ###########################################
##############################################################################################################
$kolvo = (time()-$user['viz']);
$sec = 7;
if(($user['fuel'])<$user['fuel_max']){
if($kolvo>=$sec){
$f = ceil($kolvo/$sec);
if(($f+$user['fuel'])<=$user['fuel_max']){
$mysqli->query("UPDATE `users` SET `fuel` = '".($user['fuel']+$f)."', `fuel_time` = '".time()."' WHERE `id` = '".$user['id']."' LIMIT 1");
}else{
$mysqli->query("UPDATE `users` SET `fuel` = '".$user['fuel_max']."', `fuel_time` = '".time()."' WHERE `id` = '".$user['id']."' LIMIT 1");
}
}else{
if(($user['fuel_time']+$sec) < time()){
if((1+$user['fuel'])<=$user['fuel_max']){
$mysqli->query("UPDATE `users` SET `fuel` = '".($user['fuel']+1)."', `fuel_time` = '".time()."' WHERE `id` = '".$user['id']."' LIMIT 1");
}else{
$mysqli->query("UPDATE `users` SET `fuel` = '".$user['fuel_max']."', `fuel_time` = '".time()."' WHERE `id` = '".$user['id']."' LIMIT 1");
}
}
}
}
##############################################################################################################
##############################################################################################################
##############################################################################################################





##############################################################################################################
##############################################################################################################
##############################################################################################################
$levelToExp = [
    1 => 4,
    2 => 9,
    3 => 15,
    4 => 35,
    5 => 60,
    6 => 95,
    7 => 150,
    8 => 250,
    9 => 400,
    10 => 650,
    11 => 900,
    12 => 1200,
    13 => 1500,
    14 => 2000,
    15 => 3000,
    16 => 4500,
    17 => 6000,
    18 => 7500,
    19 => 9500,
    20 => 11500,
    21 => 12000,
    22 => 15000,
    23 => 22000,
    24 => 35000,
    25 => 60000,
    26 => 100000,
    27 => 160000,
    28 => 240000,
    29 => 400000,
    30 => 600000,
    31 => 800000,
    32 => 1000000,
    33 => 1200000,
    34 => 1400000,
    35 => 1600000,
    36 => 1800000,
    37 => 2200000,
    38 => 2500000,
    39 => 3500000,
    40 => 5000000,
    41 => 7500000,
    42 => 10000000,
    43 => 12500000,
    44 => 15000000,
    45 => 20000000,
    46 => 25000000,
    47 => 35000000,
    48 => 50000000,
    49 => 60000000,
    50 => 90000000,
    51 => 125000000,
    52 => 170000000,
    53 => 225000000,
    54 => 300000000,
    55 => 100000000000000000000000000000000000000000000000000000000000000000000,
];

if ($user['level'] >= 1 && $user['level'] <= 55) {
    $exp = $levelToExp[$user['level']];
} else {
    // Уровень пользователя недопустим, установите значение по умолчанию или обработайте ошибку.
    $exp = 0; // Например, установка опыта в 0 для недопустимых уровней.
}



$exp1 = ($exp*5);
$exp_progress = round(100/($exp1/($user['exp']+1)));
if($exp_progress > 100) {$exp_progress = 100;}



if($user['exp'] >= $exp1){
$res = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user`  = "'.$user['id'].'" and `active`  = "1" limit 1');
$users_tanks = $res->fetch_assoc();
$mysqli->query("UPDATE `users` SET `fuel` = '".($user['fuel'] + $user['fuel_max'])."', `exp` = '".($user['exp'] = 0)."', `silver` = '".($user['silver'] + (($user['level']+1)*50))."', `gold` = '".($user['gold'] + (($user['level']+1)*5))."', `level` = '".($user['level'] + 1)."' WHERE `id` = '".$user['id']."' LIMIT 1");
$mysqli->query("UPDATE `users_tanks` SET `a` = '".($users_tanks['a'] + 1)."', `b` = '".($users_tanks['b'] + 1)."', `t` = '".($users_tanks['t'] + 1)."', `p` = '".($users_tanks['p'] + 1)."' WHERE `id` = '".$users_tanks['id']."' LIMIT 1");
header('Location: ?');
$_SESSION['level'] = '<div class="medium pb5 orange">Вы получили <img height="14" width="14" src="/images/icons/exp.png"> '.($user['level']+1).' уровень!</div>
<div class="small white sh_b"><span class="green2">Награда:</span><br>
<span class="nwr"><img class="ico vm" src="/images/icons/gold.png?1" alt="Золото" title="Золото"> '.(($user['level']+1)*5).' золота</span>
<span class="nwr"><img class="ico vm" src="/images/icons/silver.png" alt="Серебро" title="Серебро"> '.(($user['level']+1)*50).' серебра</span>
<span class="nwr"><img class="ico vm" src="/images/icons/fuel.png" alt="Топливо" title="Топливо"> '.($user['fuel_max']).' топлива</span><br>
<img class="vb pb2" src="/images/upgrades/starFull.png" height="14" width="14"> Танковая мощь: +4</div>';
exit();
}
##############################################################################################################
##############################################################################################################
##############################################################################################################














if($user['start'] == 0){
$res = $mysqli->query('SELECT * FROM `start` WHERE `user` = '.$user['id'].' LIMIT 1 ');
$start = $res->fetch_assoc();
if($start['step']==1 and $_SERVER['PHP_SELF'] != '/start/1.php') {
header('Location: '.$HOME.'1/');
}elseif(($start['step']==2 or $start['step']==3) and $_SERVER['PHP_SELF'] != '/start/2.php') {
header('Location: '.$HOME.'2/');
}
}else{
if($_SERVER['PHP_SELF'] != '/chat/index.php' and $_SERVER['PHP_SELF'] != '/chat/moderators.php' 
and $_SERVER['PHP_SELF'] != '/forum/index.php' and $_SERVER['PHP_SELF'] != '/forum/razdel.php' 
and $_SERVER['PHP_SELF'] != '/forum/topik.php' and $_SERVER['PHP_SELF'] != '/forum/redact.php') {
?>
<div class="round-panel" onclick="location.href='/'"><div class="wrp1"><div class="wrp2">
<table class="count bold"><tbody><tr>
<td class="small lh1 bgn"><img title="Топливо" alt="Топливо" src="/images/icons/fuel.png"><font color=silver> <?=$user['fuel']?></font></td>
<td class="small lh1 pl12"><img title="Золото" alt="Золото" src="/images/icons/gold.png?1"><font color=silver> <?=$user['gold']?></font></td>
<td class="small lh1 pl12"><img title="Серебро" alt="Серебро" src="/images/icons/silver.png"><font color=silver> <?=$user['silver']?></font></td>
</tr></tbody></table>
</div></div></div>
<?
echo '<table class="rblock blue esmall">
<tbody><tr>
<td><div class="value-block lh1"><span><span><img height="14" width="14" src="/images/icons/exp.png">'.$user['level'].'</span></span></div></td>
<td class="progr"><div class="scale-block"><div class="scale" style="width:'.$exp_progress.'%;">&nbsp;</div></div></td>
<td><div class="value-block lh1"><span><span>'.$exp_progress.'%</span></span></div></td>
</tr>
</tbody></table>';
}

if (isset($_SESSION['level'])){
?>
<div class="trnt-block mb2"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr bold">
<?=$_SESSION['level']?>
</div></div></div></div></div></div></div></div></div></div>
<?php
unset($_SESSION['level']);
}


if($user['level']>=4){
$res = $mysqli->query('SELECT * FROM `forum_news` WHERE `user` = "'.$user['id'].'" and `read` = "0" ORDER BY `id` desc');
while ($news = $res->fetch_array()){
$res1 = $mysqli->query('SELECT * FROM `forum_topik` WHERE `id` = '.$news['topik'].' LIMIT 1');
$topik = $res1->fetch_assoc();
echo '<div class="trnt-block mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="orange bold"><img src="/images/icons/victory.png"> Горячие новости! <img src="/images/icons/victory.png"></div>
<div class="dhr a_w50 mt5 mb5"></div>
<span class="yellow2 small bold">☆ '.$news['name'].' ☆</span>
<div class="mt5"><a class="simple-but inbl mb1" href="?view'.$news['id'].'"><span><span>Посмотреть новость</span></span></a></div>
<a class="gray1 small td_u" href="?readwhere'.$news['id'].'">cкрыть</a>
</div></div></div></div></div></div></div></div></div></div>';
if(isset($_GET['view'.$news['id'].''])){
$mysqli->query('DELETE FROM `forum_news` WHERE `id` = "'.$news['id'].'" ');
header('location: /topik/'.$topik['razdel'].'/'.$news['topik'].'/');
exit();
}
if(isset($_GET['readwhere'.$news['id'].''])){
$mysqli->query('DELETE FROM `forum_news` WHERE `id` = "'.$news['id'].'" ');
header('location: ?');
exit();
}
}
}











$res = $mysqli->query('SELECT * FROM `users_bonus` WHERE `user` = '.$user['id'].' LIMIT 1');
$us_bon = $res->fetch_assoc();
if(!$us_bon){
$mysqli->query('INSERT INTO `users_bonus` SET `day` = "1", `user` = "'.$user['id'].'"');
}


/* if($user['id']==1){
echo ''.$us_bon['act'].' '.$us_bon['day'].'';
} */

if($us_bon['act']==0 and $us_bon['day']!=0){

$gold = ($us_bon['day']*1);
$silver = ($us_bon['day']*50);
if($us_bon['day']==1){$color1 = 'grey';}else{$color1 = 'white';}
if($us_bon['day']==2){$color2 = 'grey';}else{$color2 = 'white';}
if($us_bon['day']==3){$color3 = 'grey';}else{$color3 = 'white';}
if($us_bon['day']==4){$color4 = 'grey';}else{$color4 = 'white';}
if($us_bon['day']==5){$color5 = 'grey';}else{$color5 = 'white';}




/* $mysqli->query("UPDATE `users` SET `gold` = '".($user['gold']+$gold)."', `silver` = '".($user['silver']+$silver)."' WHERE `id` = '".$user['id']."' LIMIT 1");
$mysqli->query("UPDATE `users_bonus` SET `act` = `act` + '1' WHERE `id` = '".$us_bon['id']."' LIMIT 1");
 */
if(isset($_GET['bon'])){
if($us_bon['act']!=0){header('Location: ?');exit();}
$mysqli->query("UPDATE `users` SET `gold` = '".($user['gold']+$gold)."', `silver` = '".($user['silver']+$silver)."' WHERE `id` = '".$user['id']."' LIMIT 1");
$mysqli->query("UPDATE `users_bonus` SET `act` = `act` + '1' WHERE `id` = '".$us_bon['id']."' LIMIT 1");
$_SESSION['ok'] = '<div class="buy-place-block"><div class="feedbackPanelINFO"><div class="line1"><span class="feedbackPanelINFO">
Получено <span class="nwr"><img title="Золото" alt="Золото" src="/images/icons/gold.png?1"> '.$gold.' золота</span>
<span class="nwr"><img class="ico vm" src="/images/icons/silver.png" alt="Серебро" title="Серебро"> '.$silver.' серебра</span>
</span></div></div></div>';
header('Location: ?');
exit();
}

if($user['level']>=3){
echo '<div class="buy-place-block"><div class="feedbackPanelERROR"><div class="line1"><span class="feedbackPanelERROR">
<div class="medium bold pb5 cntr green1"><img height="14" width="14" src="/images/icons/victory.png"> <span>Ваш бонус за вход в игру</span> <img height="14" width="14" src="/images/icons/victory.png"></div>
<div class="small white cntr sh_b bold"><span class="yellow1">
<span class="nwr"><img title="Золото" alt="Золото" src="/images/icons/gold.png?1"> '.$gold.' золота</span>
<span class="nwr"><img class="ico vm" src="/images/icons/silver.png" alt="Серебро" title="Серебро"> '.$silver.' серебра</span>
</span><br><div class="dhr a_w50 mt5 mb5"></div>
Заходите завтра и получите еще!


<table><tbody><tr>
<td style="width:25%;padding-right:4px;"></td>

<td style="width:50%;padding:0 4px;"><div style="position:relative;"><a class="simple-but border mb1" href="?bon"><span><span>Забрать</span></span></a></div></td>
<td style="width:25%;padding-left:4px;"></td>
</tr></tbody></table>'; 


?><span id="pokazat"><a onclick="document.getElementById('pokazat').style.display='none';document.getElementById('skryt').style.display='';return false;" href="#">
<span><span><u>Подробнее</u></span></span>
</a></span><?





?><span id="skryt" style="display:none">


<div class="fight center">
<div class="trnt-block mb2"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content-mini">
<div class="mt10"></div>




<span class="yellow1">


<span class="fl"><img src="/images/right_blue.png" class="price_img"><font color="<?=$color1?>" size="2">День: 1</font> 
<span class="nwr"><img title="Золото" alt="Золото" src="/images/icons/gold.png?1"> 1</span> 
<span class="nwr"><img title="Серебро" alt="Серебро" src="/images/icons/silver.png?1"> 50</span> 
</span>

<span class="fr"><img src="/images/right_blue.png" class="price_img"><font color="<?=$color2?>" size="2">День: 2</font> 
<span class="nwr"><img title="Золото" alt="Золото" src="/images/icons/gold.png?1"> 2</span> 
<span class="nwr"><img title="Серебро" alt="Серебро" src="/images/icons/silver.png?1"> 100</span> &nbsp;
</span>

<br><div class="dhr a_w100 mt5 mb5"></div>

<span class="fl"><img src="/images/right_blue.png" class="price_img"><font color="<?=$color3?>" size="2">День: 3</font> 
<span class="nwr"><img title="Золото" alt="Золото" src="/images/icons/gold.png?1"> 3</span> 
<span class="nwr"><img title="Серебро" alt="Серебро" src="/images/icons/silver.png?1"> 150</span> 
</span>

<span class="fr"><img src="/images/right_blue.png" class="price_img"><font color="<?=$color4?>" size="2">День: 4</font> 
<span class="nwr"><img title="Золото" alt="Золото" src="/images/icons/gold.png?1"> 4</span> 
<span class="nwr"><img title="Серебро" alt="Серебро" src="/images/icons/silver.png?1"> 200</span> &nbsp;
</span>

<br><div class="dhr a_w50 mt5 mb5"></div>

<span class="center"><img src="/images/right_blue.png" class="price_img"><font color="<?=$color5?>" size="2">День: 5</font> 
<span class="nwr"><img title="Золото" alt="Золото" src="/images/icons/gold.png?1"> 5</span> 
<span class="nwr"><img title="Серебро" alt="Серебро" src="/images/icons/silver.png?1"> 250</span> 
</span>

</span>




<div class="dhr a_w100 mt5 mb5"></div>
<table><tbody>
<td style="width: 100%"><span class="fl">
<div class="mt5 mb5 small green1">
&nbsp;<font color="white">*</font> Каждый последующий день награда будет увеличиваться.<br>
&nbsp;<font color="white">*</font> Максимальная награда на 5-м дне входа в игру.<br>
&nbsp;<font color="white">*</font> Если пропустить день, бонус будет считать заново с 1-го дня.
</div>
</span><td>
</tbody></table>
</div></div></div></div></div></div></div></div></div></div>
</div></span><?
echo '</div></span></div></div></div><div class="mt5"></div>';
}
}
//}








//if($user['id']==1){
$date1 =  strtotime('08:00');
$date2 =  strtotime('10:00');
$date3 =  strtotime('12:00');
$date4 =  strtotime('14:00');
$date5 =  strtotime('16:00');
$date6 =  strtotime('18:00');
$date7 =  strtotime('20:00');
$date8 =  strtotime('23:00');

if($date1<=time()){$dateStart1 = ($date1+86400);}else{$dateStart1 = ($date1);}
if($date2<=time()){$dateStart2 = ($date2+86400);}else{$dateStart2 = ($date2);}
if($date3<=time()){$dateStart3 = ($date3+86400);}else{$dateStart3 = ($date3);}
if($date4<=time()){$dateStart4 = ($date4+86400);}else{$dateStart4 = ($date4);}
if($date5<=time()){$dateStart5 = ($date5+86400);}else{$dateStart5 = ($date5);}
if($date6<=time()){$dateStart6 = ($date6+86400);}else{$dateStart6 = ($date6);}
if($date7<=time()){$dateStart7 = ($date7+86400);}else{$dateStart7 = ($date7);}
if($date8<=time()){$dateStart8 = ($date8+86400);}else{$dateStart8 = ($date8);}


if($dateStart1<(time()+(300))){$date = ($date1);$nameBattle = 'Битва на Халхин-Голе';}
if($dateStart2<(time()+(300))){$date = ($date2);$nameBattle = 'Битва за о. Сахалин';}
if($dateStart3<(time()+(300))){$date = ($date3);$nameBattle = 'Блокада Ленинграда';}
if($dateStart4<(time()+(300))){$date = ($date4);$nameBattle = 'Битва за Харьков';}
if($dateStart5<(time()+(300))){$date = ($date5);$nameBattle = 'Битва за Сталинград';}
if($dateStart6<(time()+(300))){$date = ($date6);$nameBattle = 'Битва за Днепр';}
if($dateStart7<(time()+(300))){$date = ($date7);$nameBattle = 'Битва за Москву';}
if($dateStart8<(time()+(300))){$date = ($date8);$nameBattle = 'Курская дуга';}

///echo ''.$nameBattle.'';

if($date<=time()){$dateStart = ($date+86400);}else{$dateStart = ($date);}

/* if($user['id']==1){
echo ''.time().' '.$date.' '.$_SESSION['pve'].'';
} */


if($dateStart<(time()+300) and $date){
//if($user['id']==1){
if($_SESSION['pve']!=777){
echo '<div class="trnt-block mb15"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content">
<div class="small bold yellow1 sh_b mb5 cntr"><img src="/images/icons/victory.png"> '.$nameBattle.'! <img src="/images/icons/victory.png"></div>
<div class="dhr a_w50 mt5 mb5"></div>
<div class="small bold yellow sh_b mb5 cntr">до начала '._time1($p['time']-time()).'</div>
<div class="bot"><a class="simple-but border" href="/pve/"><span><span>К сражению</span></span></a></div>
</div></div></div></div></div></div></div></div></div></div>';
}
//}
}else{
$_SESSION['pve']=0;
}
//}










$date1_ =  strtotime('11:30');
$date2_ =  strtotime('16:30');
$date3_ =  strtotime('22:30');

if($date1_<=time()){$dateStart1_ = ($date1_+86400);}else{$dateStart1_ = ($date1_);}
if($date2_<=time()){$dateStart2_ = ($date2_+86400);}else{$dateStart2_ = ($date2_);}
if($date3_<=time()){$dateStart3_ = ($date3_+86400);}else{$dateStart3_ = ($date3_);}

if($dateStart1_<(time()+(300))){$date_ = ($date1_);$dm_id = 1;}
if($dateStart2_<(time()+(300))){$date_ = ($date2_);$dm_id = 2;}
if($dateStart3_<(time()+(300))){$date_ = ($date3_);$dm_id = 3;}

if($date_<=time()){$dateStart_ = ($date_+86400);}else{$dateStart_ = ($date_);}

if($dateStart_<(time()+300) and $date_){
if($_SESSION['dm']!=777){
echo '<div class="trnt-block mb15"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content">
<div class="small bold yellow1 sh_b mb5 cntr"><img src="/images/icons/victory.png"> Схватка! <img src="/images/icons/victory.png"></div>
<div class="dhr a_w50 mt5 mb5"></div>
<div class="small bold yellow sh_b mb5 cntr">до начала '._time1($dateStart_-time()).'</div>
<div class="bot"><a class="simple-but border" href="/dm/"><span><span>К сражению</span></span></a></div>
</div></div></div></div></div></div></div></div></div></div>';
}
}else{
$_SESSION['dm']=0;
}













if($prom['time_19']>time()){

$date1_y =  strtotime('11:00');
$date2_y =  strtotime('17:00');
$date3_y =  strtotime('22:00');

if($date1_y<=time()){$dateStart1_y = ($date1_y+86400);}else{$dateStart1_y = ($date1_y);}
if($date2_y<=time()){$dateStart2_y = ($date2_y+86400);}else{$dateStart2_y = ($date2_y);}
if($date3_y<=time()){$dateStart3_y = ($date3_y+86400);}else{$dateStart3_y = ($date3_y);}

if($dateStart1_y<(time()+(300))){$date_y = ($date1_y);}
if($dateStart2_y<(time()+(300))){$date_y = ($date2_y);}
if($dateStart3_y<(time()+(300))){$date_y = ($date3_y);}

if($date_y<=time()){$dateStart__ = ($date_y+86400);}else{$dateStart__ = ($date_y);}

if($dateStart__<(time()+300) and $date_y){
if($_SESSION['dm_year']!=777){
echo '<div class="trnt-block mb15"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content">
<div class="small bold yellow1 sh_b mb5 cntr"><img src="/images/icons/victory.png"> Игра в снежки! <img src="/images/icons/victory.png"></div>
<div class="dhr a_w50 mt5 mb5"></div>
<div class="small bold yellow sh_b mb5 cntr">до начала '._time1($dateStart__-time()).'</div>
<div class="bot"><a class="simple-but border" href="/dm_year/"><span><span>К сражению</span></span></a></div>
</div></div></div></div></div></div></div></div></div></div>';
}
}else{
$_SESSION['dm_year']=0;
}
}

















if($_SESSION['miss'] >= 1){
echo '<div class="trnt-block"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="mb10"><img height="14" width="14" src="/images/icons/victory.png"> <a class="green1 small bold td_u" href="missions/">Миссия выполнена</a> <img height="14" width="14" src="/images/icons/victory.png"></div>
<div class="bot"><a class="simple-but border" href="/missions/"><span><span>За наградой</span></span></a></div>
</div></div></div></div></div></div></div></div></div></div>';
}



if($user['kill_tanks'] < 3){
echo '<div class="trnt-block mb2"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content-mini"><div class="mt5 mb5 small green1 bold cntr">';
echo 'Уничтожь в бою 3 танка<br>';
if($user['kill_tanks'] >= 1){
echo ' <img height="14" width="14" src="/images/icons/online.png"> ';
}else{
echo ' <img height="14" width="14" src="/images/icons/offline.png"> ';
}
if($user['kill_tanks'] >= 2){
echo ' <img height="14" width="14" src="/images/icons/online.png"> ';
}else{
echo ' <img height="14" width="14" src="/images/icons/offline.png"> ';
}
if($user['kill_tanks'] >= 3){
echo ' <img height="14" width="14" src="/images/icons/online.png"> ';
}else{
echo ' <img height="14" width="14" src="/images/icons/offline.png"> ';
}
echo '</div></div></div></div></div></div></div></div></div></div></div>';
}






if($user['company_add']!=0 and $user['company']!=0 ){
$res_company_add = $mysqli->query('SELECT * FROM `company_add` WHERE `id` = "'.$user['company_add'].'" limit 1');
$company_add = $res_company_add->fetch_assoc();
echo '<div class="trnt-block mt5 mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content small">';
echo '<div class="bold"><span class="yellow1">';
if(!$company_add['ank']){echo '<span class="small green2">Объявление:</span>';}echo ' '.$company_add['text'].'</span><br></div>';
echo '<div class="dhr mt5 mb5 a_w50"></div>';
echo '<div class="cntr"><div class="gray1">';


if($company_add['user']){echo ''.nick($company_add['user']).', ';} echo ''.time_last($company_add['time']).'</div><a class="gray1 td_u" href="?actAdd"><span><span>скрыть</span></span></a></div>';
echo '</div></div></div></div></div></div></div></div></div></div>';
if(isset($_GET['actAdd'])){
$mysqli->query('UPDATE `users` SET `company_add` = "0" WHERE `id` = '.$user['id'].' LIMIT 1');
header('Location: ?');
exit();
}
}


if (isset($_SESSION['ses'])){
?>
<div class="trnt-block mb2"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content-mini cntr">
<?=$_SESSION['ses']?>
</div></div></div></div></div></div></div></div></div></div>
<?php
unset($_SESSION['ses']);
}


if (isset($_SESSION['ok'])){
?>
<?=$_SESSION['ok']?>
<?php
unset($_SESSION['ok']);
}




if($user['company']==0){
$res_zayavki = $mysqli->query("SELECT COUNT(*) FROM `company_zayavki` WHERE `time` >= ".time()." and `ank` = '".$user['id']."' and `company` != '0' ");
$k_post_zayavki = $res_zayavki->fetch_array(MYSQLI_NUM);
if($k_post_zayavki[0]>0){
echo '<div class="medium green1 bold cntr mb5 pt5"><img src="/images/icons/victory.png"> Вы приглашены в дивизию <img src="/images/icons/victory.png"></div>';
$max = 10;
$res = $mysqli->query("SELECT COUNT(*) FROM `company_zayavki` WHERE `time` >= ".time()." and `ank` = '".$user['id']."' and `company` != '0' ");
$k_post = $res->fetch_array(MYSQLI_NUM);
$k_page = k_page($k_post[0],$max);
$page = page($k_page);
$start = $max*$page-$max;
$k_post[0] = $start+1;
$res_company_zayavki = $mysqli->query('SELECT * FROM `company_zayavki` WHERE `time` >= '.time().' and `ank` = '.$user['id'].' and `company` != "0" ORDER BY `time` desc LIMIT '.$start.','.$max.' ');
while ($c_z = $res_company_zayavki->fetch_array()){
$res_company = $mysqli->query('SELECT * FROM `company` WHERE `id` = "'.$c_z['company'].'" LIMIT 1');
$company = $res_company->fetch_assoc();
if($company['side'] == 1){$side = 'federation';}else{$side = 'empire';}

echo '<div class="trnt-block"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content">
<div class="mb5 inbl"><div class="thumb fl"><img src="/images/avatar/clan/'.$company['avatar'].'.png" style="width:100%; border-radius: 9px;"><span class="mask2">&nbsp;</span></div>
<div class="ml58 small white sh_b bold">
Дивизия: <a href="/company/'.$company['id'].'/"><img class="vb" src="/images/side/'.$side.'.png?1"> <span class="green2">'.$company['name'].'</span></a><br>
Бонус: <span class="green2">+'.$company['shtab_param'].' к параметрам</span><br>
Уровень: <span class="green2">'.$company['level'].'</span>
</div><div class="clrb"></div></div>

<div class="bot"><table><tbody><tr>
<td class="w50 pr1"><a class="simple-but border" href="?ok"><span><span>Принять</span></span></a></td>
<td class="w50 pl1"><a class="simple-but border gray" href="?no"><span><span>Отказаться</span></span></a></td>
</tr></tbody></table></div>
</div></div></div></div></div></div></div></div></div></div>';


if(isset($_GET['ok'])){
if(!$c_z['id']){header('Location: ?');exit();}
if($c_z['ank']!=$user['id']){header('Location: ?');exit();}
if(!$company){$mysqli->query('DELETE FROM `company_zayavki` WHERE `id` = "'.$c_z['id'].'" ');header('Location: ?');exit();}
$res_company_col_us = $mysqli->query("SELECT COUNT(*) FROM `users` WHERE `company` = '".$company['id']."' ");
$company_col_us = $res_company_col_us->fetch_array(MYSQLI_NUM);
if($company['level']>=24){$company_mesta = 24;}else{$company_mesta = $company['level'];}
if($company_col_us[0]>=$company_mesta){header('Location: ?');exit();}
$_SESSION['ses'] = '<div class="buy-place-block pt2 mb10">
<div class="medium bold white cntr sh_b mt5 mb5">Вы действительно хотите вступить в дивизию?</div>
<a class="simple-but border w50 mXa mb10" w:id="confirmLink" href="?ok_"><span><span>да, подтверждаю</span></span></a>
<a class="simple-but border red w50 mXa" w:id="cancelLink" href="?"><span><span>нет, отмена</span></span></a>
</div>';
header('Location: ?');
exit();
}

if(isset($_GET['ok_'])){
if(!$c_z['id']){header('Location: ?');exit();}
if($c_z['ank']!=$user['id']){header('Location: ?');exit();}
if(!$company){$mysqli->query('DELETE FROM `company_zayavki` WHERE `id` = "'.$c_z['id'].'" ');header('Location: ?');exit();}
$res_company_col_us = $mysqli->query("SELECT COUNT(*) FROM `users` WHERE `company` = '".$company['id']."' ");
$company_col_us = $res_company_col_us->fetch_array(MYSQLI_NUM);
if($company['level']>=24){$company_mesta = 24;}else{$company_mesta = $company['level'];}
if($company_col_us[0]>=$company_mesta){header('Location: ?');exit();}

$res = mysqli_query($mysqli,'SELECT sum(rang) FROM crew_user WHERE `user`  = "'.$user['id'].'"');
if (FALSE === $res) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res);
$sum = $row[0];
$mysqli->query('UPDATE `company` SET `lvl_crew` = "'.($company['lvl_crew']+$sum).'" WHERE `id` = '.$company['id'].'');

$res_us_comp_ = $mysqli->query('SELECT * FROM `users` WHERE `company` = "'.$company['id'].'" LIMIT 1');
$us_comp_ = $res_us_comp_->fetch_assoc();
$mysqli->query('UPDATE `users` SET `company_add` = "'.$us_comp_['company_add'].'", `company` = "'.$company['id'].'"  WHERE `id` = "'.$user['id'].'" LIMIT 1');

$mysqli->query('INSERT INTO `company_user` SET `company` = "'.$company['id'].'", `company_rang` = "6", `company_time` = "'.time().'", `user` = "'.$user['id'].'"  ');

$text = "<span class='green1'>принят в дивизию</span>";
$mysqli->query('INSERT INTO `company_log` SET `company` = "'.$company['id'].'", `text` = "'.$text.'", `time` = "'.time().'", `user` = "'.$c_z['user'].'" , `ank` = "'.$user['id'].'" ');

$res = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user`  = "'.$user['id'].'" and `active`  = "1" limit 1');
$users_tanks = $res->fetch_assoc();
$mysqli->query('UPDATE `users_tanks` SET `a` = "'.($users_tanks['a']+$company['shtab_param']).'", `b` = "'.($users_tanks['b']+$company['shtab_param']).'", `t` = "'.($users_tanks['t']+$company['shtab_param']).'", `p` = "'.($users_tanks['p']+$company['shtab_param']).'" WHERE `id` = '.$users_tanks['id'].'');
if($company['polygon_time']>time() ){
$mysqli->query('UPDATE `users_tanks` SET `a` = "'.($users_tanks['a']+40).'", `b` = "'.($users_tanks['b']+40).'", `t` = "'.($users_tanks['t']+40).'", `p` = "'.($users_tanks['p']+40).'" WHERE `id` = '.$users_tanks['id'].'');
}
$mysqli->query('DELETE FROM `company_zayavki` WHERE `ank` = "'.$user['id'].'" ');
$mysqli->query('DELETE FROM `company_zayavki` WHERE `user` = "'.$user['id'].'" ');
$mysqli->query('DELETE FROM `company_battle_user_assault` WHERE `user` = "'.$user['id'].'" ');
header('Location: /company/'.$company['id'].'/');
exit();
}

if(isset($_GET['no'])){
if(!$c_z['id']){header('Location: ?');exit();}
if($c_z['ank']!=$user['id']){header('Location: ?');exit();}
$mysqli->query('DELETE FROM `company_zayavki` WHERE `id` = "'.$c_z['id'].'" ');
header('Location: ?');
exit();
}

}
}
}







if (isset($_SESSION['err'])){
?>
<div class="buy-place-block"><div class="feedbackPanelERROR"><div class="line1"><span class="feedbackPanelERROR">
<?=$_SESSION['err']?>
</span></div></div></div>
<?php
unset($_SESSION['err']);
}





































################################################################################################
#################################### ЧИСТКА (ТОЛЬЛКО АДМИН) #####################################
################################################################################################
if($user['id']==1){
###чистка не завершивших регистрацию гостей
$res = $mysqli->query("SELECT COUNT(*) FROM `start` WHERE `time_delete` < '".time()."'");
$col_us_no_reg = $res->fetch_array(MYSQLI_NUM);
if($col_us_no_reg[0]>0){
$res = $mysqli->query('SELECT * FROM `start` WHERE `time_delete` < '.time().' ');
$id_us_no_reg = $res->fetch_assoc();
$mysqli->query('DELETE FROM `traning` WHERE `user` = "'.$id_us_no_reg['user'].'" ');
$mysqli->query('DELETE FROM `users_tanks` WHERE `user` = "'.$id_us_no_reg['user'].'" ');
$mysqli->query('DELETE FROM `buildings_user` WHERE `user` = "'.$id_us_no_reg['user'].'" ');
$mysqli->query('DELETE FROM `ammunition_users` WHERE `user` = "'.$id_us_no_reg['user'].'" ');
$mysqli->query('DELETE FROM `buildings_polygon` WHERE `user` = "'.$id_us_no_reg['user'].'" ');
$mysqli->query('DELETE FROM `missions_user` WHERE `user` = "'.$id_us_no_reg['user'].'" ');
$mysqli->query('DELETE FROM `crew_user` WHERE `user` = "'.$id_us_no_reg['user'].'" ');
$mysqli->query('DELETE FROM `company_zayavki` WHERE `user` = "'.$id_us_no_reg['user'].'" ');
$mysqli->query('DELETE FROM `convoy_user` WHERE `user` = "'.$id_us_no_reg['user'].'" ');
$mysqli->query('DELETE FROM `skills_user` WHERE `user` = "'.$id_us_no_reg['user'].'" ');

$mysqli->query('DELETE FROM `users` WHERE `id` = "'.$id_us_no_reg['user'].'" ');
$mysqli->query('DELETE FROM `start` WHERE `user` = "'.$id_us_no_reg['user'].'" ');
}
###чистка боев которые не завершены и висят (игроки которые заходят, регаются, и не играют, оставляют бои --- их и чистим.)
$res = $mysqli->query("SELECT COUNT(*) FROM `battle` WHERE `time_delete` < '".time()."'");
$col_battle_no_act = $res->fetch_array(MYSQLI_NUM);
if($col_battle_no_act[0]>10){
$mysqli->query('DELETE FROM `battle` WHERE `time_delete` < '.time().' ');
}
###чистка заявок в диву с истекшим таймером
$res_company_zayavki = $mysqli->query("SELECT COUNT(*) FROM `company_zayavki` WHERE `time` < '".time()."'");
$col_company_zayavki = $res_company_zayavki->fetch_array(MYSQLI_NUM);
if($col_company_zayavki[0]>10){
$mysqli->query('DELETE FROM `company_zayavki` WHERE `time` < '.time().' ');
}



$mysqli->query('DELETE FROM `company_battle_log` WHERE `time` < '.(time()-(3600)).' ');
























################################################################################################
#################################### ИТОГИ ИГРЫ В СНЕЖКИ (ТОЛЬЛКО АДМИН) #####################################
################################################################################################
$res = $mysqli->query('SELECT * FROM `prom` WHERE `id` = 1 LIMIT 1');
$prom = $res->fetch_assoc();
if($prom['time_19']>0 and $prom['time_19']<time()){

#######################################################
$tur1 = $mysqli->query('SELECT * FROM `dm_year_turnir` WHERE `user` != "0" and `snowball` > "0" ORDER BY `snowball` desc LIMIT 1000');
while ($turnir1 = $tur1->fetch_array()){
$reyt_t = ''.++$k_post_t[0].'';
$text[$reyt_t] = '<font color=white>'.$reyt_t.'.<font> '.nick($turnir1['user']).' <font color="#FFDF8C">награда</font> <img title="Серебро" alt="Серебро" src="/images/icons/silver.png"> <font color=silver>'.floor($turnir1['snowball']/10).' серебра</font>';
$mysqli->query('UPDATE `users` SET `silver` = `silver` + "'.floor($turnir1['snowball']/10).'" WHERE `id` = "'.$turnir1['user'].'"');
$message = "<img border='0' src='/images/icons/exp.png'> <span style='color:#98c1ff;'><b>Турнир белых снежков завершен!</b></span> <img border='0' src='/images/icons/exp.png'>
<br><font color='white'>Ваша награда:</font> <img title='Серебро' alt='Серебро' src='/images/icons/silver.png'> <font color=silver>".floor($turnir1['snowball']/10)." серебра</font>";
$res = $mysqli->query('SELECT * FROM `dialog` WHERE ((`user` = 2 and `ank` = '.$turnir1['user'].') or (`user` = '.$turnir1['user'].' and `ank` = 2)) ');
$dialog = $res->fetch_assoc();
if(!$dialog){
$mysqli->query('INSERT INTO `dialog` SET `user` = "2", `ank` = "'.$turnir1['user'].'", `time` = "'.time().'" ');
$uid = mysqli_insert_id($mysqli);
$mysqli->query('INSERT INTO `pm` SET `dialog` = "'.$uid.'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$turnir1['user'].'" ');
$mysqli->query('INSERT INTO `pm_copy` SET `dialog` = "'.$uid.'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$turnir1['user'].'" ');
}else{
$mysqli->query('INSERT INTO `pm` SET `dialog` = "'.$dialog['id'].'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$turnir1['user'].'" ');
$mysqli->query('INSERT INTO `pm_copy` SET `dialog` = "'.$dialog['id'].'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$turnir1['user'].'" ');
$mysqli->query('UPDATE `dialog` SET `time` = "'.time().'" WHERE `id` = "'.$dialog['id'].'" LIMIT 1');
}
}

$t_1 = '<div class="cntr"><img border="0" src="/images/icons/exp.png"> <span style="color:#98c1ff;"><b>Турнир снежков завершен!</b></span> <img border="0" src="/images/icons/exp.png"></div>
<br>
<div class="cntr"><span style="color:white;">Поздравляем всех участников!</span></div>
<div class="cntr"><span style="color:white;">Топ-3 игрокам по турниру голубых снежков дополнительная награда: <img class="vb pb2" width="14" height="14" src="/images/icons/gold.png?1"> 100 золота!</span></div>
<br>
<div class="cntr"><span style="color:white;"><b><u>Турнир белых снежков:</u></b></span></div><div class="mt5"></div>
'.$text['1'].'<hr>'.$text['2'].'<hr>'.$text['3'].'<hr>'.$text['4'].'<hr>'.$text['5'].'<hr>'.$text['6'].'<hr>'.$text['7'].'<hr>'.$text['8'].'<hr>'.$text['9'].'<hr>'.$text['10'].'<hr> ';

#######################################################
$tur2 = $mysqli->query('SELECT * FROM `dm_year_turnir` WHERE `user` != "0" and `snowball_b` > "0" ORDER BY `snowball_b` desc LIMIT 1000');
while ($turnir2 = $tur2->fetch_array()){
$reyt2 = ''.++$k_post1[0].'';
if($reyt2<=3){$g = 100;}else{$g = 0;}
$text2[$reyt2] = '<font color=white>'.$reyt2.'.<font> '.nick($turnir2['user']).' <font color="#FFDF8C">награда</font> <img title="Золото" alt="Золото" src="/images/icons/gold.png"> <font color=gold>'.(floor($turnir2['snowball_b']/2)+$g).' золота</font>';
$mysqli->query('UPDATE `users` SET `gold` = `gold` + "'.(floor($turnir2['snowball_b']/2)+$g).'" WHERE `id` = "'.$turnir2['user'].'"');
$message = "<img border='0' src='/images/icons/exp.png'> <span style='color:#3886fd;'><b>Турнир голубых снежков завершен!</b></span> <img border='0' src='/images/icons/exp.png'>
<br><font color='white'>Ваша награда:</font> <img title='Золото' alt='Золото' src='/images/icons/gold.png'> <font color=gold>".(floor($turnir2['snowball_b']/2)+$g)." золота</font>";
$res = $mysqli->query('SELECT * FROM `dialog` WHERE ((`user` = 2 and `ank` = '.$turnir2['user'].') or (`user` = '.$turnir2['user'].' and `ank` = 2)) ');
$dialog = $res->fetch_assoc();
if(!$dialog){
$mysqli->query('INSERT INTO `dialog` SET `user` = "2", `ank` = "'.$turnir2['user'].'", `time` = "'.time().'" ');
$uid = mysqli_insert_id($mysqli);
$mysqli->query('INSERT INTO `pm` SET `dialog` = "'.$uid.'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$turnir2['user'].'" ');
$mysqli->query('INSERT INTO `pm_copy` SET `dialog` = "'.$uid.'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$turnir2['user'].'" ');
}else{
$mysqli->query('INSERT INTO `pm` SET `dialog` = "'.$dialog['id'].'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$turnir2['user'].'" ');
$mysqli->query('INSERT INTO `pm_copy` SET `dialog` = "'.$dialog['id'].'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$turnir2['user'].'" ');
$mysqli->query('UPDATE `dialog` SET `time` = "'.time().'" WHERE `id` = "'.$dialog['id'].'" LIMIT 1');
}
}
$t_2 = '<br><br><div class="cntr"><span style="color:#3886fd;"><b><u>Турнир голубых снежков:</u></b></span></div><div class="mt5"></div>
'.$text2['1'].'<hr>'.$text2['2'].'<hr>'.$text2['3'].'<hr>'.$text2['4'].'<hr>'.$text2['5'].'<hr>'.$text2['6'].'<hr>'.$text2['7'].'<hr>'.$text2['8'].'<hr>'.$text2['9'].'<hr>'.$text2['10'].'
<hr> ';
#######################################################
$text1 = ('<div class="cntr"><img border="0" src="/images/icons/exp.png"> ');
$name = "Итоги турнира снежков";
$text = ''.$t_1.''.$t_2.'';
$mysqli->query("INSERT INTO `forum_topik` SET `name` = '".$name."', `text` = '".$text."', `time` = ".time().", `razdel` = '1', `user` = '1' ");
$uid = mysqli_insert_id($mysqli);
$res = $mysqli->query('SELECT * FROM `users` WHERE `viz` > '.(time()-(86400*7)).' ORDER BY `id` desc limit 1000');
while ($uss = $res->fetch_array()){
$mysqli->query("INSERT INTO `forum_news` SET `name` = '".$name."', `topik` = '".$uid."', `time` = '".(time()+(86400*3))."', `user` = '".$uss['id']."'");
} 

$mysqli->query('UPDATE `prom` SET `act_19` = "0", `time_19` = "0" WHERE `id` = 1');
$mysqli->query('DELETE FROM `dm_year_log` WHERE `id` ');
$mysqli->query('DELETE FROM `dm_year_results` WHERE `id` ');
$mysqli->query('DELETE FROM `dm_year_turnir` WHERE `id` ');
$mysqli->query('DELETE FROM `dm_year_user` WHERE `id` '); 
}





























}
################################################################################################
#################################### ЧИСТКА (ТОЛЬЛКО АДМИН) #####################################
################################################################################################





/* создать крон задачу с очисткой прошедших спецзаданий!!!!!! */











################################################################################################
############### обработка системы (позже можно добавить кроном для оптимизации) ################
################################################################################################
$res = $mysqli->query('SELECT * FROM `buildings_polygon` WHERE `user` = '.$user['id'].' LIMIT 1');
$buildings_polygon = $res->fetch_assoc();

if(($buildings_polygon['a_time']<time() and $buildings_polygon['a_time']>0) or ($buildings_polygon['b']>0 and $buildings_polygon['a_time']<time())){
$res = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user`  = "'.$user['id'].'" and `active`  = "1" limit 1');
$users_tanks = $res->fetch_assoc();
$mysqli->query('UPDATE `users_tanks` SET `a` = '.($users_tanks['a']-$buildings_polygon['a']).' WHERE `id` = '.$users_tanks['id'].' LIMIT 1');
$mysqli->query('UPDATE `buildings_polygon` SET `a` = "0", `a_time` = "0" WHERE `id` = '.$buildings_polygon['id'].' LIMIT 1');
}
if(($buildings_polygon['b_time']<time() and $buildings_polygon['b_time']>0) or ($buildings_polygon['b']>0 and $buildings_polygon['b_time']<time())){
$res = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user`  = "'.$user['id'].'" and `active`  = "1" limit 1');
$users_tanks = $res->fetch_assoc();
$mysqli->query('UPDATE `users_tanks` SET `b` = '.($users_tanks['b']-$buildings_polygon['b']).' WHERE `id` = '.$users_tanks['id'].' LIMIT 1');
$mysqli->query('UPDATE `buildings_polygon` SET `b` = "0", `b_time` = "0" WHERE `id` = '.$buildings_polygon['id'].' LIMIT 1');
}
if(($buildings_polygon['t_time']<time() and $buildings_polygon['t_time']>0) or ($buildings_polygon['b']>0 and $buildings_polygon['t_time']<time())){
$res = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user`  = "'.$user['id'].'" and `active`  = "1" limit 1');
$users_tanks = $res->fetch_assoc();
$mysqli->query('UPDATE `users_tanks` SET `t` = '.($users_tanks['t']-$buildings_polygon['t']).' WHERE `id` = '.$users_tanks['id'].' LIMIT 1');
$mysqli->query('UPDATE `buildings_polygon` SET `t` = "0", `t_time` = "0" WHERE `id` = '.$buildings_polygon['id'].' LIMIT 1');
}
if(($buildings_polygon['p_time']<time() and $buildings_polygon['p_time']>0) or ($buildings_polygon['b']>0 and $buildings_polygon['p_time']<time())){
$res = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user`  = "'.$user['id'].'" and `active`  = "1" limit 1');
$users_tanks = $res->fetch_assoc();
$mysqli->query('UPDATE `users_tanks` SET `p` = '.($users_tanks['p']-$buildings_polygon['p']).' WHERE `id` = '.$users_tanks['id'].' LIMIT 1');
$mysqli->query('UPDATE `buildings_polygon` SET `p` = "0", `p_time` = "0" WHERE `id` = '.$buildings_polygon['id'].' LIMIT 1');
}





// добавить кроном каждую минуту, т.к. во многих локах данная переменная повторяется, что снижает производительность
$res = $mysqli->query('SELECT * FROM `vip` WHERE `user` = "'.$user['id'].'" LIMIT 1');
$vip = $res->fetch_assoc();
if($vip['time4']<time() and $vip['time4']>0){
$res = $mysqli->query('SELECT * FROM `buildings_polygon` WHERE `user` = '.$user['id'].' LIMIT 1');
$b_polygon = $res->fetch_assoc();
if($b_polygon){
$res = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user`  = "'.$user['id'].'" and `active`  = "1" limit 1');
$u_t = $res->fetch_assoc();
if($b_polygon['a']!=70){
$mysqli->query("UPDATE `buildings_polygon` SET `a` = '".($b_polygon['a']-10)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `a` = '.($u_t['a']-10).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}else{
$mysqli->query("UPDATE `buildings_polygon` SET `a` = '".($b_polygon['a']-20)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `a` = '.($u_t['a']-20).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}
if($b_polygon['b']!=70){
$mysqli->query("UPDATE `buildings_polygon` SET `b` = '".($b_polygon['b']-10)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `b` = '.($u_t['b']-10).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}else{
$mysqli->query("UPDATE `buildings_polygon` SET `b` = '".($b_polygon['b']-20)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `b` = '.($u_t['b']-20).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}
if($b_polygon['t']!=70){
$mysqli->query("UPDATE `buildings_polygon` SET `t` = '".($b_polygon['t']-10)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `t` = '.($u_t['t']-10).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}else{
$mysqli->query("UPDATE `buildings_polygon` SET `t` = '".($b_polygon['t']-20)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `t` = '.($u_t['t']-20).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}
if($b_polygon['p']!=70){
$mysqli->query("UPDATE `buildings_polygon` SET `p` = '".($b_polygon['p']-10)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `p` = '.($u_t['p']-10).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}else{
$mysqli->query("UPDATE `buildings_polygon` SET `p` = '".($b_polygon['p']-20)."' WHERE `id` = '".$b_polygon['id']."' LIMIT 1");
$mysqli->query('UPDATE `users_tanks` SET `p` = '.($u_t['p']-20).' WHERE `id` = '.$u_t['id'].' LIMIT 1');
}
}
$mysqli->query("UPDATE `vip` SET `time4` = '0' WHERE `id` = '".$vip['id']."' LIMIT 1");
}


// добавить кроном каждую минуту, т.к. во многих локах данная переменная повторяется, что снижает производительность
if($vip['time1']<time() and $vip['time1']>0){
$mysqli->query('UPDATE `users_tanks` SET `a` = `a` - "100", `b` = `b` - "100", `t` = `t` - "100", `p` = `p` - "100" WHERE `user` = '.$user['id'].' and `active` = "1" LIMIT 1');
$mysqli->query("UPDATE `vip` SET `time1` = '0' WHERE `id` = '".$vip['id']."' LIMIT 1");
}// добавить кроном каждую минуту, т.к. во многих локах данная переменная повторяется, что снижает производительность




/* if($user['id']==1){
$mysqli->query('UPDATE `users` SET `gold` = `gold` + 500 WHERE `id` ');
} */
///$mysqli->query('UPDATE `buildings_user` SET `time_production` = '.(time()+($time_4*60)).' WHERE `id` = '.$buildings_user['id'].' LIMIT 1');
################################################################################################
############### обработка системы (позже можно добавить кроном для оптимизации) ################
################################################################################################








}
}
?>