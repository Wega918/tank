<?php
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id']){
header('Location: /');
exit();
}
##############################################################################################################################
##############################################################################################################################
##############################################################################################################################
##############################################################################################################################
echo '<a class="simple-but border" href="?creat_price"><span><span>Обновить Price</span></span></a>';
echo '<a class="simple-but border" href="?refresh_price_"><span><span>Обновить Price_</span></span></a>';

if(isset($_GET['creat_price'])){
$ch = curl_init('https://api.binance.com/api/v3/ticker/price');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HEADER, false);
$html = curl_exec($ch);
curl_close($ch);
$obj = json_decode($html);

for ($i = 0; $i <= 2234; $i++) {
$res = $mysqli->query('SELECT * FROM `price` WHERE `symbol` = "'.$obj[$i]->{'symbol'}.'" LIMIT 1');
$price = $res->fetch_assoc();

if(!$price){
$mysqli->query('INSERT INTO `price` SET `symbol` = "'.$obj[$i]->{'symbol'}.'", `price` = '.$obj[$i]->{'price'}.' ');
}
if($price['price']!=$obj[$i]->{'price'}){
$mysqli->query('UPDATE `price` SET `price` = '.$obj[$i]->{'price'}.' WHERE `symbol` = "'.$obj[$i]->{'symbol'}.'" LIMIT 1');
}
}

$_SESSION['err'] = '<div class="trnt-block"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr"><div class="red1">
Записи Price обновлены!
</div></div></div></div></div></div></div></div></div></div></div>';
header('Location: ?');
exit();
}

##############################################################################################################################

if(isset($_GET['refresh_price_'])){
$ch = curl_init('https://api.binance.com/api/v3/ticker/price');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HEADER, false);
$html = curl_exec($ch);
curl_close($ch);
$obj = json_decode($html);

$res = $mysqli->query('SELECT * FROM `price` WHERE `id` ORDER BY `id` asc ');
while ($pr = $res->fetch_array()){
$i = ''.++$k_post[0].'';
$res2 = $mysqli->query('SELECT * FROM `price_` WHERE `symbol` = "'.$pr['symbol'].'" LIMIT 1');
$price_ = $res2->fetch_assoc();

if(!$price_){
$mysqli->query('INSERT INTO `price_` SET `symbol` = "'.$pr['symbol'].'", `price` = '.$pr['price'].' ');
}
if($price_ and $price_['price']!=$obj[$i]->{'price'}){
$mysqli->query('UPDATE `price_` SET `price` = '.$obj[$i]->{'price'}.' WHERE `symbol` = "'.$obj[$i]->{'symbol'}.'" LIMIT 1');
}
}

$_SESSION['err'] = '<div class="trnt-block"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr"><div class="red1">
Записи Price_ обновлены!
</div></div></div></div></div></div></div></div></div></div></div>';
header('Location: ?');
exit();
}
##############################################################################################################################
##############################################################################################################################
##############################################################################################################################
##############################################################################################################################


echo '<hr>';
$res5 = $mysqli->query('SELECT * FROM `price` WHERE `id` ORDER BY `id` asc LIMIT 10');
while ($pr = $res5->fetch_array()){
$reyt = ''.++$k_post[0].'';
$res3 = $mysqli->query('SELECT * FROM `price` WHERE `symbol` = "'.$pr['symbol'].'" LIMIT 1');
$price = $res3->fetch_assoc();
$res4 = $mysqli->query('SELECT * FROM `price_` WHERE `symbol` = "'.$pr['symbol'].'" LIMIT 1');
$price_ = $res4->fetch_assoc();

if($pr['price']>$price_['price']){
print '<font color=red>'.$reyt.'. '.$pr['symbol'].' : '.$pr['price'].' </font><br>';
}
if($price_ and $pr['price']<$price_['price']){
print '<font color=green>'.$reyt.'. '.$pr['symbol'].' : '.$pr['price'].' > '.$price_['price'].' </font><br>';
}

}



##############################################################################################################################
##############################################################################################################################
##############################################################################################################################
##############################################################################################################################











//$ch = curl_init('https://api.binance.com/api/v3/ticker/price?symbol=USDTUAH');
/* $ch = curl_init('https://api.binance.com/api/v3/ticker/price');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HEADER, false);
$html = curl_exec($ch);
curl_close($ch);
$obj = json_decode($html);

echo '<hr>';
for ($i = 0; $i <= 2234; $i++) {
print ''.$i.'. '.$obj[$i]->{'symbol'}.' : '.$obj[$i]->{'price'}.'';
echo '<br>';
}
 */


















/* 
$title = 'Танки';
require_once ('../system/function.php');
require_once ('../system/header.php');


$rand_img_1 = rand(-110,-130); // верх / них
$rand_img_2 = rand(-10,10); // лево / право
$rand_img_3 = rand(1,120); // лево / право

$rand_img_11 = rand(-110,-130); // верх / них
$rand_img_22 = rand(-10,10); // лево / право
$rand_img_33 = rand(1,120); // лево / право

?>

<div class="trnt-block">
<div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8">
<div class="wrap-content custombg farm_1">
<div class="small bold cD2 cntr sh_b pb2"><img class="vb" height="14" width="14" src="/images/side/empire/2.png?1"> Логош</div>
<table>
<tbody><tr>
<td class="cntr">
<a href="battle?2-2.ILinkListener-lastOpponentPanel-root-bgDiv-attackLink1">

<img src="imgSmall.png" style="margin:10px 10px 10px 25px;" />
<img src="2,2.png" style="margin: <?=$rand_img_1?>px 10px <?=$rand_img_2?>px <?=$rand_img_3?>px;" />
<img src="2,2.png" style="margin: <?=$rand_img_11?>px 10px <?=$rand_img_22?>px <?=$rand_img_33?>px;" />





</div>

</a></td>
</tr>
</tbody></table>
<div class="cntr small bold mb2 pb0">
<img src="/images/upgrades/starFull.png" height="14" width="14"> <span class="green2">Танковая мощь: 714</span>
</div>

<div class="bot">
<a class="simple-but border" href="battle?2-2.ILinkListener-lastOpponentPanel-root-bgDiv-attackLink2"><span><span>Взять реванш</span></span></a>
</div>

</div>
</div></div></div></div></div></div></div></div>
</div>


<?
echo '<br>';
//<img src="1,3.png" style="margin:50px 10px -10px -200px;" />
//<img src="1,3.png" style="margin:50px 10px -10px -210px;" />
 */
require_once ('../system/footer.php');
?>