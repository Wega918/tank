<?php
require_once ('../system/function.php');


	/**
	* 30430 - ID Аккаунта
	* 26612 - ID Проекта
	* 4m0tk8x7rdw5mARx - Секретный код проекта(ключ API) ~ H2
	* Меняйте этот код секретный и ID'ы ниже
	**/
/* payment_method
https://sandbox-secure.xsolla.com/paystation2/?access_token=BearereyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE5NjIyMzQwNDgsImlzcyI6Imh0dHBzOi8vbG9naW4ueHNvbGxhLmNvbSIsImlhdCI6MTU2MjE0NzY0OCwidXNlcm5hbWUiOiJ4c29sbGEiLCJ4c29sbGFfbG9naW5fYWNjZXNzX2tleSI6IjA2SWF2ZHpDeEVHbm5aMTlpLUc5TmMxVWFfTWFZOXhTR3ZEVEY4OFE3RnMiLCJzdWIiOiJkMzQyZGFkMi05ZDU5LTExZTktYTM4NC00MjAxMGFhODAwM2YiLCJlbWFpbCI6InN1cHBvcnRAeHNvbGxhLmNvbSIsInR5cGUiOiJ4c29sbGFfbG9naW4iLCJ4c29sbGFfbG9naW5fcHJvamVjdF9pZCI6ImU2ZGZhYWM2LTc4YTgtMTFlOS05MjQ0LTQyMDEwYWE4MDAwNCIsInB1Ymxpc2hlcl9pZCI6MTU5MjR9.GCrW42OguZbLZTaoixCZgAeNLGH2xCeJHxl8u8Xn2aI



https://secure.xsolla.com/paystation3/desktop/pricepoint/?access_token=xyp5Tivaua95PUmhZZC6prWvkAhjy56n&preferences=eyJpdGVtUHJvbW90aW9ucyI6IltdIn0-&payment_method=1380&sessional=eyJoaXN0b3J5IjpbWyJwcmljZXBvaW50Iix0cnVlXV19
https://secure.xsolla.com/paystation3/desktop/pricepoint/?access_token=q8qa839tBe2i7zqrSewZtqWnXdaavcTS&preferences=eyJpdGVtUHJvbW90aW9ucyI6IltdIn0-&payment_method=1380&sessional=eyJoaXN0b3J5IjpbWyJwcmljZXBvaW50Iix0cnVlXV19




https://store.xsolla.com/api/v2/project/53262/payment/item/gold



curl -i -X POST \
  'https://store.xsolla.com/api/v2/project/{project_id}/payment/item/{item_sku}' \
  -H 'Authorization: Bearer <YOUR_JWT_HERE>' \
  -H 'Content-Type: application/json' \
  -d '{
    "sandbox": true,
    "quantity": 5,
    "settings": {
      "ui": {
        "size": "large",
        "theme": "default",
        "version": "desktop",
        "desktop": {
          "header": {
            "is_visible": true,
            "visible_logo": true,
            "visible_name": true,
            "visible_purchase": true,
            "type": "normal",
            "close_button": false
          }
        },
        "mobile": {
          "footer": {
            "is_visible": true
          },
          "header": {
            "close_button": false
          }
        }
      }
    },
    "custom_parameters": {
      "character_id": "ingameUsername"
    }
  }'
  
  
*/








if (isset($_GET['baks'])){
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, 'https://api.xsolla.com/merchant/merchants/30430/token');
    $h = array("Content-Type: application/json");
    curl_setopt($curl, CURLOPT_HTTPHEADER, $h);
    curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    curl_setopt($curl, CURLOPT_USERPWD, '30430:4m0tk8x7rdw5mARx');
    curl_setopt($curl, CURLOPT_RETURNTRANSFER,true);
    curl_setopt($curl, CURLOPT_POST, true);
    $json = array("user" => array("id" => array("value" => $user['id'], "hidden" => true)), "settings" => array("project_id" => 197256, "payment_method" => 1380));
    $json = json_encode($json);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $json);
    $token = json_decode(curl_exec($curl))->token;
    curl_close($curl);
    if (isset($token)) {

//header("Location:https://sandbox-secure.xsolla.com/paystation2/?access_token=$token");
header("Location:https://secure.xsolla.com/paystation2/?access_token=$token");
exit;
}else{
$_SESSION['err'] = 'Ошибка платежной системы - обратитесь к администратору';
header("Location: ?");
exit;
}
}



/*
https://secure.xsolla.com/paystation3/desktop/payment/?access_token=wfs0RTsjKXGQXM2YJ80AcfLZQoobGD3W_ru_&preferences=eyJpdGVtUHJvbW90aW9ucyI6IltdIn0-&sessional=eyJoaXN0b3J5IjpbWyJzYXZlZG1ldGhvZCJdLFsibGlzdCJdLFsicGF5bWVudCIsdHJ1ZV1dfQ--
https://secure.xsolla.com/paystation3/desktop/payment/?access_token=q8qa2CxKwCzYXD770zAcqLz0K3zcolqi&preferences=eyJpdGVtUHJvbW90aW9ucyI6IltdIn0-&sessional=eyJoaXN0b3J5IjpbWyJzYXZlZG1ldGhvZCJdLFsibGlzdCJdLFsicGF5bWVudCIsdHJ1ZV1dfQ--
https://secure.xsolla.com/paystation3/desktop/pricepoint/?access_token=q8qa2CxKwCzYXD770zAcqLz0K3zcolqi&preferences=eyJpdGVtUHJvbW90aW9ucyI6IltdIn0-& sessional=eyJoaXN0b3J5IjpbWyJwcmljZXBvaW50Iix0cnVlXV19
 */

$title = 'Покупка баксов';
require_once ('../system/header.php');


echo '<div class="ttl-m lblue mrg_ttl mt10 mb10"><div class="tr"><div class="tc">'.$title.'</div></div></div>';

echo '<center><a href="?baks" class="bbtn mt5 mb5"><span class="br"><span class="bc">Перейти к покупке</span></span></a></center>';

echo '<div class="marea mt10"><div class="wr_bg"><div class="wr_c1"><div class="wr_c2"><div class="wr_c3"><div class="wr_c4">';
echo '<div class="mbtn"><div class="mb_r"><div class="mb_c"><a href="'.$HOME.'" class="mb_ttl back">Вернуться</a></div></div></div>';
echo '</div></div></div></div></div></div>';







require_once ('../system/footer.php');
?>
