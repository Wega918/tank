<?php
define('DB_HOST', 'localhost'); // сервер
define('DB_NAME', 'marsgame_name'); // имя базы
define('DB_USER', 'marsgame_name'); // пользователь
define('DB_PASS', 'j2eJeQLj8QkkF'); // пароль
define('XSOLLA_CODE', 'fc511CM73zTcz7gp');