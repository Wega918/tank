<?php
include '../system/function.php';
include '../system/header.php';  

      
if(!isset($user)){
echo "Только для зарегестрированых";
}else{
header('Location: '.$HOME.'pay/');
$_SESSION['ok'] = 'Платеж выполнен! Начисление прошло успешно!';
exit();
}
include '../system/footer.php';
?>