<?php
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id']) {
header('Location: '.$HOME.'');
exit();
}
if(!$start) {
header('Location: '.$HOME.'');
exit();
}
if($start['step'] == 1) {
header('Location: '.$HOME.'1/');
exit();
}







$res = $mysqli->query('SELECT * FROM `tanks` WHERE `id` = '.$start['tank_select'].' ');
$users_tanks = $res->fetch_assoc();

$res = $mysqli->query('SELECT * FROM `tanks` WHERE `id` = '.$start['ank_tanks'].' ');
$ank_tanks = $res->fetch_assoc();


if($users_tanks['tip'] == 1){$tip = 'average';} // СТ
if($users_tanks['tip'] == 2){$tip = 'heavy';} // ТТ
if($users_tanks['tip'] == 3){$tip = 'SAU';} // САУ

if($ank_tanks['tip'] == 1){$tip1 = 'average';} // СТ
if($ank_tanks['tip'] == 2){$tip1 = 'heavy';} // ТТ
if($ank_tanks['tip'] == 3){$tip1 = 'SAU';} // САУ

if(isset($_GET['attack'])){
$mysqli->query('UPDATE `users` SET `fuel` = '.($user['fuel'] = 300).', `silver` = '.($user['silver'] = 50).' WHERE `id` = '.$user['id'].' LIMIT 1');
$mysqli->query('UPDATE `start` SET `step` = "3" WHERE `id` = '.$start['id'].' LIMIT 1');
header('Location: ?');
exit();
}
if(isset($_GET['angar'])){
if($start['ref']){
$mysqli->query('INSERT INTO `ref` (`user`,`ank`) VALUES ("'.$start['ref'].'", "'.$user['id'].'")');
}
$mysqli->query('DELETE FROM `start` WHERE `user` = "'.$user['id'].'" ');
$mysqli->query('UPDATE `users` SET `start` = "1" WHERE `id` = '.$user['id'].' LIMIT 1');

$message = "<span class='admin'><p><b>Справка:</b><br>
В игре предстоит управлять 50-тонным танком!<br>
 - Строить и улучшать личную базу.<br>
 - Улучшать экипаж своей боевой машины, модифицировать и апгрейдить её.<br>
 - Участвовать в исторических сражениях.<br>
 - Выполнять интересные миссии.<br>
 - Прокачивать свой уровень опытного бойца, получать за это награды и звания, <b>чтобы твоего танка боялись все!</b><br>
</p></span>";

$res = $mysqli->query('SELECT * FROM `dialog` WHERE ((`user` = 2 and `ank` = '.$user['id'].') or (`user` = '.$user['id'].' and `ank` = 2)) ');
$dialog = $res->fetch_assoc();
if(!$dialog){
$mysqli->query('INSERT INTO `dialog` SET `user` = "2", `ank` = "'.$user['id'].'", `time` = "'.time().'" ');
$uid = mysqli_insert_id($mysqli);
$mysqli->query('INSERT INTO `pm` SET `dialog` = "'.$uid.'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$user['id'].'" ');
$mysqli->query('INSERT INTO `pm_copy` SET `dialog` = "'.$uid.'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$user['id'].'" ');
}else{
$mysqli->query('INSERT INTO `pm` SET `dialog` = "'.$dialog['id'].'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$user['id'].'" ');
$mysqli->query('INSERT INTO `pm_copy` SET `dialog` = "'.$dialog['id'].'", `text` = "'.$message.'", `time` = "'.time().'", `user` = "2", `ank` = "'.$user['id'].'" ');
$mysqli->query('UPDATE `dialog` SET `time` = "'.time().'" WHERE `id` = "'.$dialog['id'].'" LIMIT 1');
}


header('Location: /');
exit();
}




if($start['step'] == 2) {
echo '
<div class="trnt-block mb6">
<div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8">
<div class="wrap-content">
<div class="imgtxt bshd wht btxt">
<div class="thumb fl"><img src="/images/unit_data_block_image.jpg" alt="image"><span class="mask1">&nbsp;</span></div>
<div class="ml58 small white sh_b bold">
<span class="green2">Командир</span><br>
Враг на горизонте! Атакуй его!<br>
</div>
<div class="clrb"></div>
</div>
</div>
</div></div></div></div></div></div></div></div>
</div>

<div class="trnt-block" w:id="root">
<div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8">
<div class="wrap-content">';
}elseif($start['step'] == 3) {
echo '<div class="cntr mt5 mb5 bold green1">
<div class="mb2">Потрясающе!</div>
<div class="small">Ты прирожденный танковый ас!</div>
</div>
<div class="trnt-block mb2">
<div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8">
<div class="wrap-content sh_b cntr bold green1">
<div class="mb2">
<img height="14" width="14" src="/images/icons/victory.png"> Противник уничтожен! <img height="14" width="14" src="/images/icons/victory.png">
</div>
<div class="small white"><span class="nwr">
<img class="ico vm" src="/images/icons/fuel.png" alt="Топливо" title="Топливо"> 300
 топлива</span><span class="nwr">
<img class="ico vm" src="/images/icons/silver.png" alt="Серебро" title="Серебро"> 50
 серебра</span></div>
</div>
</div></div></div></div></div></div></div></div>
</div>';
}






echo '<center><div class="wrap-content custombg angar_1" style="width:95%; border-radius: 10px;"> 
<br>

<table><tbody><tr>';

echo '<td style="width:45%;padding-right:4px;"><div style="position:relative;">
<div class="small bold cD2 cntr sh_b pb5 pt5"><font size=1%>'.$user['login'].'</font><br><img width="10%" src="/images/tanks/'.$tip.'.png"><span class="gray1"><font size=1>'.$users_tanks['name'].'</font></span></div><img class="tank-img" alt="tank" src="/images/tanks/'.$tip.'/'.$users_tanks['country'].'/'.$users_tanks['name'].'_.png" style="width:100%;">
</div></td>';

echo '<td style="width:10%;padding-right:4px;"><div style="position:relative;"></div></td>';
if($start['step'] == 2) {
echo '<td style="width:45%;padding-left:4px;"><div style="position:relative;">
<div class="small bold cD2 cntr sh_b pb5 pt5"><font color=red size=1%>'.$start['ank_nick'].'</font><br><img width="10%" src="/images/tanks/'.$tip1.'.png"><span class="gray1"><font size=1>'.$ank_tanks['name'].'</font></span></div><a href="?attack"><img class="tank-img" alt="tank" src="/images/tanks/'.$tip1.'/'.$ank_tanks['country'].'/'.$ank_tanks['name'].'.png" style="width:100%;"></a>
</td>';
}elseif($start['step'] == 3) {
echo '<td style="width:45%;padding-left:4px;"><div style="position:relative;">
<div class="small bold cD2 cntr sh_b pb5 pt5"><font color=red size=1%>'.$start['ank_nick'].'</font><br><img width="10%" src="/images/tanks/'.$tip1.'.png"><span class="gray1"><font size=1>'.$ank_tanks['name'].'</font></span></div><a href="?angar"><img class="tank-img" alt="tank" src="/images/tanks/'.$tip1.'/'.$ank_tanks['country'].'/'.$ank_tanks['name'].'/'.$ank_tanks['name'].'_3.png" style="width:100%;"></a>
</td>';
}
echo '</tr></tbody></table>
<br>';

echo '</div></center>';






if($start['step'] == 2) {
echo '<div class="bot"><a class="simple-but border" w:id="findEnemy" href="?attack"><span><span>Атаковать</span></span></a></div>';
}elseif($start['step'] == 3) {
echo '<div class="bot"><a class="simple-but border" w:id="findEnemy" href="?angar"><span><span>Войти в ангар</span></span></a></div>';
}
echo '</div></div></div></div></div></div></div></div></div></div></div>';


//require_once ('system/footer.php');
?>