<?php
require_once ('../system/function.php');
require_once ('../system/header.php');
/*$mult = mysqli_result(mysqli_query("SELECT COUNT(*) FROM `users` WHERE `ip` = '".strong($_SERVER['REMOTE_ADDR'])."' "),0);
if($mult >= 1){
header('Location: '.$HOME.' ');
$_SESSION['err'] = 'Не Пытайся Зарегистрировать еще одного персонажа!';
exit();
}*/
if(!$user['id']) {
header('Location: /');
exit();
}


if(!$user['id']) {
header('Location: '.$HOME.'start/');
exit();
}else{
if(!$start) {
header('Location: '.$HOME.'');
exit();
}
if(!$user['id']) {
header('Location: '.$HOME.'');
exit();
}
if($start['step']==1 and $_SERVER['PHP_SELF'] != '/start/1.php') {
header('Location: '.$HOME.'1/');
exit();
}elseif($start['step']==2) {
header('Location: '.$HOME.'2/');
exit();
}
}

$res = $mysqli->query('SELECT * FROM `tanks` WHERE `country` = "'.$start['country'].'" ORDER BY RAND() LIMIT 1 ');
$RAND_TANK = $res->fetch_assoc();








echo '<div class="trnt-block mt10 mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr white bold">
<div class="medium green2 sh_b mb5">Выбери себе танк!</div>
</div></div></div></div></div></div></div></div></div></div>';

if($start['country']!='GERMANY') {$country1 = 'opacity:0.4;';}else{$country1 = '';}
if($start['country']!='SSSR') {$country2 = 'opacity:0.4;';}else{$country2 = '';}
if($start['country']!='USA') {$country3 = 'opacity:0.4;';}else{$country3 = '';}



if($start['country']=='GERMANY') {$country_miss = 1;$country = 'germany';}elseif($start['country']=='SSSR') {$country_miss = 2;$country = 'ussr';}elseif($start['country']=='USA') {$country_miss = 3;$country = 'usa';}

if(isset($_GET['sel1'])){$mysqli->query('UPDATE `start` SET `tank_select` = "'.$RAND_TANK['id'].'", `country` = "GERMANY" WHERE `id` = "'.$start['id'].'" LIMIT 1');header('Location: '.$HOME.'1/');exit();}
if(isset($_GET['sel2'])){$mysqli->query('UPDATE `start` SET `tank_select` = "'.$RAND_TANK['id'].'", `country` = "SSSR" WHERE `id` = "'.$start['id'].'" LIMIT 1');header('Location: '.$HOME.'1/');exit();}
if(isset($_GET['sel3'])){$mysqli->query('UPDATE `start` SET `tank_select` = "'.$RAND_TANK['id'].'", `country` = "USA" WHERE `id` = "'.$start['id'].'" LIMIT 1');header('Location: '.$HOME.'1/');exit();}

echo '<div class="trnt-block mb2"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content">
<table class="cntr small bold"><tbody><tr>
<td style="width:33%;"><a class="white" w:id="selectGermany" href="?sel1">Германия<br><img src="/images/flags/germany.png" width="70" height="47" w:id="flagImg" style="'.$country1.'"></a></td>
<td style="width:33%;"><a class="white" w:id="selectUssr" href="?sel2">СССР<br><img src="/images/flags/ussr.png" width="70" height="47" w:id="flagImg" style="'.$country2.'"></a></td>
<td style="width:33%;"><a class="white" w:id="selectUsa" href="?sel3">США<br><img src="/images/flags/usa.png" width="70" height="47" w:id="flagImg" style="'.$country3.'"></a></td>
</tr></tbody></table></div></div></div></div></div></div></div></div></div></div>';




$res = $mysqli->query('SELECT * FROM `tanks` WHERE `id` = "'.$start['tank_select'].'" LIMIT 1');
$TANK = $res->fetch_assoc();

if($TANK['tip'] == 1){$tip_tanks = 'average';$tip = 'СРЕДНИЙ ТАНК';} // СТ
if($TANK['tip'] == 2){$tip_tanks = 'heavy';$tip = 'ТЯЖЕЛЫЙ ТАНК';} // ТТ
if($TANK['tip'] == 3){$tip_tanks = 'SAU';$tip = 'ПТ-САУ';} // САУ

if($TANK['country'] == 'GERMANY'){$coun_tank = 'ГЕРМАНИЯ';}
if($TANK['country'] == 'SSSR'){$coun_tank = 'СССР';}
if($TANK['country'] == 'USA'){$coun_tank = 'США';}


echo '<div class="trnt-block"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8">


<div class="wrap-content cntr white bold custombg bg_'.$country.'" w:id="bgDiv">

<br>

<table>
<tbody><tr>
<td class="cntr"><img class="tank-img tankimgposfix" alt="tank" src="/images/tanks/'.$tip_tanks.'/'.$TANK['country'].'/'.$TANK['name'].'.png"></td>

<td class="esmall bold green2 pl5 sh_b va_m w60px">
<img width="14" height="14" src="/images/icons/attack.png?1" alt="Атака" title="Атака"> <span class="green2">'.$TANK['a'].'</span><br>
<img width="14" height="14" src="/images/icons/armor.png?1" alt="Броня" title="Броня"> <span class="green2">'.$TANK['b'].'</span><br>
<img width="14" height="14" src="/images/icons/accuracy.png?1" alt="Точность" title="Точность"> <span class="green2">'.$TANK['t'].'</span><br>
<img width="14" height="14" src="/images/icons/durability.png?1" alt="Прочность" title="Прочность"> <span class="green2">'.$TANK['p'].'</span><br>
</td>

</tr>
</tbody></table>

<br>
<center>
<div class="small bold va_m">
<img width="16" height="11" src="/images/flags/'.$country.'16x11.png">  <font size="1">Страна: <font color="green1" style="opacity:0.7;">'.$coun_tank.'</font></font>
<img width="20" height="20" src="/images/tanks/'.$tip_tanks.'.png"><font size="1">Тип: <font color="green1" style="opacity:0.7;">'.$tip.'</font></font>
<img width="25" height="14" src="/images/tanks/'.$tip_tanks.'/'.$TANK['country'].'/'.$TANK['name'].'.png"><font size="1">Танк: <font color="green1" style="opacity:0.7;">'.$TANK['name'].'</font></font>
</div>
</center></div>


<div class="bot">

<a class="simple-but border mb5" href="?send"><span><span>ВЫБРАТЬ ЭТОТ ТАНК</span></span></a>

</div>
</div>
</div></div></div></div></div></div></div></div></div></div>';

//<div class="small bold va_m"><span class="gray1">'.$TANK['name'].'</span></div>

$arr = array(
1 => "Ведьмаг Ада",
2 => "Страник Ха",
3 => "Бегун",
4 => "Оскар Линд",
5 => "Коцап",
6 => "Плакса Царь",
7 => "Бац",
8 => "Клан Ветра",
9 => "Бодя Букин",
10 => "Ловкий Гюрза",
11 => "Жевастик",
12 => "Левоха",
13 => "Летучий огурец",
14 => "Аль Рашид",
15 => "Бешенный Зу",
16 => "Костя Федчук",
17 => "Страник Ха",
18 => "Барсук",
19 => "Трупо Укладчик",
20 => "Людоед",
21 => "Сироп",
22 => "Зубачистка",
23 => "Лунт",
24 => "Критт",
25 => "Анахарсис",
26 => "Дежавю",
27 => "Хик",
28 => "Велзевул",
29 => "Максим Ак",
30 => "Князь Светлов",
31 => "Ларс Викстрём",
32 => "Малышка Мышка",
33 => "Хозяин Демон",
34 => "Оггород",
35 => "Кастиэл",
36 => "Саня Снайпер",
37 => "Бешенный Лотар",
38 => "Нивиный",
39 => "Холифилд",
40 => "Айсберг Хищник",
41 => "Ильяс Аида",
42 => "Ляпа Кузнец",
43 => "Манах Войны",
44 => "Кадж",
45 => "Душа Кошки",
46 => "Кефир",
47 => "Святой Враг",
48 => "Динамит Ловкий",
49 => "Сирёжик",
50 => "Ушаталово",
51 => "Грох Принц",
52 => "Кима кепка",
53 => "Бейбулат",
54 => "Сатрик",
55 => "Никанорчик",
56 => "Золотой Телец",
57 => "Фунтик из кунцего",
58 => "Мриридимримд",
59 => "Смрадный",
60 => "Солдат Химик" ); 
$rand_nick = rand(1,60);





$res = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user`  = "'.$user['id'].'" and `active`  = "1" ');
$users_tanks = $res->fetch_assoc();

if(isset($_GET['send'])){
if(!$users_tanks){
$mysqli->query('INSERT INTO `users_tanks` SET `user` = '.$user['id'].', `tip_tank` = '.$TANK['tip'].', `tip` = '.$TANK['id'].', `active` = "1", `a` = '.$TANK['a'].', `b` = '.$TANK['b'].', `t` = '.$TANK['t'].', `p` = '.$TANK['p'].' ');
}
$uid = mysqli_insert_id($mysqli);

$mysqli->query('INSERT INTO `traning` SET `user` = '.$user['id'].' ');
$mysqli->query('INSERT INTO `buildings_user` SET `user` = '.$user['id'].', `tip` = "1" ');
$mysqli->query('INSERT INTO `buildings_user` SET `user` = '.$user['id'].', `tip` = "2" ');
$mysqli->query('INSERT INTO `buildings_user` SET `user` = '.$user['id'].', `tip` = "3" ');
$mysqli->query('INSERT INTO `buildings_user` SET `user` = '.$user['id'].', `tip` = "4" ');
$mysqli->query('INSERT INTO `buildings_user` SET `user` = '.$user['id'].', `tip` = "5" ');
$mysqli->query('INSERT INTO `buildings_user` SET `user` = '.$user['id'].', `tip` = "6" ');
$mysqli->query('INSERT INTO `buildings_user` SET `user` = '.$user['id'].', `tip` = "7" ');
$mysqli->query('INSERT INTO `crew_user` SET `user` = '.$user['id'].', `tip` = "1", `sposobn` = "0", `rang` = "1" ');
$mysqli->query('INSERT INTO `ammunition_users` SET `user` = '.$user['id'].' ');
$mysqli->query('INSERT INTO `shellskills` SET `user` = '.$user['id'].' ');
$mysqli->query('INSERT INTO `missions_user` SET `user` = '.$user['id'].', `tip` = "1" , `id_miss` = "1" , `prog_max` = "3", `country` = "'.$country_miss.'" ');
//$mysqli->query('INSERT INTO `medals_user` SET `user` = '.$user['id'].', `time` = "'.time().'" , `medals_id` = "1" , `name` = "Медаль разведчика" ');


/* $mysqli->query('INSERT INTO `skills_user` SET `user` = '.$user['id'].', `tip` = "1" ');
$mysqli->query('INSERT INTO `skills_user` SET `user` = '.$user['id'].', `tip` = "2" ');
$mysqli->query('INSERT INTO `skills_user` SET `user` = '.$user['id'].', `tip` = "3" ');
$mysqli->query('INSERT INTO `skills_user` SET `user` = '.$user['id'].', `tip` = "4" ');
$mysqli->query('INSERT INTO `skills_user` SET `user` = '.$user['id'].', `tip` = "5" ');
$mysqli->query('INSERT INTO `skills_user` SET `user` = '.$user['id'].', `tip` = "6" ');
$mysqli->query('INSERT INTO `skills_user` SET `user` = '.$user['id'].', `tip` = "7" ');
 */
$mysqli->query('UPDATE `start` SET `ank_nick` = "'.$arr[$rand_nick].'", `ank_tanks` = "'.$RAND_TANK['id'].'", `step` = "2" WHERE `id` = "'.$start['id'].'" LIMIT 1');
header('Location: '.$HOME.'2/');
exit();
}




/* echo '<div class="trnt-block mb2"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content-mini"><div class="mt5 mb5 small green1 cntr">
<font size=1%>
<font color=white>Средний танк</font> - средний урон, средняя броня, средняя точность и средняя прочность.
<br>
<font color=white>Тяжелый танк</font> - урон выше среднего, прочная броня, плохая точность и хорошая прочность.
<br>
<font color=white>ПТ-САУ</font> - высокий урон, слабая броня, плохая точность и плохая прочность.
<br><br>
<b>Каждая из характеристик будет учитываться в боях.</b>
</font>
</div></div></div></div></div></div></div></div></div></div></div>'; */

echo '<div class="trnt-block mb2"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content-mini"><div class="mt5 mb5 small green1 cntr">
<font size=1%>
<img width="18" height="18" src="/images/tanks/average.png"><font color=white>Средний танк</font> - средний урон, броня, точность из прочность.<br>
<img width="18" height="18" src="/images/tanks/heavy.png"><font color=white>Тяжелый танк</font> - высокий урон и прочность, прочная броня, и плохая точность.<br>
<img width="18" height="18" src="/images/tanks/SAU.png"><font color=white>ПТ-САУ</font> - огромный урон, плохая точность, слабая броня и прочность.<br><br>
<b><u>Каждая из характеристик будет учитываться в боях.</u></b>
</font>
</div></div></div></div></div></div></div></div></div></div></div>';





/* if($start['ref']){
echo '<div class="trnt-block mb2"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content-mini"><div class="mt5 mb5 small green1 cntr">
<span class="yellow1" >Регистрация проходит по приглашению '.nick($start['ref']).'</span>
</div></div></div></div></div></div></div></div></div></div></div>';
}
 */

?>