<?php
require_once ('../system/function.php');
require_once ('../system/header.php');
/*$mult = mysqli_result(mysqli_query("SELECT COUNT(*) FROM `users` WHERE `ip` = '".strong($_SERVER['REMOTE_ADDR'])."' "),0);
if($mult >= 1){
header('Location: '.$HOME.' ');
$_SESSION['err'] = 'Не Пытайся Зарегистрировать еще одного персонажа!';
exit();
}*/

$id = abs(intval($_GET['id']));









if(!$user['id']) {



$result = $mysqli->query("SELECT COUNT(*) FROM `users` WHERE `sex` = '1'");
$sex_m = $result->fetch_array(MYSQLI_NUM);
$result = $mysqli->query("SELECT COUNT(*) FROM `users` WHERE `sex` = '2'");
$sex_v = $result->fetch_array(MYSQLI_NUM);
if($sex_m[0] >= $sex_v[0]){$sex = 2;}else{$sex = 1;}
$result = $mysqli->query("SELECT COUNT(*) FROM `users` WHERE `side` = '1'");
$side_1 = $result->fetch_array(MYSQLI_NUM);
$result = $mysqli->query("SELECT COUNT(*) FROM `users` WHERE `side` = '2'");
$side_2 = $result->fetch_array(MYSQLI_NUM);
if($side_1[0] >= $side_2[0]){$side = 2;}else{$side = 1;}
$pas = rand(1000000000,10000000000);
$pass = md5(md5(md5($pas)));
$log = rand(10000,100000);
$login = 'Незнакомец';
$mysqli->query('INSERT INTO `users` (`side`, `login`, `passw`, `pass`, `datareg`, `sex` ) VALUES ("'.$side.'", "'.$login.'", "'.$pas.'", "'.$pass.'", "'.time().'", "'.$sex.'" ) ');
$uid = mysqli_insert_id($mysqli);
$res = $mysqli->query('SELECT * FROM `tanks` WHERE `country` = "SSSR" ORDER BY RAND() LIMIT 1 ');
$RAND_TANK = $res->fetch_assoc();
if($id){$ref = $id;}
$mysqli->query('INSERT INTO `start` (`time_delete`,`user`,`step`,`country`,`tank_select`,`ref`) VALUES ("'.(time()+86400).'","'.$uid.'","1","SSSR","'.$RAND_TANK['id'].'","'.$id.'")');
$mysqli->query('INSERT INTO `avatars_user` SET `user` = '.$uid.', `sex` = "'.$sex.'" , `act` = "1" , `images` = "'.$sex.'.jpg" ');

setcookie('uslog',$login,time()+86400*365,'/');
setcookie('uspass',$pass,time()+86400*365,'/');
header('Location:'.$HOME.'1/');
exit();





}else{
$res = $mysqli->query('SELECT * FROM `start` WHERE `user` = "'.$user['id'].'" ');
$start = $res->fetch_assoc();
if($start['step']==1 and $_SERVER['PHP_SELF'] != '/start/1.php') {
header('Location: '.$HOME.'1/');
exit();
}elseif($start['step']==2) {
header('Location: '.$HOME.'2/');
exit();
}
}

?>