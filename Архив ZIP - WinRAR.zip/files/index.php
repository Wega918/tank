<?php
//-----Подключаем функции-----//
require_once ('../system/function.php');
header('Location: '.$HOME.'');
exit();
?>