<?php
$title = 'Танки';
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id']){
header('Location: /');
exit();
}
$cost = 500;

echo '<table><tbody><tr>
<td style="width:50%;padding:0 3px;"><a class="simple-but blue" href="/selectUssr/"><span><span>Покупка танков</span></span></a></td>
<td style="width:50%;padding:0 3px;"><a class="simple-but gray" href="/myUssr/"><span><span>Мои танки</span></span></a></td>
</tr></tbody></table>';


echo '<div class="trnt-block mt10 mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr white bold">
<div class="medium green2 sh_b">Покупка танков</div>
</div></div></div></div></div></div></div></div></div></div>

<div class="trnt-block mt0 mb5"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content"><table class="cntr small bold"><tbody><tr>';
echo '<td style="width:33%;"><a class="white" w:id="selectGermany" href="'.$HOME.'myGermany/">ГЕРМАНИЯ<br><img src="/images/flags/germany.png" width="70" height="47" w:id="flagImg" style="opacity:0.4;"></a></td>';
echo '<td style="width:33%;"><a class="white" w:id="selectUssr" href="'.$HOME.'myUssr/">СССР<br><img src="/images/flags/ussr.png" width="70" height="47" w:id="flagImg" style=""></a></td>';
echo '<td style="width:33%;"><a class="white" w:id="selectUsa" href="'.$HOME.'myUsa/">США<br><img src="/images/flags/usa.png" width="70" height="47" w:id="flagImg" style="opacity:0.4;"></a></td>';
echo '</tr></tbody></table></div></div></div></div></div></div></div></div></div></div>';


echo '<div class="trnt-block mb2"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content-mini"><div class="mt5 mb5 small green1 cntr">
<font size=1%>
<img width="18" height="18" src="/images/tanks/average.png"><font color=white>Средний танк</font> - средний урон, броня, точность из прочность.<br>
<img width="18" height="18" src="/images/tanks/heavy.png"><font color=white>Тяжелый танк</font> - высокий урон и прочность, прочная броня, и плохая точность.<br>
<img width="18" height="18" src="/images/tanks/SAU.png"><font color=white>ПТ-САУ</font> - огромный урон, плохая точность, слабая броня и прочность.<br><br>
<b><u>Каждая из характеристик будет учитываться в боях.</u></b>
</font>
</div></div></div></div></div></div></div></div></div></div></div>';


echo '<div class="trnt-block mb10"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="medium green1 sh_b mb5"><font size=2%>При покупке новой техники будут появляться новые задания для данной машины!
Приобретайте больше танков и выполняйте больше заданий каждый день!</font></div>
</div></div></div></div></div></div></div></div></div></div>';


$res_col_tip_tank_1 = $mysqli->query("SELECT COUNT(*) FROM `users_tanks` WHERE `user` = '".$user['id']."' and `tip` >= '14' and `tip` <= '34' ");
$col_tip_tank = $res_col_tip_tank_1->fetch_array(MYSQLI_NUM);

if($col_tip_tank[0]<=0){
echo '<div class="bot"><a class="simple-but border" href="/selectUssr/"><span><span>Купить танк</span></span></a></div>';
}else{


$max = 100;
$res = $mysqli->query("SELECT COUNT(*) FROM `users_tanks` WHERE `user` = ".$user['id']." and `tip` >= '14' and `tip` <= '34' ");
$k_post = $res->fetch_array(MYSQLI_NUM);
$k_page = k_page($k_post[0],$max);
$page = page($k_page);
$start = $max*$page-$max;
$k_post[0] = $start+1;
$res = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user` = "'.$user['id'].'" and `tip` >= "14" and `tip` <= "34" ORDER BY `ID` asc LIMIT '.$start.','.$max.' ');
while ($tanks = $res->fetch_array()){

$res_traning = $mysqli->query('SELECT * FROM `tanks` WHERE `id`  = "'.$tanks['tip'].'" LIMIT 1');
$tank = $res_traning->fetch_assoc();

if($tanks['tip_tank'] == 1){$tip_tank = 'average';$tip_tank_ru = 'СРЕДНИЙ ТАНК';} // СТ
if($tanks['tip_tank'] == 2){$tip_tank = 'heavy';$tip_tank_ru = 'ТЯЖЕЛЫЙ ТАНК';} // ТТ
if($tanks['tip_tank'] == 3){$tip_tank = 'SAU';$tip_tank_ru = 'ПТ-САУ';} // САУ

if($tank['country'] == 'GERMANY'){$coun_tank = 'ГЕРМАНИЯ';$coun_tank_en = 'germany';$angar = 'bg_germany flag_short';}
if($tank['country'] == 'SSSR'){$coun_tank = 'СССР';$coun_tank_en = 'ussr';$angar = 'bg_ussr flag_short';}
if($tank['country'] == 'USA'){$coun_tank = 'США';$coun_tank_en = 'usa';$angar = 'bg_usa flag_short';}


##################################
$res_a = mysqli_query($mysqli,'SELECT sum(sposobn) FROM crew_user WHERE `user`  = "'.$user['id'].'" and `tip` >= "5" and `tip` <= "6" ');
if (FALSE === $res_a) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res_a);
$crew_sum_a = $row[0];

$res_b = mysqli_query($mysqli,'SELECT sum(sposobn) FROM crew_user WHERE `user`  = "'.$user['id'].'" and `tip` >= "7" and `tip` <= "8" ');
if (FALSE === $res_b) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res_b);
$crew_sum_b = $row[0];

$res_t = mysqli_query($mysqli,'SELECT sum(sposobn) FROM crew_user WHERE `user`  = "'.$user['id'].'" and `tip` >= "3" and `tip` <= "4" ');
if (FALSE === $res_t) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res_t);
$crew_sum_t = $row[0];

$res_p = mysqli_query($mysqli,'SELECT sum(sposobn) FROM crew_user WHERE `user`  = "'.$user['id'].'" and `tip` >= "9" and `tip` <= "10" ');
if (FALSE === $res_p) die("Select sum failed: ".mysqli_error);
$row = mysqli_fetch_row($res_p);
$crew_sum_p = $row[0];
##################################


##################################
$res_traning = $mysqli->query('SELECT * FROM `traning` WHERE `user`  = "'.$user['id'].'" LIMIT 1');
$traning = $res_traning->fetch_assoc();
##################################

$res_users_tanks = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user` = '.$user['id'].' and `active`  = "1" LIMIT 1');
$users_tanks = $res_users_tanks->fetch_assoc();

$res_users_tanks_new = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user` = '.$user['id'].' and `tip`  = "'.$tanks['tip'].'" LIMIT 1');
$users_tanks_new = $res_users_tanks_new->fetch_assoc();






$res_users_tanks_modification = $mysqli->query('SELECT * FROM `users_tanks_modification` WHERE `user` = '.$user['id'].' and `id_tank` = '.$tanks['tip'].' LIMIT 1');
$users_tanks_modification = $res_users_tanks_modification->fetch_assoc();

$res_users_tanks_pimp = $mysqli->query('SELECT * FROM `users_tanks_pimp` WHERE `user` = '.$user['id'].' and `tip_tank` = '.$tanks['tip_tank'].' LIMIT 1');
$users_tanks_pimp = $res_users_tanks_pimp->fetch_assoc();

$res_users_tanks_upgrade = $mysqli->query('SELECT * FROM `users_tanks_upgrade` WHERE `user` = '.$user['id'].' and `tip_tank` = '.$tanks['tip_tank'].' LIMIT 1');
$users_tanks_upgrade = $res_users_tanks_upgrade->fetch_assoc();

$res_b_p = $mysqli->query('SELECT * FROM `buildings_polygon` WHERE `user` = '.$user['id'].' LIMIT 1');
$b_p = $res_b_p->fetch_assoc();



$res1 = $mysqli->query('SELECT * FROM `vip` WHERE `user` = "'.$user['id'].'" LIMIT 1');
$vip = $res1->fetch_assoc();
if($vip['time1']>time()){$v_p = 100;}elsE{$v_p = 0;}



$res_company = $mysqli->query('SELECT * FROM `company` WHERE `id` = '.$user['company'].' LIMIT 1');
$company = $res_company->fetch_assoc();

if($user['company']){
$res_company_user = $mysqli->query('SELECT * FROM `company_user` WHERE `user` = '.$user['id'].' and `company` = '.$company['id'].' LIMIT 1');
$company_user = $res_company_user->fetch_assoc();
}

if($user['company']>0){
if($company['shtab_param']>0){$shtab_param = $company['shtab_param'];}else{$shtab_param = 0;}
if($company['polygon_time']>time()){$polygon_param = 40;}else{$polygon_param = 0;}
if($company_user['polygon_time']>time()){$us_polygon_param = 40;}else{$us_polygon_param = 0;}
}else{
$polygon_param = 0;
$us_polygon_param = 0;
}




$res_col_tip_tank_1 = $mysqli->query("SELECT COUNT(*) FROM `users_tanks` WHERE `user` = '".$user['id']."' and `tip_tank` = '1' ");
$col_tip_tank_1 = $res_col_tip_tank_1->fetch_array(MYSQLI_NUM);

$res_col_tip_tank_2 = $mysqli->query("SELECT COUNT(*) FROM `users_tanks` WHERE `user` = '".$user['id']."' and `tip_tank` = '2' ");
$col_tip_tank_2 = $res_col_tip_tank_2->fetch_array(MYSQLI_NUM);

$res_col_tip_tank_3 = $mysqli->query("SELECT COUNT(*) FROM `users_tanks` WHERE `user` = '".$user['id']."' and `tip_tank` = '3' ");
$col_tip_tank_3 = $res_col_tip_tank_3->fetch_array(MYSQLI_NUM);

if(($tanks['tip_tank']==1 and $col_tip_tank_1[0]>0) or ($tanks['tip_tank']==2 and $col_tip_tank_2[0]>0) or ($tanks['tip_tank']==3 and $col_tip_tank_3[0]>0)){//echo '2.1';
$param_a = $tank['a']+$crew_sum_a+$traning['a_level']+$users_tanks_modification['a']+$users_tanks_pimp['a']+$users_tanks_upgrade['a']+($user['level']-1)+$shtab_param+$polygon_param+$us_polygon_param+$b_p['a']+$v_p;
$param_b = $tank['b']+$crew_sum_b+$traning['b_level']+$users_tanks_modification['b']+$users_tanks_pimp['b']+$users_tanks_upgrade['b']+($user['level']-1)+$shtab_param+$polygon_param+$us_polygon_param+$b_p['b']+$v_p;
$param_t = $tank['t']+$crew_sum_t+$traning['t_level']+$users_tanks_modification['t']+$users_tanks_pimp['t']+$users_tanks_upgrade['t']+($user['level']-1)+$shtab_param+$polygon_param+$us_polygon_param+$b_p['t']+$v_p;
$param_p = $tank['p']+$crew_sum_p+$traning['p_level']+$users_tanks_modification['p']+$users_tanks_pimp['p']+$users_tanks_upgrade['p']+($user['level']-1)+$shtab_param+$polygon_param+$us_polygon_param+$b_p['p']+$v_p;
}else{//echo '2.2';
$param_a = $tank['a']+$crew_sum_a+$traning['a_level']+($user['level']-1)+$shtab_param+$polygon_param+$us_polygon_param+$b_p['a']+$v_p;
$param_b = $tank['b']+$crew_sum_b+$traning['b_level']+($user['level']-1)+$shtab_param+$polygon_param+$us_polygon_param+$b_p['b']+$v_p;
$param_t = $tank['t']+$crew_sum_t+$traning['t_level']+($user['level']-1)+$shtab_param+$polygon_param+$us_polygon_param+$b_p['t']+$v_p;
$param_p = $tank['p']+$crew_sum_p+$traning['p_level']+($user['level']-1)+$shtab_param+$polygon_param+$us_polygon_param+$b_p['p']+$v_p;
}


$sum_param = $param_a+$param_b+$param_t+$param_p;



if($users_tanks['tip'] == $tank['id']){
if($users_tanks['a'] != $param_a or $users_tanks['b'] != $param_b or $users_tanks['t'] != $param_t or $users_tanks['p'] != $param_p){
$mysqli->query('UPDATE `users_tanks` SET `a` = '.$param_a.', `b` = '.$param_b.', `t` = '.$param_t.', `p` = '.$param_p.' WHERE `id` = '.$users_tanks['id'].'');
}
}








echo '<div class="trnt-block"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content custombg '.$angar.'">';
echo '<div class="cntr small bold green2 pb5">
<img width="21" height="21" src="/images/attack1.png" title="Атака" alt="Атака" style="width: 21px;height: 21px;"> '.$param_a.'
<img width="21" height="21" src="/images/armor1.png" title="Броня" alt="Броня" style="width: 21px;height: 21px;"> '.$param_b.'
<img width="21" height="21" src="/images/accuracy1.png" title="Точность" alt="Точность" style="width: 21px;height: 21px;"> '.$param_t.'
<img width="21" height="21" src="/images/durability1.png" title="Прочность" alt="Прочность" style="width: 21px;height: 21px;"> '.$param_p.'
</div>';
echo '<div class="cntr small bold green2 pb5"><img src="/images/upgrades/starFull.png" height="14" width="14"> Танковая мощь: '.$sum_param.'</div>';
echo '<br><br><div class="cntr"><img class="tank-img" src="/images/tanks/'.$tip_tank.'/'.$tank['country'].'/'.$tank['name'].'.png" style="width:90%;"></div><br>';
echo '<center>
<div class="small bold va_m">
<img width="16" height="11" src="/images/flags/'.$coun_tank_en.'16x11.png"> <font size="1">Страна: <font color="green1" style="opacity:0.7;">'.$coun_tank.'</font></font>
<img width="20" height="20" src="/images/tanks/'.$tip_tank.'.png"><font size="1">Тип: <font color="green1" style="opacity:0.7;">'.$tip_tank_ru.'</font></font>
<img width="25" height="14" src="/images/tanks/'.$tip_tank.'/'.$tank['country'].'/'.$tank['name'].'.png"><font size="1">Танк: <font color="green1" style="opacity:0.7;">'.$tank['name'].'</font></font>
</div>
</center>';

if($users_tanks['tip']==$tank['id']){
echo '<div class="bot"><a class="simple-but gray border mb5" ><span><span>Выбранный танк</span></span></a></div>';
}else{
echo '<div class="bot"><a class="simple-but grey border mb5" href="?act'.$tank['id'].''.$tank['tip'].''.$tank['country'].'"><span><span>Выбрать</span></span></a></div>';
}
echo '</div>';
echo '</div></div></div></div></div></div></div></div></div>';






if(isset($_GET['act'.$tank['id'].''.$tank['tip'].''.$tank['country'].''])){
if(!$users_tanks_new){header('Location: ?');exit();}
$mysqli->query('UPDATE `users_tanks` SET `active` = "0" WHERE `user` = '.$user['id'].'');
$mysqli->query('UPDATE `users_tanks` SET `a` = '.$param_a.', `b` = '.$param_b.', `t` = '.$param_t.', `p` = '.$param_p.', `active` = "1" WHERE `id` = '.$users_tanks_new['id'].'');
//
$_SESSION['err'] = '<div class="trnt-block mb1"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="green1 sh_b mb2"><img height="14" width="14" src="/images/icons/victory.png"> Танк <b>'.$tank['name'].'</b> успешно выбран! <img height="14" width="14" src="/images/icons/victory.png"></div>
</div></div></div></div></div></div></div></div></div></div>';
header('Location: ?');
exit();
}


}
}

require_once ('../system/footer.php');
?>