<?php
require_once __DIR__.'/includes/config.php';
require_once __DIR__.'/includes/auth.php';
require_once __DIR__.'/includes/functions.php';
require_once __DIR__.'/templates/header.php';

checkAuth();

$table = $_GET['table'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 50;
$orderBy = $_GET['order'] ?? 'id';
$orderDir = $_GET['dir'] ?? 'ASC';

// Валидация параметров
if (!tableExists($pdo, $table)) {
    die("Таблица не существует");
}

// Получение данных с пагинацией и сортировкой
$total = $pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
$pages = ceil($total / $perPage);
$offset = ($page - 1) * $perPage;

// Безопасная сортировка
$allowedColumns = $pdo->query("SHOW COLUMNS FROM `$table`")->fetchAll(PDO::FETCH_COLUMN);
$orderBy = in_array($orderBy, $allowedColumns) ? $orderBy : 'id';
$orderDir = strtoupper($orderDir) === 'DESC' ? 'DESC' : 'ASC';

try {
    $stmt = $pdo->prepare("SELECT * FROM `$table` ORDER BY `$orderBy` $orderDir LIMIT :limit OFFSET :offset");
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Ошибка запроса: " . $e->getMessage());
}
?>

<div class="container-fluid">
    <h2>Таблица: <?= htmlspecialchars($table) ?></h2>
    
    <!-- Кнопки экспорта -->
    <div class="mb-3">
        <a href="export.php?table=<?= urlencode($table) ?>&format=csv" class="btn btn-sm btn-outline-secondary">CSV</a>
        <a href="export.php?table=<?= urlencode($table) ?>&format=json" class="btn btn-sm btn-outline-secondary">JSON</a>
        <a href="export.php?table=<?= urlencode($table) ?>&format=sql" class="btn btn-sm btn-outline-secondary">SQL</a>
    </div>

    <!-- Таблица с данными -->
    <div class="table-responsive">
        <table class="table table-striped table-bordered">
            <thead class="table-dark">
                <tr>
                    <?php foreach ($allowedColumns as $column): ?>
                        <th>
                            <a href="?table=<?= urlencode($table) ?>&order=<?= $column ?>&dir=<?= $orderBy === $column && $orderDir === 'ASC' ? 'DESC' : 'ASC' ?>">
                                <?= htmlspecialchars($column) ?>
                                <?= $orderBy === $column ? ($orderDir === 'ASC' ? '↑' : '↓') : '' ?>
                            </a>
                        </th>
                    <?php endforeach; ?>
                    <th>Действия</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $row): ?>
                    <tr>
                        <?php foreach ($row as $value): ?>
                            <td><?= htmlspecialchars($value ?? 'NULL') ?></td>
                        <?php endforeach; ?>
                        <td class="text-nowrap">
                            <a href="edit.php?table=<?= urlencode($table) ?>&id=<?= $row['id'] ?>" 
                               class="btn btn-sm btn-warning">✏️</a>
                            <form action="delete.php" method="POST" style="display:inline;">
                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                <input type="hidden" name="table" value="<?= htmlspecialchars($table) ?>">
                                <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Удалить запись?')">❌</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Пагинация -->
    <nav aria-label="Page navigation">
        <ul class="pagination">
            <?php for ($i = 1; $i <= $pages; $i++): ?>
                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                    <a class="page-link" href="?table=<?= urlencode($table) ?>&page=<?= $i ?>&order=<?= $orderBy ?>&dir=<?= $orderDir ?>">
                        <?= $i ?>
                    </a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>

<?php require_once __DIR__.'/templates/footer.php'; ?>