<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once 'templates/header.php';

checkAuth();

$allowedFormats = ['csv', 'json'];
$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $table = $_POST['table'] ?? '';
    $format = $_POST['format'] ?? '';
    
    if (!tableExists($pdo, $table)) {
        $error = "Таблица не существует!";
    } elseif (!in_array($format, $allowedFormats)) {
        $error = "Недопустимый формат файла!";
    } else {
        try {
            $file = $_FILES['file']['tmp_name'];
            $data = [];
            
            if ($format === 'csv') {
                $handle = fopen($file, 'r');
                while (($row = fgetcsv($handle)) !== false) {
                    $data[] = $row;
                }
                fclose($handle);
            } elseif ($format === 'json') {
                $json = file_get_contents($file);
                $data = json_decode($json, true);
            }
            
            // Импорт данных
            if (!empty($data)) {
                $columns = implode(', ', array_keys($data[0]));
                $placeholders = implode(', ', array_fill(0, count($data[0]), '?'));
                
                $pdo->beginTransaction();
                $stmt = $pdo->prepare("INSERT INTO `$table` ($columns) VALUES ($placeholders)");
                
                foreach ($data as $row) {
                    $stmt->execute(array_values($row));
                }
                
                $pdo->commit();
                $success = "Импортировано " . count($data) . " записей!";
            }
        } catch (PDOException $e) {
            $pdo->rollBack();
            $error = "Ошибка импорта: " . $e->getMessage();
        }
    }
}
?>

<div class="container mt-4">
    <h2>Импорт данных</h2>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    
    <form method="post" enctype="multipart/form-data" class="mt-4">
        <div class="mb-3">
            <label for="table" class="form-label">Таблица:</label>
            <select name="table" id="table" class="form-select" required>
                <?php foreach (getTablesList($pdo) as $table): ?>
                    <option value="<?= htmlspecialchars($table) ?>"><?= htmlspecialchars($table) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <div class="mb-3">
            <label for="format" class="form-label">Формат:</label>
            <select name="format" id="format" class="form-select" required>
                <option value="csv">CSV</option>
                <option value="json">JSON</option>
            </select>
        </div>
        
        <div class="mb-3">
            <label for="file" class="form-label">Файл:</label>
            <input type="file" name="file" id="file" class="form-control" required>
        </div>
        
        <button type="submit" class="btn btn-primary">Импортировать</button>
    </form>
</div>

<?php require_once 'templates/footer.php'; ?>