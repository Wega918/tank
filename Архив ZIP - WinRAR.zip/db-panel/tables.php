<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once 'templates/header.php';

checkAuth();

// Получаем список таблиц
$tables = getTablesList($pdo);

// Текущая таблица (из GET-параметра)
$currentTable = $_GET['table'] ?? '';
$page = max(1, intval($_GET['page'] ?? 1));
$perPage = 20;

// Если таблица выбрана
if ($currentTable && tableExists($pdo, $currentTable)) {
    $data = getTableData($pdo, $currentTable, $page, $perPage);
    $columns = !empty($data) ? array_keys($data[0]) : [];
    $totalRows = $pdo->query("SELECT COUNT(*) FROM `$currentTable`")->fetchColumn();
    $totalPages = ceil($totalRows / $perPage);
}
?>

<div class="container mt-4">
    <!-- Список таблиц -->
    <div class="row">
        <div class="col-md-3">
            <div class="list-group">
                <?php foreach ($tables as $table): ?>
                    <a href="?table=<?= urlencode($table) ?>" 
                       class="list-group-item list-group-item-action <?= $table === $currentTable ? 'active' : '' ?>">
                        <?= htmlspecialchars($table) ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Содержимое таблицы -->
        <div class="col-md-9">
            <?php if ($currentTable): ?>
                <h2><?= htmlspecialchars($currentTable) ?></h2>
                
                <!-- Пагинация -->
                <nav aria-label="Page navigation">
                    <ul class="pagination">
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                                <a class="page-link" href="?table=<?= urlencode($currentTable) ?>&page=<?= $i ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                        <?php endfor; ?>
                    </ul>
                </nav>

                <!-- Таблица с данными -->
                <div class="table-responsive">
                    <table class="table table-striped table-hover">
                        <thead>
                            <tr>
                                <?php foreach ($columns as $col): ?>
                                    <th><?= htmlspecialchars($col) ?></th>
                                <?php endforeach; ?>
                                <th>Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($data as $row): ?>
                                <tr>
                                    <?php foreach ($row as $value): ?>
                                        <td><?= htmlspecialchars($value) ?></td>
                                    <?php endforeach; ?>
                                    <td>
                                        <a href="edit.php?table=<?= urlencode($currentTable) ?>&id=<?= $row['id'] ?>" 
                                           class="btn btn-sm btn-warning">✏️</a>
                                        <a href="delete.php?table=<?= urlencode($currentTable) ?>&id=<?= $row['id'] ?>" 
                                           class="btn btn-sm btn-danger" 
                                           onclick="return confirm('Удалить запись?')">❌</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="alert alert-info">Выберите таблицу для просмотра</div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'templates/footer.php'; ?>