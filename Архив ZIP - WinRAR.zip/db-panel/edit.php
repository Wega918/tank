<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once 'templates/header.php';

checkAuth();

$table = $_GET['table'] ?? '';
$id = $_GET['id'] ?? 0;

if (!tableExists($pdo, $table)) {
    die("Таблица не существует");
}

// Получаем структуру таблицы
$stmt = $pdo->query("DESCRIBE `$table`");
$columns = $stmt->fetchAll();

// Получаем данные записи
$stmt = $pdo->prepare("SELECT * FROM `$table` WHERE id = ?");
$stmt->execute([$id]);
$row = $stmt->fetch();

if (!$row) {
    die("Запись не найдена");
}

// Обработка формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $updates = [];
    $params = [];
    
    foreach ($columns as $col) {
        $field = $col['Field'];
        if ($field === 'id') continue;
        
        $value = $_POST[$field] ?? null;
        if ($value === '') $value = null;
        
        $updates[] = "`$field` = ?";
        $params[] = $value;
    }
    $params[] = $id;
    
    try {
        $sql = "UPDATE `$table` SET " . implode(', ', $updates) . " WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        
        $_SESSION['success_message'] = "Запись успешно обновлена";
        header("Location: tables.php?table=" . urlencode($table));
        exit();
    } catch (PDOException $e) {
        $error = "Ошибка обновления: " . $e->getMessage();
    }
}
?>

<div class="container-fluid">
    <h2 class="mb-4">Редактирование записи в таблице <?= htmlspecialchars($table) ?></h2>
    
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    
    <form method="POST">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
        
        <?php foreach ($columns as $col): ?>
            <?php if ($col['Field'] === 'id') continue; ?>
            
            <div class="mb-3">
                <label for="<?= $col['Field'] ?>" class="form-label">
                    <?= htmlspecialchars($col['Field']) ?>
                    <?php if ($col['Null'] === 'NO'): ?>
                        <span class="text-danger">*</span>
                    <?php endif; ?>
                </label>
                
                <?php if (strpos($col['Type'], 'text') !== false): ?>
                    <textarea class="form-control" id="<?= $col['Field'] ?>" name="<?= $col['Field'] ?>" 
                        <?= $col['Null'] === 'NO' ? 'required' : '' ?>><?= htmlspecialchars($row[$col['Field']] ?? '') ?></textarea>
                <?php else: ?>
                    <input type="<?= strpos($col['Type'], 'int') !== false ? 'number' : 'text' ?>" 
                           class="form-control" id="<?= $col['Field'] ?>" name="<?= $col['Field'] ?>" 
                           value="<?= htmlspecialchars($row[$col['Field']] ?? '') ?>"
                           <?= $col['Null'] === 'NO' ? 'required' : '' ?>>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        
        <button type="submit" class="btn btn-primary">Сохранить</button>
        <a href="tables.php?table=<?= urlencode($table) ?>" class="btn btn-secondary">Отмена</a>
    </form>
</div>

<?php require_once 'templates/footer.php'; ?>