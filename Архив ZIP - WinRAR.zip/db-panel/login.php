<?php
require_once 'includes/config.php';

// Редирект если уже авторизован
if (isset($_SESSION['authenticated']) && $_SESSION['authenticated'] === true) {
    header("Location: index.php");
    exit();
}

// Обработка формы входа
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === ADMIN_USERNAME && password_verify($password, ADMIN_PASSWORD_HASH)) {
        $_SESSION['authenticated'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['last_activity'] = time();
        
        // Редирект с защитой от открытого редиректа
        $redirect = filter_input(INPUT_GET, 'redirect', FILTER_SANITIZE_URL);
        header("Location: " . ($redirect && str_starts_with($redirect, '/') ? $redirect : 'index.php'));
        exit();
    } else {
        $error = 'Неверные учетные данные';
        error_log("Failed login attempt for username: $username");
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход в панель управления</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .login-container { max-width: 400px; margin-top: 100px; }
        .form-floating label { padding: 1rem .75rem; }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-container mx-auto p-4 bg-white rounded shadow">
            <h2 class="text-center mb-4">Панель управления БД</h2>
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                
                <div class="form-floating mb-3">
                    <input type="text" class="form-control" id="username" name="username" required>
                    <label for="username">Логин</label>
                </div>
                
                <div class="form-floating mb-3">
                    <input type="password" class="form-control" id="password" name="password" required>
                    <label for="password">Пароль</label>
                </div>
                
                <button type="submit" class="w-100 btn btn-lg btn-primary">Войти</button>
            </form>
        </div>
    </div>
</body>
</html>