<?php
require_once 'config.php';

/**
 * Получить список таблиц в БД
 */
function getTablesList(PDO $pdo): array {
    $stmt = $pdo->query("SHOW TABLES");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

/**
 * Получить данные таблицы с пагинацией
 */
function getTableData(PDO $pdo, string $table, int $page = 1, int $perPage = 20): array {
    $offset = ($page - 1) * $perPage;
    $stmt = $pdo->prepare("SELECT * FROM `$table` LIMIT :limit OFFSET :offset");
    $stmt->bindValue(':limit', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Проверка существования таблицы
 */
function tableExists(PDO $pdo, string $table): bool {
    $stmt = $pdo->prepare("SHOW TABLES LIKE ?");
    $stmt->execute([$table]);
    return (bool)$stmt->fetch();
}

/**
 * Создать резервную копию БД
 */
function createBackup(PDO $pdo, string $backupDir): string {
    $tables = getTablesList($pdo);
    $backupContent = "";
    
    foreach ($tables as $table) {
        $backupContent .= "-- Table: $table\n";
        
        // Структура таблицы
        $stmt = $pdo->query("SHOW CREATE TABLE `$table`");
        $createTable = $stmt->fetch(PDO::FETCH_ASSOC)['Create Table'];
        $backupContent .= $createTable . ";\n\n";
        
        // Данные таблицы
        $data = $pdo->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($data as $row) {
            $values = array_map(fn($v) => $pdo->quote($v), $row);
            $backupContent .= "INSERT INTO `$table` VALUES (" . implode(', ', $values) . ");\n";
        }
        $backupContent .= "\n";
    }
    
    $backupFile = $backupDir . '/backup_' . date('Y-m-d_H-i-s') . '.sql';
    file_put_contents($backupFile, $backupContent);
    return $backupFile;
}