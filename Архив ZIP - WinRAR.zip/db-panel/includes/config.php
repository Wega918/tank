<?php
session_start();

define('DB_HOST', 'localhost');
define('DB_USER', 'angreg_marsgame');
define('DB_PASS', 'jeJeQLj8QkkF1');
define('DB_NAME', 'angreg_marsgame');

// Настройки безопасности
define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD_HASH', password_hash('secure_password', PASSWORD_BCRYPT));
define('CSRF_TOKEN_LIFETIME', 3600); // 1 час

// Автоподключение к БД с обработкой ошибок
try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    error_log("Database connection failed: " . $e->getMessage());
    die("Ошибка подключения к базе данных. Пожалуйста, попробуйте позже.");
}

// Генерация CSRF-токена при отсутствии
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    $_SESSION['csrf_token_time'] = time();
}
?>