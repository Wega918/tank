<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'templates/header.php';

checkAuth();

$query = $_POST['query'] ?? '';
$results = [];
$error = '';
$executionTime = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($query)) {
    try {
        $startTime = microtime(true);
        $stmt = $pdo->prepare($query);
        $stmt->execute();
        
        // Для SELECT показываем результаты, для других запросов - количество затронутых строк
        if (stripos(trim($query), 'SELECT') === 0) {
            $results = $stmt->fetchAll();
        } else {
            $results = ['affected_rows' => $stmt->rowCount()];
        }
        
        $executionTime = round((microtime(true) - $startTime) * 1000, 2);
    } catch (PDOException $e) {
        $error = $e->getMessage();
        error_log("SQL Error: " . $error . " | Query: " . $query);
    }
}
?>

<div class="container-fluid">
    <h2 class="mb-4">SQL-редактор</h2>
    
    <form method="POST" class="mb-4">
        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
        
        <div class="mb-3">
            <label for="query" class="form-label">SQL-запрос:</label>
            <textarea class="form-control font-monospace" id="query" name="query" rows="5" required><?= htmlspecialchars($query) ?></textarea>
        </div>
        
        <button type="submit" class="btn btn-primary">Выполнить</button>
        <button type="button" class="btn btn-outline-secondary ms-2" onclick="document.getElementById('query').value=''">Очистить</button>
    </form>
    
    <?php if ($error): ?>
        <div class="alert alert-danger">Ошибка: <?= htmlspecialchars($error) ?></div>
    <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
        <div class="alert alert-success">
            Запрос выполнен за <?= $executionTime ?> мс
            <?php if (isset($results['affected_rows'])): ?>
                | Затронуто строк: <?= $results['affected_rows'] ?>
            <?php endif; ?>
        </div>
        
        <?php if (!isset($results['affected_rows'])): ?>
            <div class="table-responsive">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <?php if (!empty($results)): ?>
                                <?php foreach (array_keys($results[0]) as $column): ?>
                                    <th><?= htmlspecialchars($column) ?></th>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($results as $row): ?>
                            <tr>
                                <?php foreach ($row as $value): ?>
                                    <td><?= is_null($value) ? 'NULL' : htmlspecialchars($value) ?></td>
                                <?php endforeach; ?>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.css">
<script>
    // Инициализация подсветки синтаксиса SQL
    const editor = CodeMirror.fromTextArea(document.getElementById('query'), {
        mode: 'text/x-sql',
        indentWithTabs: true,
        smartIndent: true,
        lineNumbers: true,
        autofocus: true
    });
</script>

<?php require_once 'templates/footer.php'; ?>