<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once 'templates/header.php';

checkAuth();

// Получаем статистику
$tables = getTablesList($pdo);
$stats = [];
$totalSize = 0;

foreach ($tables as $table) {
    $rowCount = $pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
    $tableSize = $pdo->query("SELECT ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = '$table'")->fetchColumn();
    
    $stats[$table] = [
        'rows' => $rowCount,
        'size_mb' => $tableSize
    ];
    $totalSize += $tableSize;
}
?>

<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Дашборд</h1>
</div>

<div class="row">
    <!-- Карточка с общей статистикой -->
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Общая статистика</h5>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Таблиц в БД
                        <span class="badge bg-primary rounded-pill"><?= count($tables) ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Общий размер
                        <span class="badge bg-success rounded-pill"><?= number_format($totalSize, 2) ?> MB</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <!-- Таблица со статистикой -->
    <div class="col-md-6 mb-4">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Статистика по таблицам</h5>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Таблица</th>
                                <th class="text-end">Записей</th>
                                <th class="text-end">Размер (MB)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($stats as $table => $data): ?>
                                <tr>
                                    <td><a href="tables.php?table=<?= urlencode($table) ?>"><?= htmlspecialchars($table) ?></a></td>
                                    <td class="text-end"><?= number_format($data['rows']) ?></td>
                                    <td class="text-end"><?= number_format($data['size_mb'], 2) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'templates/footer.php'; ?>