<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';
require_once 'includes/functions.php';

checkAuth();

$table = $_GET['table'] ?? '';
$format = $_GET['format'] ?? 'json';

if (!tableExists($pdo, $table)) {
    die("Таблица не существует");
}

header("Content-Type: application/octet-stream");
header("Content-Disposition: attachment; filename=\"{$table}_export.{$format}\"");

try {
    $stmt = $pdo->query("SELECT * FROM `$table`");
    $data = $stmt->fetchAll();
    
    switch ($format) {
        case 'csv':
            $output = fopen('php://output', 'w');
            if (!empty($data)) {
                fputcsv($output, array_keys($data[0]));
                foreach ($data as $row) {
                    fputcsv($output, $row);
                }
            }
            fclose($output);
            break;
            
        case 'json':
            echo json_encode($data, JSON_PRETTY_PRINT);
            break;
            
        case 'sql':
            $columns = array_keys($data[0]);
            foreach ($data as $row) {
                $values = array_map([$pdo, 'quote'], $row);
                echo "INSERT INTO `$table` (`" . implode('`, `', $columns) . "`) VALUES (" . implode(', ', $values) . ");\n";
            }
            break;
            
        default:
            die("Неподдерживаемый формат экспорта");
    }
} catch (PDOException $e) {
    die("Ошибка экспорта: " . $e->getMessage());
}
?>