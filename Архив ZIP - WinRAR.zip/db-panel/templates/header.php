<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Панель управления БД</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .sidebar { min-height: 100vh; }
        .nav-link { color: rgba(255, 255, 255, 0.75); }
        .nav-link:hover, .nav-link.active { color: white; background-color: rgba(255, 255, 255, 0.1); }
        .main-content { padding-top: 1rem; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Боковое меню -->
            <div class="col-md-3 col-lg-2 d-md-block bg-dark sidebar collapse">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'active' : '' ?>" href="index.php">
                                <i class="bi bi-speedometer2 me-2"></i>Дашборд
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'tables.php' ? 'active' : '' ?>" href="tables.php">
                                <i class="bi bi-table me-2"></i>Таблицы
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'query.php' ? 'active' : '' ?>" href="query.php">
                                <i class="bi bi-code-square me-2"></i>SQL-запросы
                            </a>
                        </li>
                    </ul>
                    
                    <div class="mt-4 border-top pt-3">
                        <div class="text-white small">Вы вошли как: <strong><?= htmlspecialchars($_SESSION['username'] ?? 'Гость') ?></strong></div>
                        <a href="logout.php" class="btn btn-sm btn-outline-light mt-2 w-100">Выйти</a>
                    </div>
                </div>
            </div>
            
            <!-- Основное содержимое -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 main-content">