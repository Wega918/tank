<?php

header('Location: /pay/');
exit();


?>