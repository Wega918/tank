<?php
require ('../system/function.php');
require ('../system/header.php');

/* if(!$user['id']){
header('Location: '.$HOME.'pay/');
$_SESSION['err'] = 'Только для зарегестрированых';
exit();
}else{

} */


echo 'err';
/* header('Location: '.$HOME.'pay/');
$_SESSION['err'] = 'При оплате произошла ошибка! Попробуйте пожалуйста еще раз!';
exit(); */
require ('../system/footer.php');
?>