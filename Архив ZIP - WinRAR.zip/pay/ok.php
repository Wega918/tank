<?php
require ('../system/function.php');
require ('../system/header.php');

/* if(!$user['id']){
header('Location: '.$HOME.'pay/');
$_SESSION['err'] = 'Только для зарегестрированых';
exit();
}else{

} */

echo 'ok';


//header('Location: '.$HOME.'pay/');
//$_SESSION['ses'] = 'Платеж выполнен! Начисление прошло успешно!';
//exit();
require ('../system/footer.php');
?>