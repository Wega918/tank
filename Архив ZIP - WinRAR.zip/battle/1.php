<?php
$title = 'Бой';
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id']) {
header('Location: '.$HOME.'');
exit();
}
$res = $mysqli->query('SELECT * FROM `battle` WHERE `user` = '.$user['id'].' ');
$battle = $res->fetch_assoc();
$res = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user`  = "'.$user['id'].'" and `active`  = "1"');
$users_tanks = $res->fetch_assoc();
$res = $mysqli->query('SELECT * FROM `traning` WHERE `user`  = "'.$user['id'].'" ');
$traning = $res->fetch_assoc();
if(!$battle) {
header('Location: '.$HOME.'battle/');
exit();
}
if($battle['battle'] == 0) {
header('Location: '.$HOME.'battle/');
exit();
}
if($battle['battle'] != 1) {
header('Location: '.$HOME.'battle/'.$battle['battle'].'/');
exit();
}


$res = $mysqli->query('SELECT * FROM `tanks` WHERE `id` = "'.$users_tanks['tip'].'" ');
$tank1 = $res->fetch_assoc();

if($battle['tank']==1){
$href = 'battle'.$battle['ank_tank1'].'';
$name = ''.$battle['ank_name1'].'';
$res = $mysqli->query('SELECT * FROM `tanks` WHERE `id`  = "'.$battle['ank_tank1'].'" ');
$tank2 = $res->fetch_assoc();
}else{
$href = 'battle'.$battle['ank_tank2'].'';
$name = ''.$battle['ank_name2'].'';
$res = $mysqli->query('SELECT * FROM `tanks` WHERE `id`  = "'.$battle['ank_tank2'].'" ');
$tank2 = $res->fetch_assoc();
}


if($tank1['tip'] == 1){$tip1 = 'average';} // СТ
if($tank1['tip'] == 2){$tip1 = 'heavy';} // ТТ
if($tank1['tip'] == 3){$tip1 = 'SAU';} // САУ
if($tank2['tip'] == 1){$tip2 = 'average';} // СТ
if($tank2['tip'] == 2){$tip2 = 'heavy';} // ТТ
if($tank2['tip'] == 3){$tip2 = 'SAU';} // САУ
#############################################################################
#############################################################################
if($tank1['country']=='GERMANY'){$country = 1;}
if($tank1['country']=='SSSR'){$country = 2;}
if($tank1['country']=='USA'){$country = 3;}










//if($user['id']==1){
?>
<?php
// Пример динамической установки стилей для второй картинки
$image2Width1 = '50%'; // Ширина второй картинки
?>

    <style>
	#myCanvas {
    max-width: 212%;
    margin-bottom: -146%;
        }
        /* Общий контейнер для изображений */
        .image-container {
            position: relative; /* Позиционирование относительно этого контейнера */
        }

        /* Стили для первой картинки */
        .image1 {
            width: 100%; /* Ширина 100% от родительского контейнера */
            height: auto; /* Высота автоматически, чтобы сохранить пропорции */
            display: block; /* Блочный элемент (если это изображение внутри анкора) */
        }

        /* Стили для второй картинки с динамически установленными свойствами */
        .image2 {
            position: absolute; /* Позиционирование абсолютное */
            top: <?php echo $image2Top; ?>; /* Динамический отступ сверху */
            left: <?php echo $image2Left; ?>; /* Динамический отступ слева */
            width: <?php echo $image2Width; ?>; /* Динамическая ширина */
            height: auto; /* Высота автоматически, чтобы сохранить пропорции */
        }
		
		.image3 {
            width: 100%; /* Ширина 100% от родительского контейнера */
            height: auto; /* Высота автоматически, чтобы сохранить пропорции */
            display: block; /* Блочный элемент (если это изображение внутри анкора) */
        }

        /* Стили для второй картинки с динамически установленными свойствами */
        .image4 {
            position: absolute; /* Позиционирование абсолютное */
            top: <?php echo $_SESSION['image2Top1']; ?>; /* Динамический отступ сверху */
            left: <?php echo $_SESSION['image2Left1']; ?>; /* Динамический отступ слева */
            width: <?php echo $image2Width1; ?>; /* Динамическая ширина */
            height: auto; /* Высота автоматически, чтобы сохранить пропорции */
        }
    </style>


<?




echo '<a href="?'.$href.'"><table><tbody><tr><td class="w50 pr1">
<div class="trnt-block mb10"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="p5 cntr custombg boi_2" w:id="heroDiv">

<div class="small bold cD2 cntr sh_b pb5 pt5"><font size=1%>'.$user['login'].'</font><br><img width="10%" src="/images/tanks/'.$tip1.'.png"><span class="gray1"><font size=1>'.$tank1['name'].'</font></span></div>
    <div class="image-container">
        <img src="/images/tanks/'.$tip1.'/'.$tank1['country'].'/'.$tank1['name'].'_.png" alt="tank" class="image1">
    </div>
<canvas id="myCanvas" width="1000" height="310"></canvas>


</div></div></div></div></div></div></div></div></div></div></td><td class="w50 pl1">
<div class="trnt-block mb10"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="p5 cntr custombg boi_2" w:id="targetDiv">
<div class="small red1 cD2 cntr sh_b pb5 pt5"><font size=1%>'.$name.'</font><br><img width="10%" src="/images/tanks/'.$tip2.'.png"><span class="gray1"><font size=1>'.$tank2['name'].'</font></span></div>
<div class="image-container">
        <img src="/images/tanks/'.$tip2.'/'.$tank2['country'].'/'.$tank2['name'].'.png" alt="tank" class="image3">';
		if($_SESSION['image2Top1']!=''){
		echo '<img src="/images/tanks/2,2.png" alt="tank" class="image4" id="image4">';
		}
echo '</div>

</div></div></div></div></div></div></div></div></div></div>
</td></tr></tbody></table></a>';

if($user['fuel'] >= 30){
echo '<div class="bot"><a class="simple-but border" href="?'.$href.'"><span><span>ДОБИТЬ</span></span></a></div>';
}else{
echo '<div class="bot"><a class="simple-but border gray" href="?'.$href.'"><span><span>ДОБИТЬ</span></span></a></div>';
}
//}


























/* 
echo '<center><div class="wrap-content custombg angar_1" style="width:100%; border-radius: 10px;"> 
<br><a href="?'.$href.'"><table><tbody><tr>';
echo '<td style="width:2%;padding-left:3px;"><div style="position:relative;"></div></td>';
echo '<td style="width:50%;padding-left:4px;"><div style="position:relative;">
<div class="small bold cD2 cntr sh_b pb5 pt5"><font size=1%>'.$user['login'].'</font><br><img width="10%" src="/images/tanks/'.$tip1.'.png"><span class="gray1"><font size=1>'.$tank1['name'].'</font></span></div><img class="tank-img" alt="tank" src="/images/tanks/'.$tip1.'/'.$tank1['country'].'/'.$tank1['name'].'_.png" style="width:100%;">
</div></td>';
if($battle['hit']>0){
echo '<td style="width:50%;padding-right:4px;"><div style="position:relative;">
<div class="small bold cD2 cntr sh_b pb5 pt5"><font size=1%>'.$name.'</font><br><img width="10%" src="/images/tanks/'.$tip2.'.png"><span class="gray1"><font size=1>'.$tank2['name'].'</font></span></div><img class="tank-img" alt="tank" src="/images/tanks/'.$tip2.'/'.$tank2['country'].'/'.$tank2['name'].'/'.$tank2['name'].'_'.$battle['hit'].'.png" style="width:100%;">
</td>';
}else{
echo '<td style="width:50%;padding-right:4px;"><div style="position:relative;">
<div class="small bold cD2 cntr sh_b pb5 pt5"><font size=1%>'.$name.'</font><br><img width="10%" src="/images/tanks/'.$tip2.'.png"><span class="gray1"><font size=1>'.$tank2['name'].'</font></span></div><img class="tank-img" alt="tank" src="/images/tanks/'.$tip2.'/'.$tank2['country'].'/'.$tank2['name'].'.png" style="width:100%;">
</td>';
}
echo '<td style="width:2%;padding-right:3px;"><div style="position:relative;"></div></td>';
echo '</tr></tbody></table></a><div class="cntr small bold mb2 pb0"></div>';


if($user['fuel'] >= 30){
echo '<div class="bot"><a class="simple-but border" href="?'.$href.'"><span><span>ДОБИТЬ</span></span></a></div>';
}else{
echo '<div class="bot"><a class="simple-but border gray" href="?'.$href.'"><span><span>ДОБИТЬ</span></span></a></div>';
}
echo '</div></center>';
echo '</div></div></div></div></div></div></div></div></div></div>';
 */













$cost_fuel = 50;
#############################################################################
#############################################################################
if(isset($_GET[''.$href.''])){
if($user['fuel'] < 30){
$_SESSION['err'] = '<div class="cntr mb5"><div class="white small">У вас не хватает <img src="/images/icons/fuel.png">'.(30-$user['fuel']).' топлива.</div></div><div class="trnt-block">
<div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8">
<div class="wrap-content cntr"><div class="green1 small">Получить <img src="/images/icons/fuel.png">'.($user['fuel_max']-$user['fuel']).' топлива</div>
<div class="bot">
<a class="simple-but gray border" href="?fuel"><span><span>Купить за <img class="ico vm" src="/images/icons/gold.png?1" alt="Золото" title="Золото"> <font size=1%>'.$cost_fuel.'</font></span></span></a>
</div></div></div></div></div></div></div></div></div></div></div>';
header('Location: ?');
exit();
}

if($battle['tank']==1){
$rand = rand(1,6);
if($rand == 1){$resuilt = 'Пробитие!';}
if($rand == 2){$resuilt = 'Враг горит!';}
if($rand == 3){$resuilt = 'Есть попадание!';}
if($rand == 4){$resuilt = 'Попадание!';}
if($rand == 5){$resuilt = 'Противник подбит!';}
if($rand == 6){
$rand_ = rand(1,6);
if($rand_ == 1){$resuilt = '<font color=red>Промах!</font>';}
if($rand_ == 2){$resuilt = '<font color=red>Рикошет!</font>';}
if($rand_ == 3){$resuilt = '<font color=red>Враг сманеврировал!</font>';}
if($rand_ == 4){$resuilt = '<font color=red>Не пробил!</font>';}
if($rand_ == 5){$resuilt = '<font color=red>Не попал в броню!</font>';}
if($rand_ == 6){$resuilt = '<font color=red>Броня не пробита!</font>';}
}

if($rand <= 5){
$hit = 1;
$exp = (2+$traning['rang']);
$silver = ((rand(2,3))+$traning['rang']);
$_SESSION['image2Top1'] = ''.rand(0,35).'%';
$_SESSION['image2Left1'] = ''.rand(0,55).'%';
}else{
$hit = 0;
$exp = $traning['rang'];
$silver = ((rand(0,1))+$traning['rang']);
$_SESSION['image2Top1'] = '';
$_SESSION['image2Left1'] = '';
}



}else{
$rand = rand(1,4);
if($rand == 1){$resuilt = 'Пробитие!';}
if($rand == 2){$resuilt = 'Враг горит!';}
if($rand == 3){$resuilt = 'Есть попадание!';}
if($rand == 4){
$rand_ = rand(1,6);
if($rand_ == 1){$resuilt = '<font color=red>Промах!</font>';}
if($rand_ == 2){$resuilt = '<font color=red>Рикошет!</font>';}
if($rand_ == 3){$resuilt = '<font color=red>Враг сманеврировал!</font>';}
if($rand_ == 4){$resuilt = '<font color=red>Не пробил!</font>';}
if($rand_ == 5){$resuilt = '<font color=red>Не попал в броню!</font>';}
if($rand_ == 6){$resuilt = '<font color=red>Броня не пробита!</font>';}
}

if($rand <= 3){
$hit = 1;
$exp = (4+$traning['rang']);
$silver = ((rand(5,6))+$traning['rang']);
$_SESSION['image2Top1'] = ''.rand(0,35).'%';
$_SESSION['image2Left1'] = ''.rand(0,55).'%';
}else{
$hit = 0;
$exp = (2+$traning['rang']);
$silver = ((rand(2,3))+$traning['rang']);
$_SESSION['image2Top1'] = '';
$_SESSION['image2Left1'] = '';
}
}
$res1 = $mysqli->query('SELECT * FROM `vip` WHERE `user` = "'.$user['id'].'" LIMIT 1');
$vip = $res1->fetch_assoc();
$res_s7 = $mysqli->query('SELECT * FROM `skills_user` WHERE `tip`  = "7" and `user`  = "'.$user['id'].'" ');
$skills_7 = $res_s7->fetch_assoc(); // Инструктор Повышает личный заработанный опыт.
$res = $mysqli->query('SELECT * FROM `prom` WHERE `id` = "1" ');
$prom = $res->fetch_assoc();

if($prom['time_2']>time()){$exp_p2 = $prom['act_2'];}else{$exp_p2 = 0;}
if($prom['time_17']>time()){$exp_p17 = $prom['act_17'];}else{$exp_p17 = 0;}
if($prom['time_18']>time()){$sil_p18 = $prom['act_18'];}else{$sil_p18 = 0;}

if($vip['time2']>time()){$v2s = 25;$v2e = 50;}elsE{$v2s = 0;$v2e = 0;}
if($vip['time4']>time()){$v4e = 50;}elsE{$v4e = 0;}
$silver = ceil($silver+ ($silver*($v2s+$sil_p18)/100));
$exp = ceil($exp+ ($exp*($v2e+$v4e+$skills_7['bon']+$exp_p2+$exp_p17)/100));

####################################################################################
$id_miss = 3;$prog_max = 6;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().' and `country` = "'.$country.'" limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){
if($hit == 1){
$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "1" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
}else{
$mysqli->query('UPDATE `missions_user` SET `prog` =  "0" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
}
//$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "1" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
####################################################################################

####################################################################################
$id_miss = 14;$prog_max = 500;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().' and `country` = "'.$country.'" limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "'.$exp.'" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
####################################################################################

####################################################################################
if($hit==1 and $traning['rang']>=3 and $user['level']>=7){
$id_miss = 24;$prog_max = 5000;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().' and `country` = "'.$country.'" limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "'.$exp.'" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
}
####################################################################################

####################################################################################
if($traning['rang']>=3 and $user['level']>=7){
$id_miss = 21;$prog_max = 150;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().' and `country` = "'.$country.'" limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "1" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
}
####################################################################################


$res = $mysqli->query('SELECT * FROM `prom` WHERE `id` = "1" ');
$prom = $res->fetch_assoc();

if($prom['time_2']>time()){
$exp = $exp+($exp*$prom['act_2']/100);
}else{
$exp = $exp;
}


if($prom['time_20']>time()){
$res = $mysqli->query('SELECT * FROM `bz_user` WHERE `user` = "'.$user['id'].'" and `tip` = "'.$prom['tip_20'].'"');
$bz_user = $res->fetch_assoc();
if($bz_user['step']==6 and $bz_user['prog_']<$bz_user['prog']){
$mysqli->query('UPDATE `bz_user` SET `prog_` = `prog_` + "'.$exp.'" WHERE `id` = '.$bz_user['id'].'');
}
}


$mysqli->query('UPDATE `battle` SET `battle` = "2", `hit` = '.($battle['hit']+$hit).' WHERE `id` = '.$battle['id'].'');
$mysqli->query('UPDATE `users` SET `silver` = '.($user['silver']+$silver).', `exp` = '.($user['exp']+$exp).', `fuel` = '.($user['fuel']-30).' WHERE `id` = '.$user['id'].'');

if($user['company']){
$res_company = $mysqli->query('SELECT * FROM `company` WHERE `id` = '.$user['company'].' limit 1');
$company = $res_company->fetch_assoc();
$res_company_user = $mysqli->query('SELECT * FROM `company_user` WHERE `user` = '.$user['id'].' and `company` = '.$company['id'].' LIMIT 1');
$company_user = $res_company_user->fetch_assoc();
$res_crew_user = $mysqli->query('SELECT * FROM `crew_user` WHERE `user` = '.$user['id'].' and `tip` = "1" limit 1');
$crew_user = $res_crew_user->fetch_assoc();
$res_s6 = $mysqli->query('SELECT * FROM `skills_user` WHERE `tip`  = "6" and `user`  = "'.$user['id'].'" ');
$skills_6 = $res_s6->fetch_assoc(); // Курсы офицеров Повышает заработанный опыт дивизии.
$exp_company = $exp+  ($exp*($crew_user['sposobn']+$skills_6['bon'])/100);
$mysqli->query('UPDATE `company_user` SET `company_exp` = '.($company_user['company_exp']+$exp_company).', `company_exp_stats` = '.($company_user['company_exp_stats']+$exp_company).' WHERE `id` = '.$company_user['id'].'');
$mysqli->query('UPDATE `company` SET `exp` = '.($company['exp']+$exp_company).' WHERE `id` = '.$company['id'].'');
}


header('Location: '.$HOME.'battle/2/');
$_SESSION['err'] = '
<div class="medium bold pb5 cntr green1"><img height="14" width="14" src="/images/icons/victory.png"> <span>'.$resuilt.'</span> <img height="14" width="14" src="/images/icons/victory.png"></div>
<div class="small white cntr sh_b bold">
<span class="nwr"><img class="ico vm" src="/images/icons/exp.png" alt="опыт" title="опыт"> '.$exp.' опыта</span>
<span class="nwr"><img class="ico vm" src="/images/icons/silver.png" alt="Серебро" title="Серебро"> '.$silver.' серебра</span>
</div>';
exit();
}
#############################################################################
#############################################################################





#############################################################################
#############################################################################
if(isset($_GET['fuel'])){
if($user['fuel'] >=30){header('Location: ?');exit();}
if($user['gold'] < $cost_fuel){
$_SESSION['err'] = '<div class="trnt-block"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="red1">У вас не хватает <img class="ico vm" src="/images/icons/gold.png?1" alt="Золото" title="Золото"> '.($cost_fuel-$user['gold']).' золота</div>
<div class="bot"><a class="simple-but w50 mXa medium m5" href="'.$HOME.'payments/"><span><span>Купить золото</span></span></a></div>
</div></span></div></div></div>
</div></div></div></div></div></div></div></div></div></div>';
header('Location: ?');
exit();
}
$mysqli->query('UPDATE `users` SET `gold` = '.($user['gold']-$cost_fuel).', `fuel` = '.($user['fuel']=$user['fuel_max']).' WHERE `id` = '.$user['id'].'');
$_SESSION['err'] = '<div class="trnt-block mb1"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="green1 sh_b mb2"><img height="14" width="14" src="/images/icons/victory.png"> Бак заправлен! <img height="14" width="14" src="/images/icons/victory.png"></div>
</div></div></div></div></div></div></div></div></div></div>';
header('Location: ?');
exit();
}
#############################################################################
#############################################################################








require_once ('../system/footer.php');
?>