<?php
$title = 'Бой';
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id']) {
header('Location: '.$HOME.'');
exit();
}
$res = $mysqli->query('SELECT * FROM `battle` WHERE `user` = '.$user['id'].' ');
$battle = $res->fetch_assoc();
$res = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user`  = "'.$user['id'].'" and `active`  = "1"');
$users_tanks = $res->fetch_assoc();
if(!$battle) {
header('Location: '.$HOME.'battle/');
exit();
}
if($battle['battle'] == 0) {
header('Location: '.$HOME.'battle/');
exit();
}
if($battle['battle'] != 3) {
header('Location: '.$HOME.'battle/'.$battle['battle'].'/');
exit();
}


$res = $mysqli->query('SELECT * FROM `tanks` WHERE `id` = "'.$users_tanks['tip'].'" ');
$tank1 = $res->fetch_assoc();

if($battle['tank']==1){
$href = 'battle'.$battle['ank_tank1'].'';
$name = ''.$battle['ank_name1'].'';
$res = $mysqli->query('SELECT * FROM `tanks` WHERE `id`  = "'.$battle['ank_tank1'].'" ');
$tank2 = $res->fetch_assoc();
}else{
$href = 'battle'.$battle['ank_tank2'].'';
$name = ''.$battle['ank_name2'].'';
$res = $mysqli->query('SELECT * FROM `tanks` WHERE `id`  = "'.$battle['ank_tank2'].'" ');
$tank2 = $res->fetch_assoc();
}


if($tank1['tip'] == 1){$tip1 = 'average';} // СТ
if($tank1['tip'] == 2){$tip1 = 'heavy';} // ТТ
if($tank1['tip'] == 3){$tip1 = 'SAU';} // САУ
if($tank2['tip'] == 1){$tip2 = 'average';} // СТ
if($tank2['tip'] == 2){$tip2 = 'heavy';} // ТТ
if($tank2['tip'] == 3){$tip2 = 'SAU';} // САУ
#############################################################################
#############################################################################




/* 
.image4 {
    position: absolute;
    top: -139%;
    left: -5%;
    width: 213px;
    height: 250px;
} */


//if($user['id']==1){
?>
<?php
// Пример динамической установки стилей для второй картинки
$image2Width1 = '100%'; // Ширина второй картинки
?>

    <style>
	.gif-container {
    position: relative;
    width: 100px; /* Задайте ширину и высоту контейнера в соответствии с размерами вашего GIF */
    height: 100px;
    top: 100px; /* Динамический отступ сверху */
    left: 100px; /* Динамический отступ слева */

}

#animated-gif {
    width: 100%;
    height: 100%;
    opacity: 0; /* Устанавливаем начальное значение прозрачности на 0 */
    animation: fadeInOut 5s linear infinite; /* Анимация затухания и появления */
}

@keyframes fadeInOut {
    0%, 100% {
        opacity: 0.03; /* Устанавливаем минимальную прозрачность на уровне 10% */
    }
    50% {
        opacity: 1; /* Здесь прозрачность будет наибольшей (90%) */
    }
}


	#myCanvas {
    max-width: 212%;
    margin-bottom: -146%;
        }
        /* Общий контейнер для изображений */
        .image-container {
            position: relative; /* Позиционирование относительно этого контейнера */
        }

        /* Стили для первой картинки */
        .image1 {
            width: 100%; /* Ширина 100% от родительского контейнера */
            height: auto; /* Высота автоматически, чтобы сохранить пропорции */
            display: block; /* Блочный элемент (если это изображение внутри анкора) */
        }

        /* Стили для второй картинки с динамически установленными свойствами */
.image2 {
    position: absolute;
    top: -108%;
    left: -3%;
    width: 105%;
    height: 275%;
}

		.image3 {
            width: 100%; /* Ширина 100% от родительского контейнера */
            height: auto; /* Высота автоматически, чтобы сохранить пропорции */
            display: block; /* Блочный элемент (если это изображение внутри анкора) */
        }

        /* Стили для второй картинки с динамически установленными свойствами */
        .image4 {
            position: absolute; /* Позиционирование абсолютное */
            top: <?php echo $_SESSION['image2Top1']; ?>; /* Динамический отступ сверху */
            left: <?php echo $_SESSION['image2Left1']; ?>; /* Динамический отступ слева */
            width: <?php echo $image2Width1; ?>; /* Динамическая ширина */
            height: auto; /* Высота автоматически, чтобы сохранить пропорции */
        }
    </style>


<?




echo '<a href="?'.$href.'"><table><tbody><tr><td class="w50 pr1">
<div class="trnt-block mb10"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="p5 cntr custombg boi_2" w:id="heroDiv">

<div class="small bold cD2 cntr sh_b pb5 pt5"><font size=1%>'.$user['login'].'</font><br><img width="10%" src="/images/tanks/'.$tip1.'.png"><span class="gray1"><font size=1>'.$tank1['name'].'</font></span></div>
    <div class="image-container">
        <img src="/images/tanks/'.$tip1.'/'.$tank1['country'].'/'.$tank1['name'].'_.png" alt="tank" class="image1">';
       
	   if($_SESSION['hit']>0){
       echo '<img src="/images/victory_2.gif" alt="tank" class="image2">';
       }

echo '</div>
<canvas id="myCanvas" width="1000" height="310"></canvas>


</div></div></div></div></div></div></div></div></div></div></td><td class="w50 pl1">
<div class="trnt-block mb10"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="p5 cntr custombg boi_2" w:id="targetDiv">
<div class="small red1 cD2 cntr sh_b pb5 pt5"><font size=1%>'.$name.'</font><br><img width="10%" src="/images/tanks/'.$tip2.'.png"><span class="gray1"><font size=1>'.$tank2['name'].'</font></span></div>
<div class="image-container">
        <img src="/images/tanks/'.$tip2.'/'.$tank2['country'].'/'.$tank2['name'].'.png" alt="tank" class="image3">';
		if($_SESSION['image2Top1']!=''){
		echo '<img src="/images/buttl.gif" alt="tank" class="image4" id="animated-gif" style="width:100%; height: 300%;">';
		}    
		
echo '</div>

</div></div></div></div></div></div></div></div></div></div>
</td></tr></tbody></table></a>';

if($user['fuel'] >= 30){
echo '<div class="bot"><a class="simple-but border" href="?'.$href.'"><span><span>ДРУГИЕ ПРОТИВНИКИ</span></span></a></div>';
}else{
echo '<div class="bot"><a class="simple-but border gray" href="?'.$href.'"><span><span>ДРУГИЕ ПРОТИВНИКИ</span></span></a></div>';
}
//}










/* 

echo '<center><div class="wrap-content custombg angar_1" style="width:100%; border-radius: 10px;"> 
<br><a href="?'.$href.'"><table><tbody><tr>';
echo '<td style="width:2%;padding-left:3px;"><div style="position:relative;"></div></td>';
echo '<td style="width:50%;padding-left:4px;"><div style="position:relative;">
<div class="small bold cD2 cntr sh_b pb5 pt5"><font size=1%>'.$user['login'].'</font><br><img width="10%" src="/images/tanks/'.$tip1.'.png"><span class="gray1"><font size=1>'.$tank1['name'].'</font></span></div><img class="tank-img" alt="tank" src="/images/tanks/'.$tip1.'/'.$tank1['country'].'/'.$tank1['name'].'_.png" style="width:100%;">
</div></td>';
if($battle['hit']>0){
echo '<td style="width:50%;padding-right:4px;"><div style="position:relative;">
<div class="small bold cD2 cntr sh_b pb5 pt5"><font size=1%>'.$name.'</font><br><img width="10%" src="/images/tanks/'.$tip2.'.png"><span class="gray1"><font size=1>'.$tank2['name'].'</font></span></div><img class="tank-img" alt="tank" src="/images/tanks/'.$tip2.'/'.$tank2['country'].'/'.$tank2['name'].'/'.$tank2['name'].'_'.$battle['hit'].'.png" style="width:100%;">
</td>';
}else{
echo '<td style="width:50%;padding-right:4px;"><div style="position:relative;">
<div class="small bold cD2 cntr sh_b pb5 pt5"><font size=1%>'.$name.'</font><br><img width="10%" src="/images/tanks/'.$tip2.'.png"><span class="gray1"><font size=1>'.$tank2['name'].'</font></span></div><img class="tank-img" alt="tank" src="/images/tanks/'.$tip2.'/'.$tank2['country'].'/'.$tank2['name'].'.png" style="width:100%;">
</td>';
}
echo '<td style="width:2%;padding-right:3px;"><div style="position:relative;"></div></td>';
echo '</tr></tbody></table></a><div class="cntr small bold mb2 pb0"></div>';


if($user['fuel'] >= 30){
echo '<div class="bot"><a class="simple-but border" href="?'.$href.'"><span><span>ДРУГИЕ ПРОТИВНИКИ</span></span></a></div>';
}else{
echo '<div class="bot"><a class="simple-but border gray" href="?'.$href.'"><span><span>ДРУГИЕ ПРОТИВНИКИ</span></span></a></div>';
}
echo '</div></center>';
echo '</div></div></div></div></div></div></div></div></div></div>';
 */













#############################################################################
#############################################################################
if(isset($_GET[''.$href.''])){
$mysqli->query('DELETE FROM `battle` WHERE `id` = "'.$battle['id'].'"  ');
header('Location: '.$HOME.'battle/');
exit();
}
#############################################################################
#############################################################################






















require_once ('../system/footer.php');
?>