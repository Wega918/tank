<?php
$title = 'Бой';
require_once ('../system/function.php');
require_once ('../system/header.php');
if(!$user['id']) {
header('Location: '.$HOME.'');
exit();
}

/* if($user['kill_tanks'] < 3){
echo '<div class="trnt-block mb2"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content-mini"><div class="mt5 mb5 small green1 bold cntr">';
echo 'Уничтожь в бою 3 танка<br>';
if($user['kill_tanks'] >= 1){
echo ' <img height="14" width="14" src="/images/icons/online.png"> ';
}else{
echo ' <img height="14" width="14" src="/images/icons/offline.png"> ';
}
if($user['kill_tanks'] >= 2){
echo ' <img height="14" width="14" src="/images/icons/online.png"> ';
}else{
echo ' <img height="14" width="14" src="/images/icons/offline.png"> ';
}
if($user['kill_tanks'] >= 3){
echo ' <img height="14" width="14" src="/images/icons/online.png"> ';
}else{
echo ' <img height="14" width="14" src="/images/icons/offline.png"> ';
}
echo '</div></div></div></div></div></div></div></div></div></div></div>';
}
 */


$res = $mysqli->query('SELECT * FROM `battle` WHERE `user` = '.$user['id'].' limit 1');
$battle = $res->fetch_assoc();
$res = $mysqli->query('SELECT * FROM `users_tanks` WHERE `user`  = "'.$user['id'].'" and `active`  = "1" limit 1');
$users_tanks = $res->fetch_assoc();
$res = $mysqli->query('SELECT * FROM `tanks` WHERE `id` = "'.$users_tanks['tip'].'" ');
$tankUs = $res->fetch_assoc();
$res = $mysqli->query('SELECT * FROM `traning` WHERE `user`  = "'.$user['id'].'" limit 1');
$traning = $res->fetch_assoc();
if($battle['battle']>0) {
header('Location: '.$HOME.'battle/'.$battle['battle'].'/');
exit();
}

$arr = array(
1 => "Ведьмаг Ада",
2 => "Страник Ха",
3 => "Бегун",
4 => "Оскар Линд",
5 => "Коцап",
6 => "Плакса Царь",
7 => "Бац",
8 => "Клан Ветра",
9 => "Бодя Букин",
10 => "Ловкий Гюрза",
11 => "Жевастик",
12 => "Левоха",
13 => "Летучий огурец",
14 => "Аль Рашид",
15 => "Бешенный Зу",
16 => "Костя Федчук",
17 => "Страник Ха",
18 => "Барсук",
19 => "Трупо Укладчик",
20 => "Людоед",
21 => "Сироп",
22 => "Зубачистка",
23 => "Лунт",
24 => "Критт",
25 => "Анахарсис",
26 => "Дежавю",
27 => "Хик",
28 => "Велзевул",
29 => "Максим Ак",
30 => "Князь Светлов",
31 => "Ларс Викстрём",
32 => "Малышка Мышка",
33 => "Хозяин Демон",
34 => "Оггород",
35 => "Кастиэл",
36 => "Саня Снайпер",
37 => "Бешенный Лотар",
38 => "Нивиный",
39 => "Холифилд",
40 => "Айсберг Хищник",
41 => "Ильяс Аида",
42 => "Ляпа Кузнец",
43 => "Манах Войны",
44 => "Кадж",
45 => "Душа Кошки",
46 => "Кефир",
47 => "Святой Враг",
48 => "Динамит Ловкий",
49 => "Сирёжик",
50 => "Ушаталово",
51 => "Грох Принц",
52 => "Кима кепка",
53 => "Бейбулат",
54 => "Сатрик",
55 => "Никанорчик",
56 => "Золотой Телец",
57 => "Фунтик из кунцего",
58 => "Мриридимримд",
59 => "Смрадный",
60 => "Солдат Химик" ); 
$rand_nick = rand(1,60);
$rand_nick2 = rand(1,60);






$params = $users_tanks['a']+$users_tanks['b']+$users_tanks['t']+$users_tanks['p'];
$params1 = ceil($params+($params*10/100));
$params2 = ceil($params+($params*15/100));



$rand_tanks1 = rand(1,47);
$rand_tanks2 = rand(1,47);
$res = $mysqli->query('SELECT * FROM `tanks` WHERE `id`  = "'.$rand_tanks1.'" limit 1');
$tank1 = $res->fetch_assoc();
$res = $mysqli->query('SELECT * FROM `tanks` WHERE `id`  = "'.$rand_tanks2.'" limit 1');
$tank2 = $res->fetch_assoc();

if($tank1['tip'] == 1){$tip1 = 'average';} // СТ
if($tank1['tip'] == 2){$tip1 = 'heavy';} // ТТ
if($tank1['tip'] == 3){$tip1 = 'SAU';} // САУ
if($tank2['tip'] == 1){$tip2 = 'average';} // СТ
if($tank2['tip'] == 2){$tip2 = 'heavy';} // ТТ
if($tank2['tip'] == 3){$tip2 = 'SAU';} // САУ
#############################################################################
#############################################################################
if($tankUs['country']=='GERMANY'){$country = 1;}
if($tankUs['country']=='SSSR'){$country = 2;}
if($tankUs['country']=='USA'){$country = 3;}








echo '<div class="trnt-block"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8">
<div class="wrap-content custombg farm_1">
<div class="small bold cD2 cntr sh_b pb2"><img class="vb" height="14" width="14" src="/images/side/empire/'.$traning['rang'].'.png"> '.$arr[$rand_nick].'</div>
<center><img width="20" height="20" src="/images/tanks/'.$tip1.'.png"><font size=2><b>'.$tank1['name'].'</b></font></center>
<table><tbody><tr><td class="cntr"><a href="?battle1"><img width="50%" alt="tank" src="/images/tanks/'.$tip1.'/'.$tank1['country'].'/'.$tank1['name'].'.png"></a></td></tr></tbody></table>
<div class="cntr small bold mb2 pb0"><img src="/images/upgrades/starFull.png" height="14" width="14"> <span class="green2">Танковая мощь: '.$params1.'</span></div>';
if($user['fuel'] >= 30){
echo '<div class="bot"><a class="simple-but border" href="?battle1"><span><span>В бой</span></span></a></div>';
}else{
echo '<div class="bot"><a class="simple-but border gray" href="?battle1"><span><span>В бой</span></span></a></div>';
}
echo '</div></div></div></div></div></div></div></div></div></div></div>';


echo '<div class="trnt-block"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8">
<div class="wrap-content custombg farm_1">
<div class="small bold cD2 cntr sh_b pb2"><img class="vb" height="14" width="14" src="/images/side/empire/'.$traning['rang'].'.png"> '.$arr[$rand_nick2].'</div>
<center><img width="20" height="20" src="/images/tanks/'.$tip2.'.png"><font size=2><b>'.$tank2['name'].'</b></font></center>
<table><tbody><tr><td class="cntr"><a href="?battle2"><img width="50%" alt="tank" src="/images/tanks/'.$tip2.'/'.$tank2['country'].'/'.$tank2['name'].'.png"></a></td></tr></tbody></table>
<div class="cntr small bold mb2 pb0"><img src="/images/upgrades/starFull.png" height="14" width="14"> <span class="green2">Танковая мощь: '.$params2.'</span></div>';
if($user['fuel'] >= 30){
echo '<div class="bot"><a class="simple-but border" href="?battle2"><span><span>В бой</span></span></a></div>';
}else{
echo '<div class="bot"><a class="simple-but border gray" href="?battle2"><span><span>В бой</span></span></a></div>';
}
echo '</div></div></div></div></div></div></div></div></div></div></div>';
#############################################################################
#############################################################################









$cost_fuel = 50;




#############################################################################
#############################################################################
if(isset($_GET['battle1'])){
if($user['fuel'] < 30){
$_SESSION['err'] = '<div class="cntr mb5"><div class="white small">У вас не хватает <img src="/images/icons/fuel.png">'.(30-$user['fuel']).' топлива.</div></div><div class="trnt-block">
<div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8">
<div class="wrap-content cntr"><div class="green1 small">Получить <img src="/images/icons/fuel.png">'.($user['fuel_max']-$user['fuel']).' топлива</div>
<div class="bot">
<a class="simple-but gray border" href="?fuel"><span><span>Купить за <img class="ico vm" src="/images/icons/gold.png?1" alt="Золото" title="Золото"> <font size=1%>'.$cost_fuel.'</font></span></span></a>
</div></div></div></div></div></div></div></div></div></div></div>';
header('Location: ?');
exit();
}

$rand = rand(1,6);
if($rand == 1){$resuilt = 'Пробитие!';}
if($rand == 2){$resuilt = 'Враг горит!';}
if($rand == 3){$resuilt = 'Есть попадание!';}
if($rand == 4){$resuilt = 'Попадание!';}
if($rand == 5){$resuilt = 'Противник подбит!';}
if($rand == 6){
$rand_ = rand(1,6);
if($rand_ == 1){$resuilt = '<font color=red>Промах!</font>';}
if($rand_ == 2){$resuilt = '<font color=red>Рикошет!</font>';}
if($rand_ == 3){$resuilt = '<font color=red>Враг сманеврировал!</font>';}
if($rand_ == 4){$resuilt = '<font color=red>Не пробил!</font>';}
if($rand_ == 5){$resuilt = '<font color=red>Не попал в броню!</font>';}
if($rand_ == 6){$resuilt = '<font color=red>Броня не пробита!</font>';}
}

if($rand <= 5){
$hit = 1;
$exp = (2+$traning['rang']);
$silver = ((rand(2,3))+$traning['rang']);
$_SESSION['image2Top1'] = ''.rand(0,35).'%';
$_SESSION['image2Left1'] = ''.rand(0,55).'%';
}else{
$hit = 0;
$exp = $traning['rang'];
$silver = ((rand(0,1))+$traning['rang']);
$_SESSION['image2Top1'] = '';
$_SESSION['image2Left1'] = '';
}
$res1 = $mysqli->query('SELECT * FROM `vip` WHERE `user` = "'.$user['id'].'" LIMIT 1');
$vip = $res1->fetch_assoc();

$res_s7 = $mysqli->query('SELECT * FROM `skills_user` WHERE `tip`  = "7" and `user`  = "'.$user['id'].'" ');
$skills_7 = $res_s7->fetch_assoc(); // Инструктор Повышает личный заработанный опыт.

$res = $mysqli->query('SELECT * FROM `prom` WHERE `id` = "1" ');
$prom = $res->fetch_assoc();

if($prom['time_2']>time()){$exp_p2 = $prom['act_2'];}else{$exp_p2 = 0;}
if($prom['time_17']>time()){$exp_p17 = $prom['act_17'];}else{$exp_p17 = 0;}
if($prom['time_18']>time()){$sil_p18 = $prom['act_18'];}else{$sil_p18 = 0;}

if($vip['time2']>time()){$v2s = 25;$v2e = 50;}elsE{$v2s = 0;$v2e = 0;}
if($vip['time4']>time()){$v4e = 50;}elsE{$v4e = 0;}
$silver = ceil($silver+ ($silver*($v2s+$sil_p18)/100));
$exp = ceil($exp+ ($exp*($v2e+$v4e+$skills_7['bon']+$exp_p2+$exp_p17)/100));


####################################################################################
$id_miss = 3;$prog_max = 6;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().' and `country` = "'.$country.'" limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){
if($hit == 1){
$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "1" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
}else{
$mysqli->query('UPDATE `missions_user` SET `prog` =  "0" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
}
//$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "1" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
####################################################################################

####################################################################################
$id_miss = 14;$prog_max = 500;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().' and `country` = "'.$country.'" limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "'.$exp.'" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
####################################################################################

####################################################################################
if($hit==1 and $traning['rang']>=3 and $user['level']>=7){
$id_miss = 24;$prog_max = 5000;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().' and `country` = "'.$country.'" limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "'.$exp.'" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
}
####################################################################################

####################################################################################
if($traning['rang']>=3 and $user['level']>=7){
$id_miss = 21;$prog_max = 150;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().' and `country` = "'.$country.'" limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "1" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
}
####################################################################################


if($prom['time_20']>time()){
$res = $mysqli->query('SELECT * FROM `bz_user` WHERE `user` = "'.$user['id'].'" and `tip` = "'.$prom['tip_20'].'"');
$bz_user = $res->fetch_assoc();
if($bz_user['step']==6 and $bz_user['prog_']<$bz_user['prog']){
$mysqli->query('UPDATE `bz_user` SET `prog_` = `prog_` + "'.$exp.'" WHERE `id` = '.$bz_user['id'].'');
}
}


$mysqli->query('UPDATE `battle` SET `tank` = "1", `battle` = "1", `hit` = '.($battle['hit']+$hit).' WHERE `id` = '.$battle['id'].'');
$mysqli->query('UPDATE `users` SET `silver` = '.($user['silver']+$silver).', `exp` = '.($user['exp']+$exp).', `fuel` = '.($user['fuel']-30).' WHERE `id` = '.$user['id'].'');

if($user['company']){
$res_company = $mysqli->query('SELECT * FROM `company` WHERE `id` = '.$user['company'].' limit 1');
$company = $res_company->fetch_assoc();
$res_company_user = $mysqli->query('SELECT * FROM `company_user` WHERE `user` = '.$user['id'].' and `company` = '.$company['id'].' LIMIT 1');
$company_user = $res_company_user->fetch_assoc();
$res_crew_user = $mysqli->query('SELECT * FROM `crew_user` WHERE `user` = '.$user['id'].' and `tip` = "1" limit 1');
$crew_user = $res_crew_user->fetch_assoc();
$res_s6 = $mysqli->query('SELECT * FROM `skills_user` WHERE `tip`  = "6" and `user`  = "'.$user['id'].'" ');
$skills_6 = $res_s6->fetch_assoc(); // Курсы офицеров Повышает заработанный опыт дивизии.
$exp_company = $exp+  ($exp*($crew_user['sposobn']+$skills_6['bon'])/100);
$mysqli->query('UPDATE `company_user` SET `company_exp` = '.($company_user['company_exp']+$exp_company).', `company_exp_stats` = '.($company_user['company_exp_stats']+$exp_company).' WHERE `id` = '.$company_user['id'].'');
$mysqli->query('UPDATE `company` SET `exp` = '.($company['exp']+$exp_company).' WHERE `id` = '.$company['id'].'');
}

header('Location: '.$HOME.'battle/1/');
$_SESSION['err'] = '
<div class="medium bold pb5 cntr green1"><img height="14" width="14" src="/images/icons/victory.png"> <span>'.$resuilt.'</span> <img height="14" width="14" src="/images/icons/victory.png"></div>
<div class="small white cntr sh_b bold">
<span class="nwr"><img class="ico vm" src="/images/icons/exp.png" alt="опыт" title="опыт"> '.$exp.' опыта</span>
<span class="nwr"><img class="ico vm" src="/images/icons/silver.png" alt="Серебро" title="Серебро"> '.$silver.' серебра</span>
</div>';
exit();
}
#############################################################################
#############################################################################












#############################################################################
#############################################################################
if(isset($_GET['battle2'])){
if($user['fuel'] < 30){
$_SESSION['err'] = '<div class="cntr mb5"><div class="white small">У вас не хватает <img src="/images/icons/fuel.png">'.(30-$user['fuel']).' топлива.</div></div><div class="trnt-block">
<div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8">
<div class="wrap-content cntr"><div class="green1 small">Получить <img src="/images/icons/fuel.png">'.($user['fuel_max']-$user['fuel']).' топлива</div>
<div class="bot">
<a class="simple-but gray border" href="?fuel"><span><span>Купить за <img class="ico vm" src="/images/icons/gold.png?1" alt="Золото" title="Золото"> <font size=1%>'.$cost_fuel.'</font></span></span></a>
</div></div></div></div></div></div></div></div></div></div></div>';
header('Location: ?');
exit();
}
$rand = rand(1,4);
if($rand == 1){$resuilt = 'Пробитие!';}
if($rand == 2){$resuilt = 'Враг горит!';}
if($rand == 3){$resuilt = 'Есть попадание!';}
if($rand == 4){
$rand_ = rand(1,6);
if($rand_ == 1){$resuilt = '<font color=red>Промах!</font>';}
if($rand_ == 2){$resuilt = '<font color=red>Рикошет!</font>';}
if($rand_ == 3){$resuilt = '<font color=red>Враг сманеврировал!</font>';}
if($rand_ == 4){$resuilt = '<font color=red>Не пробил!</font>';}
if($rand_ == 5){$resuilt = '<font color=red>Не попал в броню!</font>';}
if($rand_ == 6){$resuilt = '<font color=red>Броня не пробита!</font>';}
}

if($rand <= 3){
$hit = 1;
$exp = (4+$traning['rang']);
$silver = ((rand(5,6))+$traning['rang']);
$_SESSION['image2Top1'] = ''.rand(0,35).'%';
$_SESSION['image2Left1'] = ''.rand(0,55).'%';
}else{
$hit = 0;
$exp = (2+$traning['rang']);
$silver = ((rand(2,3))+$traning['rang']);
$_SESSION['image2Top1'] = '';
$_SESSION['image2Left1'] = '';
}


$res1 = $mysqli->query('SELECT * FROM `vip` WHERE `user` = "'.$user['id'].'" LIMIT 1');
$vip = $res1->fetch_assoc();

$res_s7 = $mysqli->query('SELECT * FROM `skills_user` WHERE `tip`  = "7" and `user`  = "'.$user['id'].'" ');
$skills_7 = $res_s7->fetch_assoc(); // Инструктор Повышает личный заработанный опыт.

$res = $mysqli->query('SELECT * FROM `prom` WHERE `id` = "1" ');
$prom = $res->fetch_assoc();

if($prom['time_2']>time()){$exp_p2 = $prom['act_2'];}else{$exp_p2 = 0;}
if($prom['time_17']>time()){$exp_p17 = $prom['act_17'];}else{$exp_p17 = 0;}
if($prom['time_18']>time()){$sil_p18 = $prom['act_18'];}else{$sil_p18 = 0;}

if($vip['time2']>time()){$v2s = 25;$v2e = 50;}elsE{$v2s = 0;$v2e = 0;}
if($vip['time4']>time()){$v4e = 50;}elsE{$v4e = 0;}
$silver = ceil($silver+ ($silver*($v2s+$sil_p18)/100));
$exp = ceil($exp+ ($exp*($v2e+$v4e+$skills_7['bon']+$exp_p2+$exp_p17)/100));


####################################################################################
$id_miss = 3;$prog_max = 6;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().' and `country` = "'.$country.'" limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){
if($hit == 1){
$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "1" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
}else{
$mysqli->query('UPDATE `missions_user` SET `prog` =  "0" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
}
$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "1" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
####################################################################################

####################################################################################
$id_miss = 14;$prog_max = 500;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().' and `country` = "'.$country.'" limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "'.$exp.'" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
####################################################################################

####################################################################################
if($hit==1 and $traning['rang']>=3 and $user['level']>=7){
$id_miss = 24;$prog_max = 5000;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().' and `country` = "'.$country.'" limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "'.$exp.'" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
}
####################################################################################

####################################################################################
if($traning['rang']>=3 and $user['level']>=7){
$id_miss = 21;$prog_max = 150;
$res = $mysqli->query('SELECT * FROM `missions_user` WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < '.time().' and `country` = "'.$country.'" limit 1');$miss = $res->fetch_assoc();
if($miss['prog']<$miss['prog_max'] and $miss['time']<time()){$mysqli->query('UPDATE `missions_user` SET `prog` = `prog` + "1" WHERE `user` = '.$user['id'].' and `id_miss` = "'.$id_miss.'" and `prog` < "'.$prog_max.'" and `time` < "'.time().'" and `country` = "'.$country.'" limit 1');
if(($miss['prog']+1)>=$prog_max and $miss['time']<time()){$_SESSION['miss'] = 1;}
}
}
####################################################################################


if($prom['time_20']>time()){
$res = $mysqli->query('SELECT * FROM `bz_user` WHERE `user` = "'.$user['id'].'" and `tip` = "'.$prom['tip_20'].'"');
$bz_user = $res->fetch_assoc();
if($bz_user['step']==6 and $bz_user['prog_']<$bz_user['prog']){
$mysqli->query('UPDATE `bz_user` SET `prog_` = `prog_` + "'.$exp.'" WHERE `id` = '.$bz_user['id'].'');
}
}

$mysqli->query('UPDATE `battle` SET `tank` = "2", `battle` = "1", `hit` = '.($battle['hit']+$hit).' WHERE `id` = '.$battle['id'].'');
$mysqli->query('UPDATE `users` SET `silver` = '.($user['silver']+$silver).', `exp` = '.($user['exp']+$exp).', `fuel` = '.($user['fuel']-30).' WHERE `id` = '.$user['id'].'');

if($user['company']){
$res_company_user = $mysqli->query('SELECT * FROM `company_user` WHERE `user` = '.$user['id'].' limit 1');
$company_user = $res_company_user->fetch_assoc();
$res_company = $mysqli->query('SELECT * FROM `company` WHERE `id` = '.$user['company'].' limit 1');
$company = $res_company->fetch_assoc();
$res_crew_user = $mysqli->query('SELECT * FROM `crew_user` WHERE `user` = '.$user['id'].' and `tip` = "1" limit 1');
$crew_user = $res_crew_user->fetch_assoc();
$res_s6 = $mysqli->query('SELECT * FROM `skills_user` WHERE `tip`  = "6" and `user`  = "'.$user['id'].'" ');
$skills_6 = $res_s6->fetch_assoc(); // Курсы офицеров Повышает заработанный опыт дивизии.
$exp_company = $exp+  ($exp*($crew_user['sposobn']+$skills_6['bon'])/100);
$mysqli->query('UPDATE `company_user` SET `company_exp` = '.($company_user['company_exp']+$exp_company).', `company_exp_stats` = '.($company_user['company_exp_stats']+$exp_company).' WHERE `id` = '.$company_user['id'].'');
$mysqli->query('UPDATE `company` SET `exp` = '.($company['exp']+$exp_company).' WHERE `id` = '.$company['id'].'');
}


header('Location: '.$HOME.'battle/1/');
$_SESSION['err'] = '
<div class="medium bold pb5 cntr green1"><img height="14" width="14" src="/images/icons/victory.png"> <span>'.$resuilt.'</span> <img height="14" width="14" src="/images/icons/victory.png"></div>
<div class="small white cntr sh_b bold">
<span class="nwr"><img class="ico vm" src="/images/icons/exp.png" alt="опыт" title="опыт"> '.$exp.' опыта</span>
<span class="nwr"><img class="ico vm" src="/images/icons/silver.png" alt="Серебро" title="Серебро"> '.$silver.' серебра</span>
</div>';
exit();
}
#############################################################################
#############################################################################









#############################################################################
#############################################################################
if(isset($_GET['fuel'])){
if($user['fuel'] >=30){header('Location: ?');exit();}
if($user['gold'] < $cost_fuel){
$_SESSION['err'] = '<div class="trnt-block"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="red1">У вас не хватает <img class="ico vm" src="/images/icons/gold.png?1" alt="Золото" title="Золото"> '.($cost_fuel-$user['gold']).' золота</div>
<div class="bot"><a class="simple-but mXa w50 border medium" href="'.$HOME.'payments/"><span><span>Купить золото</span></span></a></div>
</div></span></div></div></div>
</div></div></div></div></div></div></div></div></div></div>';
header('Location: ?');
exit();
}
$mysqli->query('UPDATE `users` SET `gold` = '.($user['gold']-$cost_fuel).', `fuel` = '.($user['fuel']=$user['fuel_max']).' WHERE `id` = '.$user['id'].'');
$_SESSION['err'] = '<div class="trnt-block mb1"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content cntr">
<div class="green1 sh_b mb2"><img height="14" width="14" src="/images/icons/victory.png"> Бак заправлен! <img height="14" width="14" src="/images/icons/victory.png"></div>
</div></div></div></div></div></div></div></div></div></div>';
header('Location: ?');
exit();
}
#############################################################################
#############################################################################

























if(!$battle){
$mysqli->query('INSERT INTO `battle` SET `time_delete` = '.(time()+86400).', `user` = '.$user['id'].', `ank_tank1` = '.$tank1['id'].', `ank_name1` = "'.$arr[$rand_nick].'", `ank_tank2` = '.$tank2['id'].', `ank_name2` = "'.$arr[$rand_nick2].'" ');
}else{
$mysqli->query('UPDATE `battle` SET `time_delete` = '.(time()+86400).', `ank_tank1` = '.$tank1['id'].', `ank_name1` = "'.$arr[$rand_nick].'", `ank_tank2` = '.$tank2['id'].', `ank_name2` = "'.$arr[$rand_nick2].'" WHERE `id` = '.$battle['id'].'');
}

$arr_text_battle = array(
1 => "<img class='vb pb2' height='14' width='14' src='/images/upgrades/starFull.png'> Танковая мощь: сумма всех параметров танка",
2 => "Тут показаны 2 противника (сверху вниз): слабый и сильный. Чем сильнее противник, тем больше награда за победу",
3 => "<div class='mt5 mb5 small green1 cntr'>Маленький секрет: Повышая свое звание в тренировке, вы будете получать большую награду</div>
<div class='bot'><a class='simple-but border' href='/training/".$user['id']."/'><span><span>Тренироваться</span></span></a></div><br>",
4 => "В сутки доступно 50 дополнительных дозаправок, с каждой дозаправкой цена уменьшается на <img class='ico vm' src='/images/icons/gold.png?1' alt='Золото' title='Золото'> 1 золота",
5 => "",
6 => "",
7 => "",
8 => "",
9 => "",
10 => ""); 
$rand_text_battle = rand(1,3);
echo '<div class="trnt-block mb2"><div class="wrap1"><div class="wrap2"><div class="wrap3"><div class="wrap4"><div class="wrap5"><div class="wrap6"><div class="wrap7"><div class="wrap8"><div class="wrap-content-mini">
<div class="mt5 mb5 small green1 cntr">'.$arr_text_battle[$rand_text_battle].'</div>
</div></div></div></div></div></div></div></div></div></div>';

require_once ('../system/footer.php');
?>